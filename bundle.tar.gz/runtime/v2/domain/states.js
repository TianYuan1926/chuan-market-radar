"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATE_DIMENSIONS = exports.DATA_QUALITY_STATES = exports.CANDIDATE_LIFECYCLE_TRANSITIONS = exports.DETECTOR_ALLOWED_EMISSION_SCOPES = exports.DETECTOR_EMISSION_SCOPES = exports.DETECTOR_LIFECYCLE_STATES = exports.CANDIDATE_LIFECYCLE_STATES = exports.USER_FITS = exports.ACTION_STATES = exports.SETUP_GRADES = exports.EVIDENCE_GRADES = exports.CANDIDATE_PRIORITIES = void 0;
exports.canDetectorEmit = canDetectorEmit;
exports.isCandidateLifecycleTransitionAllowed = isCandidateLifecycleTransitionAllowed;
exports.isActionState = isActionState;
exports.CANDIDATE_PRIORITIES = ["P0", "P1", "P2", "P3"];
exports.EVIDENCE_GRADES = ["A", "B", "C", "INSUFFICIENT"];
exports.SETUP_GRADES = [
    "PREMIUM",
    "QUALIFIED",
    "MARGINAL",
    "INVALID",
    "UNKNOWN",
];
exports.ACTION_STATES = [
    "OBSERVE",
    "WAIT",
    "BLOCKED",
    "TRADE_PLAN_READY",
];
exports.USER_FITS = [
    "SUITABLE",
    "CONDITIONAL",
    "UNSUITABLE",
    "UNAVAILABLE",
];
exports.CANDIDATE_LIFECYCLE_STATES = [
    "DISCOVERED",
    "QUEUED",
    "VALIDATING",
    "EVIDENCE_READY",
    "PROMOTED",
    "REJECTED",
    "EXPIRED",
    "DATA_UNAVAILABLE",
];
exports.DETECTOR_LIFECYCLE_STATES = [
    "DRAFT",
    "REPLAY_VALIDATED",
    "SHADOW",
    "LIMITED",
    "ACTIVE",
    "SUSPENDED",
    "RETIRED",
];
exports.DETECTOR_EMISSION_SCOPES = [
    "REPLAY",
    "SHADOW",
    "LIMITED",
    "PRODUCTION",
];
exports.DETECTOR_ALLOWED_EMISSION_SCOPES = Object.freeze({
    DRAFT: [],
    REPLAY_VALIDATED: ["REPLAY"],
    SHADOW: ["REPLAY", "SHADOW"],
    LIMITED: ["REPLAY", "SHADOW", "LIMITED"],
    ACTIVE: ["REPLAY", "SHADOW", "LIMITED", "PRODUCTION"],
    SUSPENDED: [],
    RETIRED: [],
});
function canDetectorEmit(lifecycle, scope) {
    return exports.DETECTOR_ALLOWED_EMISSION_SCOPES[lifecycle]
        .includes(scope);
}
exports.CANDIDATE_LIFECYCLE_TRANSITIONS = Object.freeze({
    DISCOVERED: ["QUEUED", "REJECTED", "EXPIRED", "DATA_UNAVAILABLE"],
    QUEUED: ["VALIDATING", "REJECTED", "EXPIRED", "DATA_UNAVAILABLE"],
    VALIDATING: ["EVIDENCE_READY", "REJECTED", "EXPIRED", "DATA_UNAVAILABLE"],
    EVIDENCE_READY: ["PROMOTED", "REJECTED", "EXPIRED", "DATA_UNAVAILABLE"],
    PROMOTED: [],
    REJECTED: [],
    EXPIRED: [],
    DATA_UNAVAILABLE: [],
});
function isCandidateLifecycleTransitionAllowed(previous, next) {
    return exports.CANDIDATE_LIFECYCLE_TRANSITIONS[previous]
        .includes(next);
}
exports.DATA_QUALITY_STATES = [
    "FRESH",
    "PARTIAL",
    "STALE",
    "UNAVAILABLE",
    "RATE_LIMITED",
    "AUTH_ERROR",
    "TRANSPORT_ERROR",
    "INVALID",
];
exports.STATE_DIMENSIONS = Object.freeze({
    actionState: exports.ACTION_STATES,
    candidatePriority: exports.CANDIDATE_PRIORITIES,
    evidenceGrade: exports.EVIDENCE_GRADES,
    setupGrade: exports.SETUP_GRADES,
    userFit: exports.USER_FITS,
});
function isActionState(value) {
    return typeof value === "string" &&
        exports.ACTION_STATES.some((state) => state === value);
}
