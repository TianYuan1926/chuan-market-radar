"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PRODUCT_CONSTITUTION = exports.CONSTITUTIONAL_INVARIANTS = exports.PRODUCT_MISSION = exports.OPPORTUNITY_PATTERNS_BY_FAMILY = exports.OPPORTUNITY_DIRECTIONS_BY_FAMILY = exports.OPPORTUNITY_PATTERNS = exports.OPPORTUNITY_FAMILIES = exports.SUPPORTED_CONTRACT_CLASS = exports.TARGET_VENUES = exports.V2_DOMAIN_SCHEMA_VERSION = void 0;
exports.isOpportunityPatternForFamily = isOpportunityPatternForFamily;
exports.V2_DOMAIN_SCHEMA_VERSION = "market-radar-v2-domain.v2";
exports.TARGET_VENUES = [
    "BINANCE_FUTURES",
    "OKX_SWAP",
    "BYBIT_LINEAR_PERPETUAL",
];
exports.SUPPORTED_CONTRACT_CLASS = "LINEAR_STABLECOIN_SETTLED_PERPETUAL";
exports.OPPORTUNITY_FAMILIES = [
    "PRE_MOVE",
    "BREAKOUT_RETEST",
    "TREND_CONTINUATION",
    "REVERSAL_RANGE",
    "RELATIVE_STRENGTH",
    "DERIVATIVES_FLOW",
];
exports.OPPORTUNITY_PATTERNS = [
    "PRE_MOVE_COMPRESSION",
    "PRE_MOVE_FLOW_DIVERGENCE",
    "PRE_MOVE_LIQUIDITY_SHIFT",
    "BREAKOUT_EDGE",
    "ROLE_FLIP_RETEST",
    "TREND_COMPRESSION",
    "STRUCTURAL_PULLBACK_RESUMPTION",
    "KEY_LEVEL_REVERSAL",
    "RANGE_EDGE",
    "RELATIVE_STRENGTH",
    "RELATIVE_WEAKNESS",
    "PRICE_OI_DIVERGENCE",
    "CROWDING_RELEASE",
    "FUNDING_BASIS_DISLOCATION",
];
exports.OPPORTUNITY_DIRECTIONS_BY_FAMILY = Object.freeze({
    PRE_MOVE: ["LONG", "SHORT", "UNKNOWN"],
    BREAKOUT_RETEST: ["LONG", "SHORT"],
    TREND_CONTINUATION: ["LONG", "SHORT"],
    REVERSAL_RANGE: ["LONG", "SHORT"],
    RELATIVE_STRENGTH: ["LONG", "SHORT"],
    DERIVATIVES_FLOW: ["LONG", "SHORT", "UNKNOWN"],
});
exports.OPPORTUNITY_PATTERNS_BY_FAMILY = Object.freeze({
    PRE_MOVE: [
        "PRE_MOVE_COMPRESSION",
        "PRE_MOVE_FLOW_DIVERGENCE",
        "PRE_MOVE_LIQUIDITY_SHIFT",
    ],
    BREAKOUT_RETEST: ["BREAKOUT_EDGE", "ROLE_FLIP_RETEST"],
    TREND_CONTINUATION: [
        "TREND_COMPRESSION",
        "STRUCTURAL_PULLBACK_RESUMPTION",
    ],
    REVERSAL_RANGE: ["KEY_LEVEL_REVERSAL", "RANGE_EDGE"],
    RELATIVE_STRENGTH: ["RELATIVE_STRENGTH", "RELATIVE_WEAKNESS"],
    DERIVATIVES_FLOW: [
        "PRICE_OI_DIVERGENCE",
        "CROWDING_RELEASE",
        "FUNDING_BASIS_DISLOCATION",
    ],
});
function isOpportunityPatternForFamily(family, pattern) {
    return exports.OPPORTUNITY_PATTERNS_BY_FAMILY[family]
        .includes(pattern);
}
exports.PRODUCT_MISSION = "Continuously cover every eligible target-CEX contract, detect pre-move opportunities as early as honestly provable, detect other structured long and short opportunities, produce strict human-execution plans, and improve through point-in-time outcomes without future leakage.";
exports.CONSTITUTIONAL_INVARIANTS = Object.freeze({
    automaticRulePromotionAllowed: false,
    automaticTradingAllowed: false,
    candidateIsSignal: false,
    candidatePriorityMayRepresentEvidenceGrade: false,
    evidenceGradeMayRepresentSetupGrade: false,
    evidenceOrSetupGradeMayDirectlyImplyReady: false,
    frontendMayCreateTradingFacts: false,
    futureOutcomeMayAffectOriginalDecision: false,
    minimumNetRewardRisk: 3,
    minimumStructuralRewardRisk: 3,
    onlyFinalDecisionMayProduceReady: true,
    outcomeEvaluatorMayApprovePromotion: false,
    partialMayBecomeReady: false,
    personalOrPortfolioRiskMayUpgradeActionState: false,
    productionWriteAuthorityPerFact: 1,
    staleMayBecomeLive: false,
    strategyDraftMayDirectlyImplyReady: false,
    unknownMayBecomeZero: false,
});
exports.PRODUCT_CONSTITUTION = Object.freeze({
    contractClass: exports.SUPPORTED_CONTRACT_CLASS,
    invariants: exports.CONSTITUTIONAL_INVARIANTS,
    mission: exports.PRODUCT_MISSION,
    opportunityDirections: exports.OPPORTUNITY_DIRECTIONS_BY_FAMILY,
    opportunityFamilies: exports.OPPORTUNITY_FAMILIES,
    opportunityPatterns: exports.OPPORTUNITY_PATTERNS_BY_FAMILY,
    schemaVersion: exports.V2_DOMAIN_SCHEMA_VERSION,
    targetVenues: exports.TARGET_VENUES,
});
