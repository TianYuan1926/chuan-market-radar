"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UNCERTAINTY_DIMENSIONS = void 0;
exports.UNCERTAINTY_DIMENSIONS = [
    "data",
    "model",
    "market",
    "execution",
];
