"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stableSha256 = stableSha256;
exports.stableContentHash = stableContentHash;
exports.deepFreezeArtifact = deepFreezeArtifact;
const node_crypto_1 = require("node:crypto");
function canonicalJson(value) {
    if (value === null) {
        return "null";
    }
    if (typeof value === "string" || typeof value === "boolean") {
        return JSON.stringify(value);
    }
    if (typeof value === "number") {
        if (!Number.isFinite(value)) {
            throw new TypeError("artifact values must contain only finite numbers");
        }
        return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
        return `[${value.map((item) => canonicalJson(item)).join(",")}]`;
    }
    if (typeof value === "object") {
        const prototype = Object.getPrototypeOf(value);
        if (prototype !== Object.prototype && prototype !== null) {
            throw new TypeError("artifact values must contain only plain objects");
        }
        const record = value;
        return `{${Object.keys(record)
            .sort()
            .map((key) => `${JSON.stringify(key)}:${canonicalJson(record[key])}`)
            .join(",")}}`;
    }
    throw new TypeError("artifact values must be JSON-compatible");
}
function stableSha256(value) {
    return (0, node_crypto_1.createHash)("sha256").update(canonicalJson(value)).digest("hex");
}
function stableContentHash(value) {
    return `sha256:${stableSha256(value)}`;
}
function deepFreezeArtifact(value) {
    if (value === null || typeof value !== "object" || Object.isFrozen(value)) {
        return value;
    }
    for (const nested of Object.values(value)) {
        deepFreezeArtifact(nested);
    }
    return Object.freeze(value);
}
