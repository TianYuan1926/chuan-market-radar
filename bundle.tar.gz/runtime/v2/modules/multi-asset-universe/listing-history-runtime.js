"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.M1ListingHistoryAdvanceResultSchema = exports.M1ListingHistoryGapSchema = exports.M1ListingHistoryCheckpointSchema = exports.M1ListingHistoryPageSchema = exports.M1_LISTING_HISTORY_GAP_REASONS = exports.M1_LISTING_HISTORY_SOURCES = exports.M1_LISTING_HISTORY_GAP_VERSION = exports.M1_LISTING_HISTORY_CHECKPOINT_VERSION = exports.M1_LISTING_HISTORY_PAGE_VERSION = void 0;
exports.buildM1ListingHistoryRequest = buildM1ListingHistoryRequest;
exports.buildM1ListingHistoryPageRequest = buildM1ListingHistoryPageRequest;
exports.parseM1ListingHistoryPage = parseM1ListingHistoryPage;
exports.advanceM1ListingHistory = advanceM1ListingHistory;
const zod_1 = require("zod");
const primitives_1 = require("../../runtime-schema/primitives");
const source_capability_contract_1 = require("../source-capability/source-capability-contract");
const listing_lifecycle_contract_1 = require("./listing-lifecycle-contract");
const bybit_bitget_listing_announcements_1 = require("./adapters/bybit-bitget-listing-announcements");
const runtime_adapter_profile_1 = require("../collector/runtime-adapter-profile");
const stable_artifact_1 = require("../universe/stable-artifact");
exports.M1_LISTING_HISTORY_PAGE_VERSION = "v2-m1-listing-history-page.v1";
exports.M1_LISTING_HISTORY_CHECKPOINT_VERSION = "v2-m1-listing-history-checkpoint.v1";
exports.M1_LISTING_HISTORY_GAP_VERSION = "v2-m1-listing-history-gap.v1";
exports.M1_LISTING_HISTORY_SOURCES = [
    "BYBIT_DERIVATIVES",
    "BITGET_FUTURES",
];
exports.M1_LISTING_HISTORY_GAP_REASONS = [
    "SOURCE_OR_PROFILE_DRIFT",
    "REQUEST_TOKEN_DISCONTINUITY",
    "PAGE_ORDINAL_DISCONTINUITY",
    "REPEATED_REQUEST_TOKEN",
    "EMPTY_NONTERMINAL_PAGE",
    "ANNOUNCEMENT_ID_CONTENT_CONFLICT",
    "NO_CHECKPOINT_OVERLAP",
    "INVALID_SEGMENT_STOP",
    "FUTURE_KNOWLEDGE",
];
const DigestSchema = zod_1.z.string().regex(/^sha256:[0-9a-f]{64}$/u);
const ReleaseIdSchema = zod_1.z.string().regex(/^[0-9a-f]{40}$/u);
const ListingSourceSchema = zod_1.z.enum(exports.M1_LISTING_HISTORY_SOURCES);
const ListingModeSchema = zod_1.z.enum(["BOOTSTRAP", "INCREMENTAL"]);
const ListingHistoryResponsibilitySchema = zod_1.z.enum([
    "BYBIT_PROVIDER_AVAILABLE_HISTORY_CHECKPOINTED",
    "BITGET_OFFICIAL_ONE_MONTH_WINDOW_CHECKPOINTED",
]);
const UniqueStringsSchema = zod_1.z.array(primitives_1.NonEmptyStringSchema)
    .superRefine((values, context) => {
    if (new Set(values).size !== values.length) {
        context.addIssue({
            code: "custom",
            message: "values must be unique",
        });
    }
});
function responsibilityFor(sourceId) {
    return sourceId === "BYBIT_DERIVATIVES"
        ? "BYBIT_PROVIDER_AVAILABLE_HISTORY_CHECKPOINTED"
        : "BITGET_OFFICIAL_ONE_MONTH_WINDOW_CHECKPOINTED";
}
function validateListingProfile(profile) {
    runtime_adapter_profile_1.M1RuntimeAdapterProfileSchema.parse(profile);
    if (!exports.M1_LISTING_HISTORY_SOURCES.includes(profile.sourceId) ||
        profile.capabilityId !== "LISTING_ANNOUNCEMENT" ||
        profile.operation !== "LISTING_HISTORY_SEGMENT" ||
        !profile.schedulerRouteEligible ||
        !profile.noAuthorityShadowEligible ||
        profile.historyResponsibility !==
            responsibilityFor(profile.sourceId)) {
        throw new Error("listing history requires an exact live-passed announcement profile");
    }
}
const ListingHistoryPageCoreSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_LISTING_HISTORY_PAGE_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: ReleaseIdSchema,
    profileId: primitives_1.NonEmptyStringSchema,
    sourceId: ListingSourceSchema,
    historyResponsibility: ListingHistoryResponsibilitySchema,
    mode: ListingModeSchema,
    pageOrdinal: zod_1.z.number().int().positive().max(10000),
    requestToken: primitives_1.NonEmptyStringSchema,
    receivedAt: primitives_1.IsoDateTimeSchema,
    responseBodyHash: DigestSchema,
    rawRecordCount: primitives_1.NonNegativeIntegerSchema,
    normalizedRecordCount: primitives_1.NonNegativeIntegerSchema,
    providerReportedTotal: primitives_1.NonNegativeIntegerSchema.nullable(),
    nextRequestToken: primitives_1.NonEmptyStringSchema.nullable(),
    providerTerminal: zod_1.z.boolean(),
    observations: zod_1.z.array(listing_lifecycle_contract_1.M1ListingAnnouncementObservationSchema),
    rawBodyRetained: zod_1.z.literal(false),
    secretMaterialPresent: zod_1.z.literal(false),
    candidateEmissionAllowed: zod_1.z.literal(false),
    strategyAuthorityGranted: zod_1.z.literal(false),
    readyAuthorityGranted: zod_1.z.literal(false),
});
exports.M1ListingHistoryPageSchema = ListingHistoryPageCoreSchema.extend({
    pageId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
}).superRefine((page, context) => {
    if (page.rawRecordCount !== page.normalizedRecordCount ||
        page.normalizedRecordCount !== page.observations.length) {
        context.addIssue({
            code: "custom",
            message: "listing history page cannot hide normalization loss",
            path: ["normalizedRecordCount"],
        });
    }
    if (page.providerTerminal !== (page.nextRequestToken === null)) {
        context.addIssue({
            code: "custom",
            message: "provider terminal status must match the next token",
            path: ["providerTerminal"],
        });
    }
    const announcementIds = page.observations.map((observation) => observation.announcementId);
    if (new Set(announcementIds).size !== announcementIds.length) {
        context.addIssue({
            code: "custom",
            message: "one provider page cannot repeat an announcement id",
            path: ["observations"],
        });
    }
    for (const observation of page.observations) {
        if (observation.sourceId !== page.sourceId ||
            Date.parse(observation.knowledgeTime) > Date.parse(page.receivedAt)) {
            context.addIssue({
                code: "custom",
                message: "page observation source or knowledge time drifted",
                path: ["observations"],
            });
        }
    }
    if (page.sourceId === "BYBIT_DERIVATIVES") {
        const requestPage = parseBybitPageToken(page.requestToken);
        const nextPage = page.nextRequestToken === null
            ? null
            : parseBybitPageToken(page.nextRequestToken);
        if (requestPage === null ||
            (nextPage !== null && nextPage !== requestPage + 1) ||
            page.providerReportedTotal === null) {
            context.addIssue({
                code: "custom",
                message: "Bybit listing page number chain is invalid",
                path: ["requestToken"],
            });
        }
    }
    else if (!(page.requestToken === "ROOT" ||
        page.requestToken.startsWith("cursor:")) ||
        (page.nextRequestToken !== null &&
            !page.nextRequestToken.startsWith("cursor:")) ||
        page.providerReportedTotal !== null) {
        context.addIssue({
            code: "custom",
            message: "Bitget listing cursor chain is invalid",
            path: ["requestToken"],
        });
    }
    const expectedHash = (0, stable_artifact_1.stableContentHash)(listingHistoryPageCore(page));
    if (page.contentHash !== expectedHash) {
        context.addIssue({
            code: "custom",
            message: "listing history page content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (page.pageId !==
        `listing-history-page:${page.sourceId}:${expectedHash.slice(7, 23)}`) {
        context.addIssue({
            code: "custom",
            message: "listing history page id mismatch",
            path: ["pageId"],
        });
    }
});
function listingHistoryPageCore(page) {
    return ListingHistoryPageCoreSchema.parse({
        schemaVersion: page.schemaVersion,
        scopeEpoch: page.scopeEpoch,
        releaseId: page.releaseId,
        profileId: page.profileId,
        sourceId: page.sourceId,
        historyResponsibility: page.historyResponsibility,
        mode: page.mode,
        pageOrdinal: page.pageOrdinal,
        requestToken: page.requestToken,
        receivedAt: page.receivedAt,
        responseBodyHash: page.responseBodyHash,
        rawRecordCount: page.rawRecordCount,
        normalizedRecordCount: page.normalizedRecordCount,
        providerReportedTotal: page.providerReportedTotal,
        nextRequestToken: page.nextRequestToken,
        providerTerminal: page.providerTerminal,
        observations: page.observations,
        rawBodyRetained: page.rawBodyRetained,
        secretMaterialPresent: page.secretMaterialPresent,
        candidateEmissionAllowed: page.candidateEmissionAllowed,
        strategyAuthorityGranted: page.strategyAuthorityGranted,
        readyAuthorityGranted: page.readyAuthorityGranted,
    });
}
function parseBybitPageToken(token) {
    const match = /^page:([1-9][0-9]*)$/u.exec(token);
    if (match === null)
        return null;
    const value = Number(match[1]);
    return Number.isSafeInteger(value) ? value : null;
}
function object(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value)
        ? value
        : null;
}
function arrayAt(value, ...path) {
    let current = value;
    for (const key of path) {
        const record = object(current);
        if (record === null)
            return null;
        current = record[key];
    }
    return Array.isArray(current) ? current : null;
}
function numberAt(value, ...path) {
    let current = value;
    for (const key of path) {
        const record = object(current);
        if (record === null)
            return null;
        current = record[key];
    }
    return typeof current === "number" && Number.isFinite(current)
        ? current
        : null;
}
function stringAt(value, ...path) {
    let current = value;
    for (const key of path) {
        const record = object(current);
        if (record === null)
            return null;
        current = record[key];
    }
    return typeof current === "string" ? current : null;
}
function buildM1ListingHistoryRequest(input) {
    var _a, _b;
    validateListingProfile(input.profile);
    if (input.checkpoint !== null) {
        exports.M1ListingHistoryCheckpointSchema.parse(input.checkpoint);
        if (input.checkpoint.releaseId !== input.profile.runtimeReleaseId ||
            input.checkpoint.profileId !== input.profile.profileId ||
            input.checkpoint.sourceId !== input.profile.sourceId) {
            throw new Error("listing history checkpoint and profile drifted");
        }
    }
    let requestToken;
    if (input.mode === "INCREMENTAL") {
        if (input.checkpoint === null ||
            input.checkpoint.status === "BOOTSTRAP_IN_PROGRESS") {
            throw new Error("incremental collection requires a complete bootstrap");
        }
        requestToken = input.profile.sourceId === "BYBIT_DERIVATIVES"
            ? "page:1"
            : "ROOT";
    }
    else {
        if (input.checkpoint !== null &&
            input.checkpoint.status !== "BOOTSTRAP_IN_PROGRESS") {
            throw new Error("completed listing history cannot restart bootstrap");
        }
        requestToken = (_b = (_a = input.checkpoint) === null || _a === void 0 ? void 0 : _a.nextBootstrapRequestToken) !== null && _b !== void 0 ? _b : (input.profile.sourceId === "BYBIT_DERIVATIVES" ? "page:1" : "ROOT");
    }
    return buildM1ListingHistoryPageRequest({
        profile: input.profile,
        requestToken,
    });
}
function buildM1ListingHistoryPageRequest(input) {
    validateListingProfile(input.profile);
    const requestToken = primitives_1.NonEmptyStringSchema.parse(input.requestToken);
    const url = new URL(input.profile.initialUrl);
    if (input.profile.sourceId === "BYBIT_DERIVATIVES") {
        const page = parseBybitPageToken(requestToken);
        if (page === null)
            throw new Error("invalid Bybit page token");
        url.searchParams.set("locale", "en-US");
        url.searchParams.set("type", "new_crypto");
        url.searchParams.set("page", String(page));
        url.searchParams.set("limit", "20");
    }
    else {
        url.searchParams.set("language", "en_US");
        url.searchParams.set("annType", "coin_listings");
        url.searchParams.set("limit", "10");
        if (requestToken === "ROOT") {
            url.searchParams.delete("cursor");
        }
        else if (requestToken.startsWith("cursor:")) {
            url.searchParams.set("cursor", requestToken.slice("cursor:".length));
        }
        else {
            throw new Error("invalid Bitget cursor token");
        }
    }
    if (url.protocol !== "https:" ||
        url.hostname !== input.profile.endpointHost) {
        throw new Error("listing request escaped the exact profile host");
    }
    return (0, stable_artifact_1.deepFreezeArtifact)({
        allowedHost: input.profile.endpointHost,
        requestToken,
        url: url.toString(),
        credentialRequired: false,
        rawBodyRetentionAllowed: false,
    });
}
function parseM1ListingHistoryPage(input) {
    var _a, _b;
    validateListingProfile(input.profile);
    DigestSchema.parse(input.responseBodyHash);
    primitives_1.IsoDateTimeSchema.parse(input.receivedAt);
    let observations;
    let rawRecordCount;
    let providerReportedTotal;
    let nextRequestToken;
    if (input.profile.sourceId === "BYBIT_DERIVATIVES") {
        if (!(0, bybit_bitget_listing_announcements_1.bybitListingAnnouncementSchemaConforms)(input.payload)) {
            throw new Error("Bybit listing page failed exact schema conformance");
        }
        const records = arrayAt(input.payload, "result", "list");
        const total = numberAt(input.payload, "result", "total");
        const page = parseBybitPageToken(input.requestToken);
        if (records === null ||
            total === null ||
            !Number.isSafeInteger(total) ||
            page === null) {
            throw new Error("Bybit listing page metadata is incomplete");
        }
        const normalized = (0, bybit_bitget_listing_announcements_1.normalizeBybitListingAnnouncements)({
            payload: input.payload,
            receivedAt: input.receivedAt,
        });
        observations = normalized.observations;
        rawRecordCount = records.length;
        providerReportedTotal = total;
        nextRequestToken = page * 20 < total ? `page:${page + 1}` : null;
    }
    else {
        if (!(0, bybit_bitget_listing_announcements_1.bitgetListingAnnouncementSchemaConforms)(input.payload)) {
            throw new Error("Bitget listing page failed exact schema conformance");
        }
        const records = arrayAt(input.payload, "data");
        if (records === null) {
            throw new Error("Bitget listing page metadata is incomplete");
        }
        const normalized = (0, bybit_bitget_listing_announcements_1.normalizeBitgetListingAnnouncements)({
            payload: input.payload,
            receivedAt: input.receivedAt,
        });
        observations = normalized.observations;
        rawRecordCount = records.length;
        providerReportedTotal = null;
        const lastAnnouncementId = (_b = (_a = stringAt(records.at(-1), "annId")) === null || _a === void 0 ? void 0 : _a.trim()) !== null && _b !== void 0 ? _b : "";
        nextRequestToken = records.length === 10 && lastAnnouncementId.length > 0
            ? `cursor:${lastAnnouncementId}`
            : null;
    }
    if (observations.length !== rawRecordCount) {
        throw new Error("listing page normalization was partial");
    }
    const core = listingHistoryPageCore({
        schemaVersion: exports.M1_LISTING_HISTORY_PAGE_VERSION,
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        releaseId: input.profile.runtimeReleaseId,
        profileId: input.profile.profileId,
        sourceId: input.profile.sourceId,
        historyResponsibility: input.profile.historyResponsibility,
        mode: input.mode,
        pageOrdinal: input.pageOrdinal,
        requestToken: input.requestToken,
        receivedAt: input.receivedAt,
        responseBodyHash: input.responseBodyHash,
        rawRecordCount,
        normalizedRecordCount: observations.length,
        providerReportedTotal,
        nextRequestToken,
        providerTerminal: nextRequestToken === null,
        observations: [...observations],
        rawBodyRetained: false,
        secretMaterialPresent: false,
        candidateEmissionAllowed: false,
        strategyAuthorityGranted: false,
        readyAuthorityGranted: false,
    });
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1ListingHistoryPageSchema.parse(Object.assign(Object.assign({}, core), { pageId: `listing-history-page:${core.sourceId}:${contentHash.slice(7, 23)}`, contentHash })));
}
const ListingHistoryCheckpointCoreSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_LISTING_HISTORY_CHECKPOINT_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: ReleaseIdSchema,
    profileId: primitives_1.NonEmptyStringSchema,
    sourceId: ListingSourceSchema,
    historyResponsibility: ListingHistoryResponsibilitySchema,
    status: zod_1.z.enum([
        "BOOTSTRAP_IN_PROGRESS",
        "BOOTSTRAP_COMPLETE",
        "INCREMENTAL_CURRENT",
    ]),
    generatedAt: primitives_1.IsoDateTimeSchema,
    sourceCutoff: primitives_1.IsoDateTimeSchema,
    bootstrapCutoff: primitives_1.IsoDateTimeSchema,
    nextBootstrapRequestToken: primitives_1.NonEmptyStringSchema.nullable(),
    providerHistoryComplete: zod_1.z.boolean(),
    providerWindowComplete: zod_1.z.boolean(),
    pageCount: primitives_1.NonNegativeIntegerSchema,
    announcementCount: primitives_1.NonNegativeIntegerSchema,
    duplicateObservationCount: primitives_1.NonNegativeIntegerSchema,
    lastIncrementalOverlapCount: primitives_1.NonNegativeIntegerSchema,
    newestProviderPublishedAt: primitives_1.IsoDateTimeSchema.nullable(),
    oldestProviderPublishedAt: primitives_1.IsoDateTimeSchema.nullable(),
    pageChainHeadHash: DigestSchema,
    pageIds: UniqueStringsSchema,
    observations: zod_1.z.array(listing_lifecycle_contract_1.M1ListingAnnouncementObservationSchema),
    authorityBoundary: zod_1.z.literal("LISTING_HISTORY_ONLY_NO_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY"),
    runtimeExecutionAllowed: zod_1.z.literal(false),
    candidateEmissionAllowed: zod_1.z.literal(false),
    strategyAuthorityGranted: zod_1.z.literal(false),
    readyAuthorityGranted: zod_1.z.literal(false),
    productionChanged: zod_1.z.literal(false),
});
exports.M1ListingHistoryCheckpointSchema = ListingHistoryCheckpointCoreSchema.extend({
    checkpointId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
}).superRefine((checkpoint, context) => {
    var _a, _b, _c, _d;
    if (Date.parse(checkpoint.sourceCutoff) > Date.parse(checkpoint.generatedAt) ||
        Date.parse(checkpoint.bootstrapCutoff) >
            Date.parse(checkpoint.sourceCutoff)) {
        context.addIssue({
            code: "custom",
            message: "listing checkpoint chronology is invalid",
            path: ["sourceCutoff"],
        });
    }
    const complete = checkpoint.status !== "BOOTSTRAP_IN_PROGRESS";
    if (complete === (checkpoint.nextBootstrapRequestToken !== null)) {
        context.addIssue({
            code: "custom",
            message: "bootstrap completion and next token disagree",
            path: ["nextBootstrapRequestToken"],
        });
    }
    if (checkpoint.sourceId === "BYBIT_DERIVATIVES" &&
        (checkpoint.providerHistoryComplete !== complete ||
            checkpoint.providerWindowComplete)) {
        context.addIssue({
            code: "custom",
            message: "Bybit checkpoint history boundary is overstated",
            path: ["providerHistoryComplete"],
        });
    }
    if (checkpoint.sourceId === "BITGET_FUTURES" &&
        (checkpoint.providerHistoryComplete ||
            checkpoint.providerWindowComplete !== complete)) {
        context.addIssue({
            code: "custom",
            message: "Bitget one-month window cannot claim full history",
            path: ["providerWindowComplete"],
        });
    }
    if (checkpoint.pageCount !== checkpoint.pageIds.length ||
        checkpoint.announcementCount !== checkpoint.observations.length) {
        context.addIssue({
            code: "custom",
            message: "checkpoint page or announcement denominator drifted",
        });
    }
    const ids = checkpoint.observations.map((observation) => observation.announcementId);
    if (new Set(ids).size !== ids.length) {
        context.addIssue({
            code: "custom",
            message: "checkpoint announcements must be unique",
            path: ["observations"],
        });
    }
    const sorted = sortObservations(checkpoint.observations);
    if (checkpoint.observations.some((observation, index) => (0, stable_artifact_1.stableContentHash)(observation) !== (0, stable_artifact_1.stableContentHash)(sorted[index]))) {
        context.addIssue({
            code: "custom",
            message: "checkpoint observations require canonical ordering",
            path: ["observations"],
        });
    }
    const newest = (_b = (_a = checkpoint.observations[0]) === null || _a === void 0 ? void 0 : _a.providerPublishedAt) !== null && _b !== void 0 ? _b : null;
    const oldest = (_d = (_c = checkpoint.observations.at(-1)) === null || _c === void 0 ? void 0 : _c.providerPublishedAt) !== null && _d !== void 0 ? _d : null;
    if (checkpoint.newestProviderPublishedAt !== newest ||
        checkpoint.oldestProviderPublishedAt !== oldest) {
        context.addIssue({
            code: "custom",
            message: "checkpoint time bounds do not match observations",
        });
    }
    const expectedHash = (0, stable_artifact_1.stableContentHash)(listingHistoryCheckpointCore(checkpoint));
    if (checkpoint.contentHash !== expectedHash) {
        context.addIssue({
            code: "custom",
            message: "listing history checkpoint content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (checkpoint.checkpointId !==
        `listing-history-checkpoint:${checkpoint.sourceId}:${expectedHash.slice(7, 23)}`) {
        context.addIssue({
            code: "custom",
            message: "listing history checkpoint id mismatch",
            path: ["checkpointId"],
        });
    }
});
function listingHistoryCheckpointCore(checkpoint) {
    return ListingHistoryCheckpointCoreSchema.parse({
        schemaVersion: checkpoint.schemaVersion,
        scopeEpoch: checkpoint.scopeEpoch,
        releaseId: checkpoint.releaseId,
        profileId: checkpoint.profileId,
        sourceId: checkpoint.sourceId,
        historyResponsibility: checkpoint.historyResponsibility,
        status: checkpoint.status,
        generatedAt: checkpoint.generatedAt,
        sourceCutoff: checkpoint.sourceCutoff,
        bootstrapCutoff: checkpoint.bootstrapCutoff,
        nextBootstrapRequestToken: checkpoint.nextBootstrapRequestToken,
        providerHistoryComplete: checkpoint.providerHistoryComplete,
        providerWindowComplete: checkpoint.providerWindowComplete,
        pageCount: checkpoint.pageCount,
        announcementCount: checkpoint.announcementCount,
        duplicateObservationCount: checkpoint.duplicateObservationCount,
        lastIncrementalOverlapCount: checkpoint.lastIncrementalOverlapCount,
        newestProviderPublishedAt: checkpoint.newestProviderPublishedAt,
        oldestProviderPublishedAt: checkpoint.oldestProviderPublishedAt,
        pageChainHeadHash: checkpoint.pageChainHeadHash,
        pageIds: checkpoint.pageIds,
        observations: checkpoint.observations,
        authorityBoundary: checkpoint.authorityBoundary,
        runtimeExecutionAllowed: checkpoint.runtimeExecutionAllowed,
        candidateEmissionAllowed: checkpoint.candidateEmissionAllowed,
        strategyAuthorityGranted: checkpoint.strategyAuthorityGranted,
        readyAuthorityGranted: checkpoint.readyAuthorityGranted,
        productionChanged: checkpoint.productionChanged,
    });
}
function sortObservations(observations) {
    return [...observations].sort((left, right) => right.providerPublishedAt.localeCompare(left.providerPublishedAt) ||
        left.announcementId.localeCompare(right.announcementId));
}
const ListingHistoryGapCoreSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_LISTING_HISTORY_GAP_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: ReleaseIdSchema,
    profileId: primitives_1.NonEmptyStringSchema,
    sourceId: ListingSourceSchema,
    mode: ListingModeSchema,
    detectedAt: primitives_1.IsoDateTimeSchema,
    reason: zod_1.z.enum(exports.M1_LISTING_HISTORY_GAP_REASONS),
    expectedRequestToken: primitives_1.NonEmptyStringSchema.nullable(),
    observedRequestToken: primitives_1.NonEmptyStringSchema.nullable(),
    priorCheckpointHash: DigestSchema.nullable(),
    pageEvidenceHash: DigestSchema,
    checkpointAdvanced: zod_1.z.literal(false),
    candidateEmissionAllowed: zod_1.z.literal(false),
    strategyAuthorityGranted: zod_1.z.literal(false),
    readyAuthorityGranted: zod_1.z.literal(false),
    productionChanged: zod_1.z.literal(false),
});
exports.M1ListingHistoryGapSchema = ListingHistoryGapCoreSchema.extend({
    gapId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
}).superRefine((gap, context) => {
    const expectedHash = (0, stable_artifact_1.stableContentHash)(listingHistoryGapCore(gap));
    if (gap.contentHash !== expectedHash) {
        context.addIssue({
            code: "custom",
            message: "listing history gap content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (gap.gapId !==
        `listing-history-gap:${gap.sourceId}:${expectedHash.slice(7, 23)}`) {
        context.addIssue({
            code: "custom",
            message: "listing history gap id mismatch",
            path: ["gapId"],
        });
    }
});
function listingHistoryGapCore(gap) {
    return ListingHistoryGapCoreSchema.parse({
        schemaVersion: gap.schemaVersion,
        scopeEpoch: gap.scopeEpoch,
        releaseId: gap.releaseId,
        profileId: gap.profileId,
        sourceId: gap.sourceId,
        mode: gap.mode,
        detectedAt: gap.detectedAt,
        reason: gap.reason,
        expectedRequestToken: gap.expectedRequestToken,
        observedRequestToken: gap.observedRequestToken,
        priorCheckpointHash: gap.priorCheckpointHash,
        pageEvidenceHash: gap.pageEvidenceHash,
        checkpointAdvanced: gap.checkpointAdvanced,
        candidateEmissionAllowed: gap.candidateEmissionAllowed,
        strategyAuthorityGranted: gap.strategyAuthorityGranted,
        readyAuthorityGranted: gap.readyAuthorityGranted,
        productionChanged: gap.productionChanged,
    });
}
exports.M1ListingHistoryAdvanceResultSchema = zod_1.z.discriminatedUnion("status", [
    zod_1.z.strictObject({
        status: zod_1.z.literal("COMMITTED"),
        checkpoint: exports.M1ListingHistoryCheckpointSchema,
        gap: zod_1.z.null(),
    }),
    zod_1.z.strictObject({
        status: zod_1.z.literal("BLOCKED_GAP"),
        checkpoint: zod_1.z.null(),
        gap: exports.M1ListingHistoryGapSchema,
    }),
]);
function blockedGap(input) {
    var _a, _b;
    const core = listingHistoryGapCore({
        schemaVersion: exports.M1_LISTING_HISTORY_GAP_VERSION,
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        releaseId: input.profile.runtimeReleaseId,
        profileId: input.profile.profileId,
        sourceId: input.profile.sourceId,
        mode: input.mode,
        detectedAt: input.detectedAt,
        reason: input.reason,
        expectedRequestToken: input.expectedRequestToken,
        observedRequestToken: input.observedRequestToken,
        priorCheckpointHash: (_b = (_a = input.priorCheckpoint) === null || _a === void 0 ? void 0 : _a.contentHash) !== null && _b !== void 0 ? _b : null,
        pageEvidenceHash: (0, stable_artifact_1.stableContentHash)(input.pages.map((page) => page.contentHash)),
        checkpointAdvanced: false,
        candidateEmissionAllowed: false,
        strategyAuthorityGranted: false,
        readyAuthorityGranted: false,
        productionChanged: false,
    });
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    const gap = exports.M1ListingHistoryGapSchema.parse(Object.assign(Object.assign({}, core), { gapId: `listing-history-gap:${core.sourceId}:${contentHash.slice(7, 23)}`, contentHash }));
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1ListingHistoryAdvanceResultSchema.parse({
        status: "BLOCKED_GAP",
        checkpoint: null,
        gap,
    }));
}
function advanceM1ListingHistory(input) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
    validateListingProfile(input.profile);
    primitives_1.IsoDateTimeSchema.parse(input.generatedAt);
    primitives_1.IsoDateTimeSchema.parse(input.sourceCutoff);
    const prior = input.priorCheckpoint === null
        ? null
        : exports.M1ListingHistoryCheckpointSchema.parse(input.priorCheckpoint);
    const pages = input.pages.map((page) => exports.M1ListingHistoryPageSchema.parse(page));
    if (pages.length === 0) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "INVALID_SEGMENT_STOP", expectedRequestToken: null, observedRequestToken: null, detectedAt: input.generatedAt }));
    }
    if (pages.length > input.profile.maxRequestsPerSegment) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "INVALID_SEGMENT_STOP", expectedRequestToken: null, observedRequestToken: pages[0].requestToken, detectedAt: input.generatedAt }));
    }
    if (prior !== null &&
        (prior.releaseId !== input.profile.runtimeReleaseId ||
            prior.profileId !== input.profile.profileId ||
            prior.sourceId !== input.profile.sourceId)) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "SOURCE_OR_PROFILE_DRIFT", expectedRequestToken: null, observedRequestToken: pages[0].requestToken, detectedAt: input.generatedAt }));
    }
    const expectedFirstToken = input.mode === "INCREMENTAL"
        ? input.profile.sourceId === "BYBIT_DERIVATIVES"
            ? "page:1"
            : "ROOT"
        : (_a = prior === null || prior === void 0 ? void 0 : prior.nextBootstrapRequestToken) !== null && _a !== void 0 ? _a : (input.profile.sourceId === "BYBIT_DERIVATIVES" ? "page:1" : "ROOT");
    if (pages[0].requestToken !== expectedFirstToken) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "REQUEST_TOKEN_DISCONTINUITY", expectedRequestToken: expectedFirstToken, observedRequestToken: pages[0].requestToken, detectedAt: input.generatedAt }));
    }
    const requestTokens = pages.map((page) => page.requestToken);
    if (new Set(requestTokens).size !== requestTokens.length) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "REPEATED_REQUEST_TOKEN", expectedRequestToken: null, observedRequestToken: null, detectedAt: input.generatedAt }));
    }
    for (let index = 0; index < pages.length; index += 1) {
        const page = pages[index];
        if (page.pageOrdinal !== index + 1) {
            return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "PAGE_ORDINAL_DISCONTINUITY", expectedRequestToken: String(index + 1), observedRequestToken: String(page.pageOrdinal), detectedAt: input.generatedAt }));
        }
        if (page.releaseId !== input.profile.runtimeReleaseId ||
            page.profileId !== input.profile.profileId ||
            page.sourceId !== input.profile.sourceId ||
            page.mode !== input.mode) {
            return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "SOURCE_OR_PROFILE_DRIFT", expectedRequestToken: null, observedRequestToken: page.requestToken, detectedAt: input.generatedAt }));
        }
        if (Date.parse(page.receivedAt) > Date.parse(input.sourceCutoff)) {
            return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "FUTURE_KNOWLEDGE", expectedRequestToken: null, observedRequestToken: page.requestToken, detectedAt: input.generatedAt }));
        }
        if (page.rawRecordCount === 0 &&
            !page.providerTerminal) {
            return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "EMPTY_NONTERMINAL_PAGE", expectedRequestToken: null, observedRequestToken: page.requestToken, detectedAt: input.generatedAt }));
        }
        const next = pages[index + 1];
        if (next !== undefined &&
            page.nextRequestToken !== next.requestToken) {
            return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "REQUEST_TOKEN_DISCONTINUITY", expectedRequestToken: page.nextRequestToken, observedRequestToken: next.requestToken, detectedAt: input.generatedAt }));
        }
    }
    if (input.mode === "BOOTSTRAP" &&
        prior !== null &&
        prior.status !== "BOOTSTRAP_IN_PROGRESS") {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "INVALID_SEGMENT_STOP", expectedRequestToken: null, observedRequestToken: pages[0].requestToken, detectedAt: input.generatedAt }));
    }
    if (input.mode === "INCREMENTAL" &&
        (prior === null ||
            prior.status === "BOOTSTRAP_IN_PROGRESS")) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "INVALID_SEGMENT_STOP", expectedRequestToken: null, observedRequestToken: pages[0].requestToken, detectedAt: input.generatedAt }));
    }
    const priorById = new Map(((_b = prior === null || prior === void 0 ? void 0 : prior.observations) !== null && _b !== void 0 ? _b : []).map((observation) => [
        observation.announcementId,
        observation,
    ]));
    const mergedById = new Map(priorById);
    let duplicateObservationCount = (_c = prior === null || prior === void 0 ? void 0 : prior.duplicateObservationCount) !== null && _c !== void 0 ? _c : 0;
    let overlapCount = 0;
    for (const page of pages) {
        for (const observation of page.observations) {
            const existing = mergedById.get(observation.announcementId);
            if (existing === undefined) {
                mergedById.set(observation.announcementId, observation);
                continue;
            }
            if (existing.sourceRecordDigest !== observation.sourceRecordDigest) {
                return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "ANNOUNCEMENT_ID_CONTENT_CONFLICT", expectedRequestToken: null, observedRequestToken: page.requestToken, detectedAt: input.generatedAt }));
            }
            duplicateObservationCount += 1;
            if (priorById.has(observation.announcementId))
                overlapCount += 1;
        }
    }
    const lastPage = pages.at(-1);
    if (input.segmentStop === "SOURCE_TERMINAL" &&
        !lastPage.providerTerminal) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "INVALID_SEGMENT_STOP", expectedRequestToken: lastPage.nextRequestToken, observedRequestToken: null, detectedAt: input.generatedAt }));
    }
    if (input.segmentStop === "SEGMENT_PAGE_LIMIT" &&
        lastPage.providerTerminal) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "INVALID_SEGMENT_STOP", expectedRequestToken: null, observedRequestToken: lastPage.requestToken, detectedAt: input.generatedAt }));
    }
    if (input.mode === "INCREMENTAL" &&
        prior !== null &&
        prior.announcementCount > 0 &&
        (overlapCount === 0 ||
            input.segmentStop !== "PRIOR_CHECKPOINT_OVERLAP")) {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "NO_CHECKPOINT_OVERLAP", expectedRequestToken: null, observedRequestToken: lastPage.requestToken, detectedAt: input.generatedAt }));
    }
    if (input.mode === "BOOTSTRAP" &&
        input.segmentStop === "PRIOR_CHECKPOINT_OVERLAP") {
        return blockedGap(Object.assign(Object.assign({}, input), { priorCheckpoint: prior, pages, reason: "INVALID_SEGMENT_STOP", expectedRequestToken: null, observedRequestToken: lastPage.requestToken, detectedAt: input.generatedAt }));
    }
    const bootstrapComplete = input.mode === "INCREMENTAL" ||
        input.segmentStop === "SOURCE_TERMINAL";
    const observations = sortObservations([...mergedById.values()]);
    const status = input.mode === "INCREMENTAL"
        ? "INCREMENTAL_CURRENT"
        : bootstrapComplete
            ? "BOOTSTRAP_COMPLETE"
            : "BOOTSTRAP_IN_PROGRESS";
    const pageIds = [
        ...((_d = prior === null || prior === void 0 ? void 0 : prior.pageIds) !== null && _d !== void 0 ? _d : []),
        ...pages.map((page) => page.pageId),
    ];
    const pageChainHeadHash = (0, stable_artifact_1.stableContentHash)({
        previous: (_e = prior === null || prior === void 0 ? void 0 : prior.pageChainHeadHash) !== null && _e !== void 0 ? _e : null,
        pages: pages.map((page) => page.contentHash),
    });
    const core = listingHistoryCheckpointCore({
        schemaVersion: exports.M1_LISTING_HISTORY_CHECKPOINT_VERSION,
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        releaseId: input.profile.runtimeReleaseId,
        profileId: input.profile.profileId,
        sourceId: input.profile.sourceId,
        historyResponsibility: input.profile.historyResponsibility,
        status,
        generatedAt: input.generatedAt,
        sourceCutoff: input.sourceCutoff,
        bootstrapCutoff: (_f = prior === null || prior === void 0 ? void 0 : prior.bootstrapCutoff) !== null && _f !== void 0 ? _f : input.sourceCutoff,
        nextBootstrapRequestToken: status === "BOOTSTRAP_IN_PROGRESS"
            ? lastPage.nextRequestToken
            : null,
        providerHistoryComplete: input.profile.sourceId === "BYBIT_DERIVATIVES" &&
            status !== "BOOTSTRAP_IN_PROGRESS",
        providerWindowComplete: input.profile.sourceId === "BITGET_FUTURES" &&
            status !== "BOOTSTRAP_IN_PROGRESS",
        pageCount: pageIds.length,
        announcementCount: observations.length,
        duplicateObservationCount,
        lastIncrementalOverlapCount: input.mode === "INCREMENTAL" ? overlapCount : 0,
        newestProviderPublishedAt: (_h = (_g = observations[0]) === null || _g === void 0 ? void 0 : _g.providerPublishedAt) !== null && _h !== void 0 ? _h : null,
        oldestProviderPublishedAt: (_k = (_j = observations.at(-1)) === null || _j === void 0 ? void 0 : _j.providerPublishedAt) !== null && _k !== void 0 ? _k : null,
        pageChainHeadHash,
        pageIds,
        observations,
        authorityBoundary: "LISTING_HISTORY_ONLY_NO_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY",
        runtimeExecutionAllowed: false,
        candidateEmissionAllowed: false,
        strategyAuthorityGranted: false,
        readyAuthorityGranted: false,
        productionChanged: false,
    });
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    const checkpoint = exports.M1ListingHistoryCheckpointSchema.parse(Object.assign(Object.assign({}, core), { checkpointId: `listing-history-checkpoint:${core.sourceId}:${contentHash.slice(7, 23)}`, contentHash }));
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1ListingHistoryAdvanceResultSchema.parse({
        status: "COMMITTED",
        checkpoint,
        gap: null,
    }));
}
