"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.M1MultiAssetIdentitySnapshotSchema = exports.M1MultiAssetInstrumentObservationSchema = exports.M1OfficialUnderlyingMappingSchema = exports.M1_JURISDICTION_AVAILABILITY_STATES = exports.M1_IDENTITY_STATUSES = exports.M1_CLASSIFICATION_AUTHORITIES = exports.M1_LISTING_LIFECYCLE_STATES = exports.M1_CONTRACT_MECHANISMS = exports.M1_COVERAGE_CLASSES = exports.M1_DERIVATIVE_ASSET_DOMAINS = exports.M1_MULTI_ASSET_IDENTITY_SNAPSHOT_VERSION = exports.M1_MULTI_ASSET_IDENTITY_VERSION = void 0;
exports.deriveM1ListingEpoch = deriveM1ListingEpoch;
exports.deriveM1IdentityEpoch = deriveM1IdentityEpoch;
exports.deriveM1CanonicalInstrumentId = deriveM1CanonicalInstrumentId;
exports.deriveM1UnderlyingGroupId = deriveM1UnderlyingGroupId;
exports.createM1MultiAssetObservation = createM1MultiAssetObservation;
exports.buildM1MultiAssetIdentitySnapshot = buildM1MultiAssetIdentitySnapshot;
const zod_1 = require("zod");
const primitives_1 = require("../../runtime-schema/primitives");
const source_capability_contract_1 = require("../source-capability/source-capability-contract");
const stable_artifact_1 = require("../universe/stable-artifact");
exports.M1_MULTI_ASSET_IDENTITY_VERSION = "v2-m1-multi-asset-identity.v1";
exports.M1_MULTI_ASSET_IDENTITY_SNAPSHOT_VERSION = "v2-m1-multi-asset-identity-snapshot.v1";
exports.M1_DERIVATIVE_ASSET_DOMAINS = [
    "CRYPTO_LINEAR_PERPETUAL",
    "EQUITY_SINGLE_NAME_PERPETUAL",
    "EQUITY_INDEX_ETF_PERPETUAL",
    "EQUITY_CFD",
    "OTHER_RWA_DERIVATIVE",
];
exports.M1_COVERAGE_CLASSES = [
    "SUPPORTED_DERIVATIVE",
    "ASSET_LISTING_WATCH",
];
exports.M1_CONTRACT_MECHANISMS = [
    "LINEAR_PERPETUAL",
    "EQUITY_CFD",
    "UNKNOWN_DERIVATIVE",
    "NONE_ASSET_WATCH",
];
exports.M1_LISTING_LIFECYCLE_STATES = [
    "ANNOUNCED_WAITING_CATALOG",
    "OBSERVED_UNCONFIRMED",
    "PRE_LAUNCH_OR_PREOPEN",
    "TRADING_WARMUP",
    "ESTABLISHED",
    "MAINTENANCE",
    "RESTRICTED",
    "SUSPENDED",
    "DELISTING",
    "OFFLINE",
    "UNRESOLVED",
];
exports.M1_CLASSIFICATION_AUTHORITIES = [
    "PROVIDER_EXPLICIT_CATEGORY",
    "PROVIDER_NEGATIVE_RWA_FLAG",
    "OFFICIAL_PRODUCT_MAPPING",
    "UNRESOLVED",
];
exports.M1_IDENTITY_STATUSES = [
    "EXACT",
    "PARTIAL",
    "UNRESOLVED",
];
exports.M1_JURISDICTION_AVAILABILITY_STATES = [
    "UNVERIFIED",
    "AVAILABLE",
    "RESTRICTED",
    "UNAVAILABLE",
];
const DigestSchema = zod_1.z.string().regex(/^sha256:[0-9a-f]{64}$/u);
const VenueSchema = zod_1.z.enum(source_capability_contract_1.M1_VENUE_SOURCE_IDS);
const DerivativeAssetDomainSchema = zod_1.z.enum(exports.M1_DERIVATIVE_ASSET_DOMAINS);
const AssetDomainSchema = zod_1.z.enum(source_capability_contract_1.M1_ASSET_DOMAINS);
const UniqueNonEmptyStringsSchema = zod_1.z.array(primitives_1.NonEmptyStringSchema)
    .superRefine((values, context) => {
    if (new Set(values).size !== values.length) {
        context.addIssue({
            code: "custom",
            message: "values must be unique",
        });
    }
});
exports.M1OfficialUnderlyingMappingSchema = zod_1.z.strictObject({
    sourceId: VenueSchema,
    venueInstrumentId: primitives_1.NonEmptyStringSchema,
    assetDomain: DerivativeAssetDomainSchema,
    underlyingReferenceId: primitives_1.NonEmptyStringSchema,
    evidenceIds: UniqueNonEmptyStringsSchema.min(1),
    reviewedAt: primitives_1.IsoDateTimeSchema,
    expiresAt: primitives_1.IsoDateTimeSchema,
}).superRefine((mapping, context) => {
    if (Date.parse(mapping.reviewedAt) >= Date.parse(mapping.expiresAt)) {
        context.addIssue({
            code: "custom",
            message: "official mapping expiry must be later than review time",
            path: ["expiresAt"],
        });
    }
    if (![
        "EQUITY_SINGLE_NAME_PERPETUAL",
        "EQUITY_INDEX_ETF_PERPETUAL",
        "OTHER_RWA_DERIVATIVE",
    ].includes(mapping.assetDomain)) {
        context.addIssue({
            code: "custom",
            message: "official mapping is reserved for exact RWA classification",
            path: ["assetDomain"],
        });
    }
});
exports.M1MultiAssetInstrumentObservationSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_MULTI_ASSET_IDENTITY_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    coverageClass: zod_1.z.enum(exports.M1_COVERAGE_CLASSES),
    assetDomain: AssetDomainSchema.nullable(),
    sourceId: VenueSchema,
    venueInstrumentId: primitives_1.NonEmptyStringSchema,
    canonicalInstrumentId: primitives_1.NonEmptyStringSchema.nullable(),
    underlyingGroupId: primitives_1.NonEmptyStringSchema.nullable(),
    underlyingReferenceId: primitives_1.NonEmptyStringSchema.nullable(),
    baseAsset: primitives_1.NonEmptyStringSchema.nullable(),
    quoteAsset: primitives_1.NonEmptyStringSchema.nullable(),
    settlementAsset: primitives_1.NonEmptyStringSchema.nullable(),
    contractMechanism: zod_1.z.enum(exports.M1_CONTRACT_MECHANISMS),
    contractMultiplier: primitives_1.PositiveDecimalStringSchema.nullable(),
    priceTick: primitives_1.PositiveDecimalStringSchema.nullable(),
    quantityStep: primitives_1.PositiveDecimalStringSchema.nullable(),
    listingEpoch: primitives_1.NonEmptyStringSchema,
    identityEpoch: primitives_1.NonEmptyStringSchema,
    identityStatus: zod_1.z.enum(exports.M1_IDENTITY_STATUSES),
    classificationAuthority: zod_1.z.enum(exports.M1_CLASSIFICATION_AUTHORITIES),
    classificationEvidenceIds: UniqueNonEmptyStringsSchema,
    providerStatus: primitives_1.NonEmptyStringSchema,
    lifecycleState: zod_1.z.enum(exports.M1_LISTING_LIFECYCLE_STATES),
    providerListTime: primitives_1.IsoDateTimeSchema.nullable(),
    providerDelistTime: primitives_1.IsoDateTimeSchema.nullable(),
    firstObservedAt: primitives_1.IsoDateTimeSchema,
    statusEffectiveAt: primitives_1.IsoDateTimeSchema.nullable(),
    knowledgeTime: primitives_1.IsoDateTimeSchema,
    jurisdictionAvailability: zod_1.z.enum(exports.M1_JURISDICTION_AVAILABILITY_STATES),
    sourceCapability: zod_1.z.literal("DERIVATIVE_INSTRUMENT_CATALOG"),
    sourceRecordDigest: DigestSchema,
    runtimeEligibility: zod_1.z.literal("NOT_EVALUATED_NO_AUTHORITY"),
    candidateEmissionAllowed: zod_1.z.literal(false),
    strategyAuthority: zod_1.z.literal(false),
    reasonCodes: primitives_1.ReasonCodesSchema,
}).superRefine((observation, context) => {
    const firstObservedAt = Date.parse(observation.firstObservedAt);
    const knowledgeTime = Date.parse(observation.knowledgeTime);
    if (firstObservedAt > knowledgeTime) {
        context.addIssue({
            code: "custom",
            message: "firstObservedAt cannot be later than knowledgeTime",
            path: ["firstObservedAt"],
        });
    }
    const isWatch = observation.coverageClass === "ASSET_LISTING_WATCH";
    if (isWatch &&
        (observation.assetDomain !== "ASSET_LISTING_WATCH" ||
            observation.contractMechanism !== "NONE_ASSET_WATCH" ||
            observation.canonicalInstrumentId !== null)) {
        context.addIssue({
            code: "custom",
            message: "listing watch rows cannot masquerade as derivative identities",
            path: ["coverageClass"],
        });
    }
    if (!isWatch &&
        observation.assetDomain !== null &&
        !exports.M1_DERIVATIVE_ASSET_DOMAINS.includes(observation.assetDomain)) {
        context.addIssue({
            code: "custom",
            message: "derivative coverage requires a derivative asset domain",
            path: ["assetDomain"],
        });
    }
    const completeIdentity = [
        observation.assetDomain,
        observation.canonicalInstrumentId,
        observation.baseAsset,
        observation.quoteAsset,
        observation.settlementAsset,
        observation.contractMultiplier,
        observation.priceTick,
        observation.quantityStep,
    ].every((value) => value !== null);
    if (observation.identityStatus === "EXACT" && !completeIdentity) {
        context.addIssue({
            code: "custom",
            message: "exact identity requires every material identity field",
            path: ["identityStatus"],
        });
    }
    if (observation.identityStatus === "UNRESOLVED" &&
        (observation.canonicalInstrumentId !== null ||
            observation.reasonCodes.length === 0)) {
        context.addIssue({
            code: "custom",
            message: "unresolved identity requires null canonical id and reasons",
            path: ["identityStatus"],
        });
    }
    if (observation.classificationAuthority === "OFFICIAL_PRODUCT_MAPPING" &&
        observation.classificationEvidenceIds.length === 0) {
        context.addIssue({
            code: "custom",
            message: "official product mapping requires evidence ids",
            path: ["classificationEvidenceIds"],
        });
    }
    if (observation.classificationAuthority === "UNRESOLVED" &&
        observation.assetDomain !== null) {
        context.addIssue({
            code: "custom",
            message: "unresolved classification cannot claim an asset domain",
            path: ["assetDomain"],
        });
    }
});
const CountByVenueSchema = zod_1.z.strictObject({
    BINANCE_FUTURES: primitives_1.NonNegativeIntegerSchema,
    OKX_SWAP: primitives_1.NonNegativeIntegerSchema,
    BYBIT_DERIVATIVES: primitives_1.NonNegativeIntegerSchema,
    BITGET_FUTURES: primitives_1.NonNegativeIntegerSchema,
});
const CountByAssetDomainSchema = zod_1.z.strictObject({
    CRYPTO_LINEAR_PERPETUAL: primitives_1.NonNegativeIntegerSchema,
    EQUITY_SINGLE_NAME_PERPETUAL: primitives_1.NonNegativeIntegerSchema,
    EQUITY_INDEX_ETF_PERPETUAL: primitives_1.NonNegativeIntegerSchema,
    EQUITY_CFD: primitives_1.NonNegativeIntegerSchema,
    OTHER_RWA_DERIVATIVE: primitives_1.NonNegativeIntegerSchema,
    ASSET_LISTING_WATCH: primitives_1.NonNegativeIntegerSchema,
    CROSS_MARKET_CONTEXT: zod_1.z.literal(0),
    UNRESOLVED: primitives_1.NonNegativeIntegerSchema,
});
exports.M1MultiAssetIdentitySnapshotSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_MULTI_ASSET_IDENTITY_SNAPSHOT_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: primitives_1.NonEmptyStringSchema,
    generatedAt: primitives_1.IsoDateTimeSchema,
    sourceCutoff: primitives_1.IsoDateTimeSchema,
    registryDigest: DigestSchema,
    snapshotId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
    venueDenominator: zod_1.z.literal(4),
    observedCount: primitives_1.NonNegativeIntegerSchema,
    exactIdentityCount: primitives_1.NonNegativeIntegerSchema,
    unresolvedIdentityCount: primitives_1.NonNegativeIntegerSchema,
    countsByVenue: CountByVenueSchema,
    countsByAssetDomain: CountByAssetDomainSchema,
    observations: zod_1.z.array(exports.M1MultiAssetInstrumentObservationSchema),
    authorityBoundary: zod_1.z.literal("IDENTITY_AND_LISTING_GOVERNANCE_ONLY_NO_ELIGIBLE_FACT_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY"),
    productionChanged: zod_1.z.literal(false),
}).superRefine((snapshot, context) => {
    var _a;
    if (Date.parse(snapshot.sourceCutoff) > Date.parse(snapshot.generatedAt)) {
        context.addIssue({
            code: "custom",
            message: "sourceCutoff cannot be later than generatedAt",
            path: ["sourceCutoff"],
        });
    }
    if (snapshot.observedCount !== snapshot.observations.length) {
        context.addIssue({
            code: "custom",
            message: "observedCount must equal observations length",
            path: ["observedCount"],
        });
    }
    const exact = snapshot.observations.filter((observation) => observation.identityStatus === "EXACT").length;
    const unresolved = snapshot.observations.filter((observation) => observation.identityStatus === "UNRESOLVED").length;
    if (snapshot.exactIdentityCount !== exact) {
        context.addIssue({
            code: "custom",
            message: "exactIdentityCount does not match observations",
            path: ["exactIdentityCount"],
        });
    }
    if (snapshot.unresolvedIdentityCount !== unresolved) {
        context.addIssue({
            code: "custom",
            message: "unresolvedIdentityCount does not match observations",
            path: ["unresolvedIdentityCount"],
        });
    }
    const rowKeys = snapshot.observations.map((observation) => `${observation.sourceId}:${observation.venueInstrumentId}:${observation.listingEpoch}`);
    if (new Set(rowKeys).size !== rowKeys.length) {
        context.addIssue({
            code: "custom",
            message: "source instrument listing epoch rows must be unique",
            path: ["observations"],
        });
    }
    const currentInstrumentKeys = snapshot.observations.map((observation) => `${observation.sourceId}:${observation.venueInstrumentId}`);
    if (new Set(currentInstrumentKeys).size !== currentInstrumentKeys.length) {
        context.addIssue({
            code: "custom",
            message: "a point-in-time snapshot cannot duplicate a venue instrument",
            path: ["observations"],
        });
    }
    const canonicalIds = snapshot.observations
        .map((observation) => observation.canonicalInstrumentId)
        .filter((value) => value !== null);
    if (new Set(canonicalIds).size !== canonicalIds.length) {
        context.addIssue({
            code: "custom",
            message: "canonical instrument ids must be unique",
            path: ["observations"],
        });
    }
    if (snapshot.observations.some((observation) => Date.parse(observation.knowledgeTime) > Date.parse(snapshot.sourceCutoff))) {
        context.addIssue({
            code: "custom",
            message: "observations cannot be known after sourceCutoff",
            path: ["observations"],
        });
    }
    const expectedVenueCounts = emptyVenueCounts();
    const expectedDomainCounts = emptyDomainCounts();
    for (const observation of snapshot.observations) {
        expectedVenueCounts[observation.sourceId] += 1;
        expectedDomainCounts[(_a = observation.assetDomain) !== null && _a !== void 0 ? _a : "UNRESOLVED"] += 1;
    }
    if ((0, stable_artifact_1.stableContentHash)(snapshot.countsByVenue) !==
        (0, stable_artifact_1.stableContentHash)(expectedVenueCounts)) {
        context.addIssue({
            code: "custom",
            message: "venue counts do not match observations",
            path: ["countsByVenue"],
        });
    }
    if ((0, stable_artifact_1.stableContentHash)(snapshot.countsByAssetDomain) !==
        (0, stable_artifact_1.stableContentHash)(expectedDomainCounts)) {
        context.addIssue({
            code: "custom",
            message: "asset-domain counts do not match observations",
            path: ["countsByAssetDomain"],
        });
    }
    const sorted = [...snapshot.observations].sort((left, right) => left.sourceId.localeCompare(right.sourceId) ||
        left.venueInstrumentId.localeCompare(right.venueInstrumentId) ||
        left.listingEpoch.localeCompare(right.listingEpoch));
    if (snapshot.observations.some((observation, index) => observation !== sorted[index] &&
        (0, stable_artifact_1.stableContentHash)(observation) !== (0, stable_artifact_1.stableContentHash)(sorted[index]))) {
        context.addIssue({
            code: "custom",
            message: "identity observations must use canonical ordering",
            path: ["observations"],
        });
    }
    const expectedContentHash = (0, stable_artifact_1.stableContentHash)({
        scopeEpoch: snapshot.scopeEpoch,
        releaseId: snapshot.releaseId,
        generatedAt: snapshot.generatedAt,
        sourceCutoff: snapshot.sourceCutoff,
        registryDigest: snapshot.registryDigest,
        venueDenominator: snapshot.venueDenominator,
        observedCount: snapshot.observedCount,
        exactIdentityCount: snapshot.exactIdentityCount,
        unresolvedIdentityCount: snapshot.unresolvedIdentityCount,
        countsByVenue: snapshot.countsByVenue,
        countsByAssetDomain: snapshot.countsByAssetDomain,
        observations: snapshot.observations,
        authorityBoundary: snapshot.authorityBoundary,
        productionChanged: snapshot.productionChanged,
    });
    if (snapshot.contentHash !== expectedContentHash) {
        context.addIssue({
            code: "custom",
            message: "identity snapshot content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (snapshot.snapshotId !==
        `multi-asset-identity:${snapshot.contentHash.slice(7, 31)}`) {
        context.addIssue({
            code: "custom",
            message: "identity snapshot id mismatch",
            path: ["snapshotId"],
        });
    }
});
function normalizeIdentityToken(value) {
    return value.trim().normalize("NFC").toUpperCase();
}
function deriveM1ListingEpoch(input) {
    var _a;
    const identityTime = (_a = input.providerListTime) !== null && _a !== void 0 ? _a : input.firstObservedAt;
    const digest = (0, stable_artifact_1.stableSha256)({
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        sourceId: input.sourceId,
        venueInstrumentId: normalizeIdentityToken(input.venueInstrumentId),
        identityTime,
    });
    return `listing:${digest.slice(0, 24)}`;
}
function deriveM1IdentityEpoch(input) {
    const digest = (0, stable_artifact_1.stableSha256)({
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        sourceId: input.sourceId,
        venueInstrumentId: normalizeIdentityToken(input.venueInstrumentId),
        listingEpoch: input.listingEpoch,
        assetDomain: input.assetDomain,
        underlyingReferenceId: input.underlyingReferenceId,
    });
    return `identity:${digest.slice(0, 24)}`;
}
function deriveM1CanonicalInstrumentId(input) {
    return [
        source_capability_contract_1.M1_SCOPE_EPOCH,
        input.sourceId,
        normalizeIdentityToken(input.venueInstrumentId),
        input.identityEpoch,
    ].join(":");
}
function deriveM1UnderlyingGroupId(input) {
    if (input.underlyingReferenceId === null || input.settlementAsset === null) {
        return null;
    }
    return [
        source_capability_contract_1.M1_SCOPE_EPOCH,
        input.assetDomain,
        normalizeIdentityToken(input.underlyingReferenceId),
        normalizeIdentityToken(input.settlementAsset),
    ].join(":");
}
function createM1MultiAssetObservation(input) {
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1MultiAssetInstrumentObservationSchema.parse(Object.assign(Object.assign({}, input), { schemaVersion: exports.M1_MULTI_ASSET_IDENTITY_VERSION, scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH, runtimeEligibility: "NOT_EVALUATED_NO_AUTHORITY", candidateEmissionAllowed: false, strategyAuthority: false })));
}
function emptyVenueCounts() {
    return {
        BINANCE_FUTURES: 0,
        OKX_SWAP: 0,
        BYBIT_DERIVATIVES: 0,
        BITGET_FUTURES: 0,
    };
}
function emptyDomainCounts() {
    return {
        CRYPTO_LINEAR_PERPETUAL: 0,
        EQUITY_SINGLE_NAME_PERPETUAL: 0,
        EQUITY_INDEX_ETF_PERPETUAL: 0,
        EQUITY_CFD: 0,
        OTHER_RWA_DERIVATIVE: 0,
        ASSET_LISTING_WATCH: 0,
        CROSS_MARKET_CONTEXT: 0,
        UNRESOLVED: 0,
    };
}
function stabilizeObservationAgainstPrevious(current, previous) {
    if (previous === null ||
        previous.sourceId !== current.sourceId ||
        previous.venueInstrumentId !== current.venueInstrumentId) {
        return current;
    }
    const currentListTime = current.providerListTime === null
        ? null
        : Date.parse(current.providerListTime);
    const preservePriorListingEpoch = currentListTime === null ||
        currentListTime <= Date.parse(previous.firstObservedAt);
    if (!preservePriorListingEpoch) {
        return current;
    }
    const identityEpoch = deriveM1IdentityEpoch({
        sourceId: current.sourceId,
        venueInstrumentId: current.venueInstrumentId,
        listingEpoch: previous.listingEpoch,
        assetDomain: current.assetDomain,
        underlyingReferenceId: current.underlyingReferenceId,
    });
    const canonicalInstrumentId = current.identityStatus === "EXACT"
        ? deriveM1CanonicalInstrumentId({
            sourceId: current.sourceId,
            venueInstrumentId: current.venueInstrumentId,
            identityEpoch,
        })
        : null;
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1MultiAssetInstrumentObservationSchema.parse(Object.assign(Object.assign({}, current), { listingEpoch: previous.listingEpoch, identityEpoch,
        canonicalInstrumentId, firstObservedAt: previous.firstObservedAt, reasonCodes: [...new Set([
                ...current.reasonCodes,
                "listing_epoch_preserved_from_prior_observation",
            ])].sort() })));
}
function buildM1MultiAssetIdentitySnapshot(input) {
    var _a, _b;
    const previous = input.previous === undefined || input.previous === null
        ? null
        : exports.M1MultiAssetIdentitySnapshotSchema.parse(input.previous);
    if (previous !== null &&
        (previous.registryDigest !== input.registryDigest ||
            Date.parse(previous.sourceCutoff) >= Date.parse(input.sourceCutoff))) {
        throw new Error("previous identity snapshot must use the same registry and an earlier cutoff");
    }
    const previousByInstrument = new Map(((_a = previous === null || previous === void 0 ? void 0 : previous.observations) !== null && _a !== void 0 ? _a : []).map((observation) => [
        `${observation.sourceId}:${observation.venueInstrumentId}`,
        observation,
    ]));
    const observations = input.observations.map((observation) => {
        var _a;
        return stabilizeObservationAgainstPrevious(observation, (_a = previousByInstrument.get(`${observation.sourceId}:${observation.venueInstrumentId}`)) !== null && _a !== void 0 ? _a : null);
    }).sort((left, right) => left.sourceId.localeCompare(right.sourceId) ||
        left.venueInstrumentId.localeCompare(right.venueInstrumentId) ||
        left.listingEpoch.localeCompare(right.listingEpoch));
    const countsByVenue = emptyVenueCounts();
    const countsByAssetDomain = emptyDomainCounts();
    for (const observation of observations) {
        countsByVenue[observation.sourceId] += 1;
        countsByAssetDomain[(_b = observation.assetDomain) !== null && _b !== void 0 ? _b : "UNRESOLVED"] += 1;
    }
    const core = {
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        releaseId: input.releaseId,
        generatedAt: input.generatedAt,
        sourceCutoff: input.sourceCutoff,
        registryDigest: input.registryDigest,
        venueDenominator: 4,
        observedCount: observations.length,
        exactIdentityCount: observations.filter((observation) => observation.identityStatus === "EXACT").length,
        unresolvedIdentityCount: observations.filter((observation) => observation.identityStatus === "UNRESOLVED").length,
        countsByVenue,
        countsByAssetDomain,
        observations,
        authorityBoundary: "IDENTITY_AND_LISTING_GOVERNANCE_ONLY_NO_ELIGIBLE_FACT_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY",
        productionChanged: false,
    };
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1MultiAssetIdentitySnapshotSchema.parse(Object.assign(Object.assign({}, core), { schemaVersion: exports.M1_MULTI_ASSET_IDENTITY_SNAPSHOT_VERSION, snapshotId: `multi-asset-identity:${contentHash.slice(7, 31)}`, contentHash })));
}
