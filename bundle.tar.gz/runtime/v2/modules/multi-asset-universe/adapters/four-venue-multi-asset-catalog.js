"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.binanceMultiAssetCatalogSchemaConforms = binanceMultiAssetCatalogSchemaConforms;
exports.okxMultiAssetCatalogSchemaConforms = okxMultiAssetCatalogSchemaConforms;
exports.bybitMultiAssetCatalogSchemaConforms = bybitMultiAssetCatalogSchemaConforms;
exports.bitgetMultiAssetCatalogSchemaConforms = bitgetMultiAssetCatalogSchemaConforms;
exports.normalizeBinanceMultiAssetCatalog = normalizeBinanceMultiAssetCatalog;
exports.normalizeOkxMultiAssetCatalog = normalizeOkxMultiAssetCatalog;
exports.normalizeBybitMultiAssetCatalog = normalizeBybitMultiAssetCatalog;
exports.normalizeBitgetMultiAssetCatalog = normalizeBitgetMultiAssetCatalog;
const zod_1 = require("zod");
const multi_asset_identity_contract_1 = require("../multi-asset-identity-contract");
const stable_artifact_1 = require("../../universe/stable-artifact");
const BinanceEnvelopeSchema = zod_1.z.object({
    symbols: zod_1.z.array(zod_1.z.unknown()),
}).passthrough();
const BinanceRowSchema = zod_1.z.object({
    symbol: zod_1.z.string(),
    baseAsset: zod_1.z.string(),
    quoteAsset: zod_1.z.string(),
    marginAsset: zod_1.z.string(),
    contractType: zod_1.z.string(),
    status: zod_1.z.string(),
    onboardDate: zod_1.z.union([zod_1.z.number(), zod_1.z.string()]).optional(),
    deliveryDate: zod_1.z.union([zod_1.z.number(), zod_1.z.string()]).optional(),
    underlyingType: zod_1.z.string().optional(),
    underlyingSubType: zod_1.z.array(zod_1.z.string()).optional(),
    filters: zod_1.z.array(zod_1.z.unknown()).optional(),
}).passthrough();
const OkxEnvelopeSchema = zod_1.z.object({
    code: zod_1.z.string(),
    data: zod_1.z.array(zod_1.z.unknown()),
}).passthrough();
const OkxRowSchema = zod_1.z.object({
    instId: zod_1.z.string(),
    instType: zod_1.z.string(),
    ctType: zod_1.z.string(),
    ctVal: zod_1.z.string(),
    ctValCcy: zod_1.z.string(),
    quoteCcy: zod_1.z.string().optional(),
    settleCcy: zod_1.z.string(),
    state: zod_1.z.string(),
    instCategory: zod_1.z.string().optional(),
    uly: zod_1.z.string().optional(),
    instFamily: zod_1.z.string().optional(),
    listTime: zod_1.z.string().optional(),
    expTime: zod_1.z.string().optional(),
    tickSz: zod_1.z.string().optional(),
    lotSz: zod_1.z.string().optional(),
    minSz: zod_1.z.string().optional(),
}).passthrough();
const BybitEnvelopeSchema = zod_1.z.object({
    retCode: zod_1.z.number().int(),
    result: zod_1.z.object({
        category: zod_1.z.string(),
        list: zod_1.z.array(zod_1.z.unknown()),
        nextPageCursor: zod_1.z.string().optional(),
    }).passthrough(),
}).passthrough();
const BybitRowSchema = zod_1.z.object({
    symbol: zod_1.z.string(),
    contractType: zod_1.z.string(),
    status: zod_1.z.string(),
    baseCoin: zod_1.z.string(),
    quoteCoin: zod_1.z.string(),
    settleCoin: zod_1.z.string(),
    launchTime: zod_1.z.union([zod_1.z.string(), zod_1.z.number()]).optional(),
    deliveryTime: zod_1.z.union([zod_1.z.string(), zod_1.z.number()]).optional(),
    symbolType: zod_1.z.string().optional(),
    isPreListing: zod_1.z.boolean().optional(),
    priceFilter: zod_1.z.object({
        tickSize: zod_1.z.string(),
    }).passthrough().optional(),
    lotSizeFilter: zod_1.z.object({
        qtyStep: zod_1.z.string(),
    }).passthrough().optional(),
}).passthrough();
const BitgetEnvelopeSchema = zod_1.z.object({
    code: zod_1.z.string(),
    data: zod_1.z.array(zod_1.z.unknown()),
}).passthrough();
const BitgetRowSchema = zod_1.z.object({
    symbol: zod_1.z.string(),
    baseCoin: zod_1.z.string(),
    quoteCoin: zod_1.z.string(),
    supportMarginCoins: zod_1.z.array(zod_1.z.string()).optional(),
    symbolType: zod_1.z.string(),
    symbolStatus: zod_1.z.string(),
    launchTime: zod_1.z.string().optional(),
    offTime: zod_1.z.string().optional(),
    maintainTime: zod_1.z.string().optional(),
    sizeMultiplier: zod_1.z.string().optional(),
    pricePlace: zod_1.z.string().optional(),
    priceEndStep: zod_1.z.string().optional(),
    isRwa: zod_1.z.string().optional(),
}).passthrough();
function everyRowConforms(records, schema) {
    return records.every((record) => schema.safeParse(record).success);
}
function binanceMultiAssetCatalogSchemaConforms(payload) {
    const envelope = BinanceEnvelopeSchema.safeParse(payload);
    return envelope.success &&
        everyRowConforms(envelope.data.symbols, BinanceRowSchema);
}
function okxMultiAssetCatalogSchemaConforms(payload) {
    const envelope = OkxEnvelopeSchema.safeParse(payload);
    return envelope.success &&
        envelope.data.code === "0" &&
        everyRowConforms(envelope.data.data, OkxRowSchema);
}
function bybitMultiAssetCatalogSchemaConforms(payload) {
    const envelope = BybitEnvelopeSchema.safeParse(payload);
    return envelope.success &&
        envelope.data.retCode === 0 &&
        envelope.data.result.category === "linear" &&
        everyRowConforms(envelope.data.result.list, BybitRowSchema);
}
function bitgetMultiAssetCatalogSchemaConforms(payload) {
    const envelope = BitgetEnvelopeSchema.safeParse(payload);
    return envelope.success &&
        envelope.data.code === "00000" &&
        everyRowConforms(envelope.data.data, BitgetRowSchema);
}
function uniqueSorted(values) {
    return [...new Set(values)].sort();
}
function normalizeToken(value) {
    if (typeof value !== "string") {
        return null;
    }
    const normalized = value.trim().normalize("NFC").toUpperCase();
    return normalized.length > 0 && normalized.length <= 160 ? normalized : null;
}
function normalizeDecimal(value) {
    if (typeof value !== "string") {
        return null;
    }
    const trimmed = value.trim();
    if (!/^(?:0|[1-9]\d*)(?:\.\d+)?$/u.test(trimmed)) {
        return null;
    }
    const [integer = "0", fraction = ""] = trimmed.split(".");
    const normalizedInteger = integer.replace(/^0+(?=\d)/u, "");
    const normalizedFraction = fraction.replace(/0+$/u, "");
    const normalized = normalizedFraction.length > 0
        ? `${normalizedInteger}.${normalizedFraction}`
        : normalizedInteger;
    return /[1-9]/u.test(normalized) ? normalized : null;
}
function decimalFromPlaces(coefficient, places) {
    if (coefficient === undefined ||
        places === undefined ||
        !/^[1-9]\d*$/u.test(coefficient) ||
        !/^(?:0|[1-9]\d*)$/u.test(places)) {
        return null;
    }
    const decimalPlaces = Number(places);
    if (!Number.isSafeInteger(decimalPlaces) || decimalPlaces > 24) {
        return null;
    }
    if (decimalPlaces === 0) {
        return normalizeDecimal(coefficient);
    }
    const padded = coefficient.padStart(decimalPlaces + 1, "0");
    const splitAt = padded.length - decimalPlaces;
    return normalizeDecimal(`${padded.slice(0, splitAt)}.${padded.slice(splitAt)}`);
}
function timestampFromMilliseconds(value) {
    if (value === null || value === undefined || value === "" || value === "-1") {
        return null;
    }
    const numeric = typeof value === "number" ? value : Number(value);
    if (!Number.isSafeInteger(numeric) || numeric <= 0) {
        return null;
    }
    const date = new Date(numeric);
    return Number.isNaN(date.getTime()) ? null : date.toISOString();
}
function activeMapping(mappings, sourceId, venueInstrumentId, receivedAt) {
    const normalizedInstrumentId = normalizeToken(venueInstrumentId);
    const valid = mappings
        .filter((mapping) => mapping.sourceId === sourceId &&
        normalizeToken(mapping.venueInstrumentId) === normalizedInstrumentId &&
        Date.parse(mapping.reviewedAt) <= Date.parse(receivedAt) &&
        Date.parse(receivedAt) < Date.parse(mapping.expiresAt));
    return {
        mapping: valid.length === 1 ? valid[0] : null,
        ambiguous: valid.length > 1,
    };
}
function validatedMappings(mappings) {
    return mappings.map((mapping) => multi_asset_identity_contract_1.M1OfficialUnderlyingMappingSchema.parse(mapping));
}
function classification(input) {
    const mappingResolution = activeMapping(input.mappings, input.sourceId, input.venueInstrumentId, input.receivedAt);
    if (mappingResolution.ambiguous) {
        return {
            assetDomain: null,
            authority: "UNRESOLVED",
            evidenceIds: [],
            underlyingReferenceId: null,
            reasonCodes: ["multiple_active_official_mappings_for_instrument"],
        };
    }
    const mapping = mappingResolution.mapping;
    const hint = input.classificationHint;
    if (mapping !== null) {
        const hintConflicts = hint.assetDomain === "CRYPTO_LINEAR_PERPETUAL" ||
            (hint.assetDomain !== null &&
                hint.assetDomain !== "OTHER_RWA_DERIVATIVE" &&
                hint.assetDomain !== mapping.assetDomain);
        if (hintConflicts) {
            return {
                assetDomain: null,
                authority: "UNRESOLVED",
                evidenceIds: mapping.evidenceIds,
                underlyingReferenceId: null,
                reasonCodes: uniqueSorted([
                    ...hint.reasonCodes,
                    "provider_and_official_mapping_classification_conflict",
                ]),
            };
        }
        return {
            assetDomain: mapping.assetDomain,
            authority: "OFFICIAL_PRODUCT_MAPPING",
            evidenceIds: mapping.evidenceIds,
            underlyingReferenceId: mapping.underlyingReferenceId,
            reasonCodes: hint.broadRwa
                ? ["broad_provider_rwa_category_refined_by_official_mapping"]
                : [],
        };
    }
    if (hint.assetDomain === null) {
        return {
            assetDomain: null,
            authority: "UNRESOLVED",
            evidenceIds: [],
            underlyingReferenceId: null,
            reasonCodes: uniqueSorted([
                ...hint.reasonCodes,
                "asset_domain_not_proven_without_symbol_guessing",
            ]),
        };
    }
    const baseAsset = normalizeToken(input.baseAsset);
    return {
        assetDomain: hint.assetDomain,
        authority: hint.authority,
        evidenceIds: [],
        underlyingReferenceId: baseAsset === null
            ? null
            : `VENUE_ASSET:${input.sourceId}:${baseAsset}`,
        reasonCodes: hint.reasonCodes,
    };
}
function materialize(input) {
    var _a;
    const venueInstrumentId = (_a = normalizeToken(input.venueInstrumentId)) !== null && _a !== void 0 ? _a : `UNRESOLVED:${(0, stable_artifact_1.stableContentHash)(input.rawRecord).slice(7, 31)}`;
    const baseAsset = normalizeToken(input.baseAsset);
    const quoteAsset = normalizeToken(input.quoteAsset);
    const settlementAsset = normalizeToken(input.settlementAsset);
    const contractMultiplier = normalizeDecimal(input.contractMultiplier);
    const priceTick = normalizeDecimal(input.priceTick);
    const quantityStep = normalizeDecimal(input.quantityStep);
    const resolved = classification(Object.assign(Object.assign({}, input), { venueInstrumentId }));
    const listingEpoch = (0, multi_asset_identity_contract_1.deriveM1ListingEpoch)({
        sourceId: input.sourceId,
        venueInstrumentId,
        providerListTime: input.providerListTime,
        firstObservedAt: input.receivedAt,
    });
    const identityEpoch = (0, multi_asset_identity_contract_1.deriveM1IdentityEpoch)({
        sourceId: input.sourceId,
        venueInstrumentId,
        listingEpoch,
        assetDomain: resolved.assetDomain,
        underlyingReferenceId: resolved.underlyingReferenceId,
    });
    const complete = input.targetContract &&
        resolved.assetDomain !== null &&
        baseAsset !== null &&
        quoteAsset !== null &&
        settlementAsset !== null &&
        contractMultiplier !== null &&
        priceTick !== null &&
        quantityStep !== null;
    const identityStatus = complete
        ? "EXACT"
        : resolved.assetDomain === null
            ? "UNRESOLVED"
            : "PARTIAL";
    const canonicalInstrumentId = complete
        ? (0, multi_asset_identity_contract_1.deriveM1CanonicalInstrumentId)({
            sourceId: input.sourceId,
            venueInstrumentId,
            identityEpoch,
        })
        : null;
    const reasonCodes = uniqueSorted([
        ...input.extraReasonCodes,
        ...resolved.reasonCodes,
        ...(input.targetContract ? [] : ["contract_outside_target_mechanism"]),
        ...(baseAsset === null ? ["base_asset_missing_or_invalid"] : []),
        ...(quoteAsset === null ? ["quote_asset_missing_or_invalid"] : []),
        ...(settlementAsset === null
            ? ["settlement_asset_missing_or_invalid"]
            : []),
        ...(contractMultiplier === null ? ["contract_multiplier_unresolved"] : []),
        ...(priceTick === null ? ["price_tick_unresolved"] : []),
        ...(quantityStep === null ? ["quantity_step_unresolved"] : []),
    ]);
    return (0, multi_asset_identity_contract_1.createM1MultiAssetObservation)({
        coverageClass: "SUPPORTED_DERIVATIVE",
        assetDomain: resolved.assetDomain,
        sourceId: input.sourceId,
        venueInstrumentId,
        canonicalInstrumentId,
        underlyingGroupId: complete && resolved.assetDomain !== null
            ? (0, multi_asset_identity_contract_1.deriveM1UnderlyingGroupId)({
                assetDomain: resolved.assetDomain,
                underlyingReferenceId: resolved.underlyingReferenceId,
                settlementAsset,
            })
            : null,
        underlyingReferenceId: resolved.underlyingReferenceId,
        baseAsset,
        quoteAsset,
        settlementAsset,
        contractMechanism: input.contractMechanism,
        contractMultiplier,
        priceTick,
        quantityStep,
        listingEpoch,
        identityEpoch,
        identityStatus,
        classificationAuthority: resolved.authority,
        classificationEvidenceIds: [...resolved.evidenceIds],
        providerStatus: input.providerStatus,
        lifecycleState: input.lifecycleState,
        providerListTime: input.providerListTime,
        providerDelistTime: input.providerDelistTime,
        firstObservedAt: input.receivedAt,
        statusEffectiveAt: input.statusEffectiveAt,
        knowledgeTime: input.receivedAt,
        jurisdictionAvailability: "UNVERIFIED",
        sourceCapability: "DERIVATIVE_INSTRUMENT_CATALOG",
        sourceRecordDigest: (0, stable_artifact_1.stableContentHash)(input.rawRecord),
        reasonCodes,
    });
}
function finish(sourceId, receivedAt, rawRecordCount, observations, outerReasonCodes = []) {
    const reasonCodes = uniqueSorted([
        ...outerReasonCodes,
        ...observations.flatMap((observation) => observation.reasonCodes),
    ]);
    const status = rawRecordCount === 0 || observations.length === 0
        ? "FAIL"
        : observations.some((observation) => observation.identityStatus !== "EXACT")
            ? "PARTIAL"
            : "PASS";
    return (0, stable_artifact_1.deepFreezeArtifact)({
        sourceId,
        receivedAt,
        rawRecordCount,
        observations: [...observations],
        status,
        reasonCodes,
        authorityBoundary: "NORMALIZATION_ONLY_NO_ELIGIBLE_FACT_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY",
    });
}
function invalidEnvelope(sourceId, receivedAt, reasonCode) {
    return finish(sourceId, receivedAt, 0, [], [reasonCode]);
}
function binanceClassification(row) {
    const category = normalizeToken(row.underlyingType);
    const domain = category === "COIN" || category === "CRYPTO"
        ? "CRYPTO_LINEAR_PERPETUAL"
        : category === "STOCK" || category === "EQUITY"
            ? "EQUITY_SINGLE_NAME_PERPETUAL"
            : category === "ETF" || category === "INDEX"
                ? "EQUITY_INDEX_ETF_PERPETUAL"
                : ["RWA", "TRADFI", "COMMODITY", "FOREX", "BOND"].includes(category !== null && category !== void 0 ? category : "")
                    ? "OTHER_RWA_DERIVATIVE"
                    : null;
    return {
        assetDomain: domain,
        authority: domain === null
            ? "UNRESOLVED"
            : "PROVIDER_EXPLICIT_CATEGORY",
        reasonCodes: domain === null
            ? ["binance_underlying_type_unrecognized_or_missing"]
            : [],
        broadRwa: domain === "OTHER_RWA_DERIVATIVE",
    };
}
function binanceFilter(filters, filterType, field) {
    var _a;
    for (const filter of filters !== null && filters !== void 0 ? filters : []) {
        if (typeof filter === "object" &&
            filter !== null &&
            filter.filterType === filterType &&
            typeof filter[field] === "string") {
            return (_a = filter[field]) !== null && _a !== void 0 ? _a : null;
        }
    }
    return null;
}
function binanceLifecycle(status) {
    if (status === "PENDING_TRADING") {
        return "PRE_LAUNCH_OR_PREOPEN";
    }
    if (status === "TRADING") {
        return "TRADING_WARMUP";
    }
    if (["PRE_DELIVERING", "DELIVERING", "PRE_SETTLE", "SETTLING"].includes(status)) {
        return "DELISTING";
    }
    if (["DELIVERED", "CLOSE"].includes(status)) {
        return "OFFLINE";
    }
    return "UNRESOLVED";
}
function normalizeBinanceMultiAssetCatalog(input) {
    var _a;
    const envelope = BinanceEnvelopeSchema.safeParse(input.payload);
    if (!envelope.success) {
        return invalidEnvelope("BINANCE_FUTURES", input.receivedAt, "binance_scope_v2_catalog_schema_invalid");
    }
    const mappings = validatedMappings((_a = input.mappings) !== null && _a !== void 0 ? _a : []);
    const observations = envelope.data.symbols.map((rawRecord) => {
        const parsed = BinanceRowSchema.safeParse(rawRecord);
        if (!parsed.success) {
            return materialize({
                sourceId: "BINANCE_FUTURES",
                venueInstrumentId: typeof (rawRecord === null || rawRecord === void 0 ? void 0 : rawRecord.symbol) ===
                    "string"
                    ? String(rawRecord.symbol)
                    : `UNRESOLVED:${(0, stable_artifact_1.stableContentHash)(rawRecord).slice(7, 31)}`,
                baseAsset: null,
                quoteAsset: null,
                settlementAsset: null,
                contractMechanism: "UNKNOWN_DERIVATIVE",
                contractMultiplier: null,
                priceTick: null,
                quantityStep: null,
                providerStatus: "SCHEMA_INVALID",
                lifecycleState: "UNRESOLVED",
                providerListTime: null,
                providerDelistTime: null,
                statusEffectiveAt: null,
                receivedAt: input.receivedAt,
                rawRecord,
                classificationHint: {
                    assetDomain: null,
                    authority: "UNRESOLVED",
                    reasonCodes: ["binance_catalog_row_schema_invalid"],
                    broadRwa: false,
                },
                mappings,
                extraReasonCodes: ["binance_catalog_row_schema_invalid"],
                targetContract: false,
            });
        }
        const row = parsed.data;
        const targetContract = row.contractType === "PERPETUAL" &&
            row.quoteAsset.toUpperCase() === "USDT" &&
            row.marginAsset.toUpperCase() === "USDT";
        return materialize({
            sourceId: "BINANCE_FUTURES",
            venueInstrumentId: row.symbol,
            baseAsset: row.baseAsset,
            quoteAsset: row.quoteAsset,
            settlementAsset: row.marginAsset,
            contractMechanism: row.contractType === "PERPETUAL"
                ? "LINEAR_PERPETUAL"
                : "UNKNOWN_DERIVATIVE",
            contractMultiplier: "1",
            priceTick: binanceFilter(row.filters, "PRICE_FILTER", "tickSize"),
            quantityStep: binanceFilter(row.filters, "LOT_SIZE", "stepSize"),
            providerStatus: row.status,
            lifecycleState: binanceLifecycle(row.status),
            providerListTime: timestampFromMilliseconds(row.onboardDate),
            providerDelistTime: timestampFromMilliseconds(row.deliveryDate),
            statusEffectiveAt: timestampFromMilliseconds(row.onboardDate),
            receivedAt: input.receivedAt,
            rawRecord,
            classificationHint: binanceClassification(row),
            mappings,
            extraReasonCodes: [],
            targetContract,
        });
    });
    return finish("BINANCE_FUTURES", input.receivedAt, envelope.data.symbols.length, observations);
}
function okxClassification(row) {
    var _a;
    const domain = row.instCategory === "1"
        ? "CRYPTO_LINEAR_PERPETUAL"
        : row.instCategory === "3"
            ? "EQUITY_SINGLE_NAME_PERPETUAL"
            : ["4", "5", "6"].includes((_a = row.instCategory) !== null && _a !== void 0 ? _a : "")
                ? "OTHER_RWA_DERIVATIVE"
                : null;
    return {
        assetDomain: domain,
        authority: domain === null
            ? "UNRESOLVED"
            : "PROVIDER_EXPLICIT_CATEGORY",
        reasonCodes: domain === null
            ? ["okx_inst_category_unrecognized_or_missing"]
            : [],
        broadRwa: domain === "OTHER_RWA_DERIVATIVE",
    };
}
function okxQuoteAsset(row) {
    var _a, _b, _c, _d;
    if (normalizeToken(row.quoteCcy) !== null) {
        return (_a = row.quoteCcy) !== null && _a !== void 0 ? _a : null;
    }
    const underlying = ((_b = row.uly) === null || _b === void 0 ? void 0 : _b.trim()) || ((_c = row.instFamily) === null || _c === void 0 ? void 0 : _c.trim()) || "";
    const match = /^(.+)-([^-]+)$/u.exec(underlying);
    return (_d = match === null || match === void 0 ? void 0 : match[2]) !== null && _d !== void 0 ? _d : null;
}
function okxLifecycle(state) {
    if (state === "preopen") {
        return "PRE_LAUNCH_OR_PREOPEN";
    }
    if (state === "live") {
        return "TRADING_WARMUP";
    }
    if (state === "suspend") {
        return "SUSPENDED";
    }
    if (state === "test") {
        return "RESTRICTED";
    }
    if (state === "expiring") {
        return "DELISTING";
    }
    if (state === "expired") {
        return "OFFLINE";
    }
    return "UNRESOLVED";
}
function normalizeOkxMultiAssetCatalog(input) {
    var _a;
    const envelope = OkxEnvelopeSchema.safeParse(input.payload);
    if (!envelope.success || envelope.data.code !== "0") {
        return invalidEnvelope("OKX_SWAP", input.receivedAt, envelope.success
            ? "okx_scope_v2_catalog_provider_error"
            : "okx_scope_v2_catalog_schema_invalid");
    }
    const mappings = validatedMappings((_a = input.mappings) !== null && _a !== void 0 ? _a : []);
    const observations = envelope.data.data.map((rawRecord) => {
        var _a, _b, _c;
        const parsed = OkxRowSchema.safeParse(rawRecord);
        if (!parsed.success) {
            return materialize({
                sourceId: "OKX_SWAP",
                venueInstrumentId: typeof (rawRecord === null || rawRecord === void 0 ? void 0 : rawRecord.instId) ===
                    "string"
                    ? String(rawRecord.instId)
                    : `UNRESOLVED:${(0, stable_artifact_1.stableContentHash)(rawRecord).slice(7, 31)}`,
                baseAsset: null,
                quoteAsset: null,
                settlementAsset: null,
                contractMechanism: "UNKNOWN_DERIVATIVE",
                contractMultiplier: null,
                priceTick: null,
                quantityStep: null,
                providerStatus: "SCHEMA_INVALID",
                lifecycleState: "UNRESOLVED",
                providerListTime: null,
                providerDelistTime: null,
                statusEffectiveAt: null,
                receivedAt: input.receivedAt,
                rawRecord,
                classificationHint: {
                    assetDomain: null,
                    authority: "UNRESOLVED",
                    reasonCodes: ["okx_catalog_row_schema_invalid"],
                    broadRwa: false,
                },
                mappings,
                extraReasonCodes: ["okx_catalog_row_schema_invalid"],
                targetContract: false,
            });
        }
        const row = parsed.data;
        const quoteAsset = okxQuoteAsset(row);
        const targetContract = row.instType === "SWAP" &&
            row.ctType === "linear" &&
            ["USDT", "USDC"].includes(row.settleCcy.toUpperCase()) &&
            normalizeToken(quoteAsset) === normalizeToken(row.settleCcy);
        return materialize({
            sourceId: "OKX_SWAP",
            venueInstrumentId: row.instId,
            baseAsset: row.ctValCcy,
            quoteAsset,
            settlementAsset: row.settleCcy,
            contractMechanism: row.instType === "SWAP" && row.ctType === "linear"
                ? "LINEAR_PERPETUAL"
                : "UNKNOWN_DERIVATIVE",
            contractMultiplier: row.ctVal,
            priceTick: (_a = row.tickSz) !== null && _a !== void 0 ? _a : null,
            quantityStep: (_c = (_b = row.lotSz) !== null && _b !== void 0 ? _b : row.minSz) !== null && _c !== void 0 ? _c : null,
            providerStatus: row.state,
            lifecycleState: okxLifecycle(row.state),
            providerListTime: timestampFromMilliseconds(row.listTime),
            providerDelistTime: timestampFromMilliseconds(row.expTime),
            statusEffectiveAt: timestampFromMilliseconds(row.listTime),
            receivedAt: input.receivedAt,
            rawRecord,
            classificationHint: okxClassification(row),
            mappings,
            extraReasonCodes: [],
            targetContract,
        });
    });
    return finish("OKX_SWAP", input.receivedAt, envelope.data.data.length, observations);
}
function bybitClassification(row) {
    const category = row.symbolType === undefined
        ? null
        : row.symbolType.trim() === ""
            ? ""
            : normalizeToken(row.symbolType);
    const domain = category === "" || category === "INNOVATION"
        ? "CRYPTO_LINEAR_PERPETUAL"
        : category === "STOCK" ||
            category === "COMMODITY" ||
            category === "FOREX"
            ? "OTHER_RWA_DERIVATIVE"
            : null;
    return {
        assetDomain: domain,
        authority: domain === null
            ? "UNRESOLVED"
            : "PROVIDER_EXPLICIT_CATEGORY",
        reasonCodes: domain === null
            ? ["bybit_symbol_type_unrecognized"]
            : category === "STOCK"
                ? ["bybit_stock_category_does_not_distinguish_single_name_from_etf"]
                : [],
        broadRwa: domain === "OTHER_RWA_DERIVATIVE",
    };
}
function bybitLifecycle(status, isPreListing) {
    if (status === "PreLaunch" || isPreListing === true) {
        return "PRE_LAUNCH_OR_PREOPEN";
    }
    if (status === "Trading") {
        return "TRADING_WARMUP";
    }
    if (status === "Settling" || status === "Delivering") {
        return "DELISTING";
    }
    if (status === "Closed") {
        return "OFFLINE";
    }
    return "UNRESOLVED";
}
function normalizeBybitMultiAssetCatalog(input) {
    var _a;
    const envelope = BybitEnvelopeSchema.safeParse(input.payload);
    if (!envelope.success ||
        envelope.data.retCode !== 0 ||
        envelope.data.result.category !== "linear") {
        return invalidEnvelope("BYBIT_DERIVATIVES", input.receivedAt, envelope.success
            ? "bybit_scope_v2_catalog_provider_error"
            : "bybit_scope_v2_catalog_schema_invalid");
    }
    const mappings = validatedMappings((_a = input.mappings) !== null && _a !== void 0 ? _a : []);
    const observations = envelope.data.result.list.map((rawRecord) => {
        var _a, _b, _c, _d;
        const parsed = BybitRowSchema.safeParse(rawRecord);
        if (!parsed.success) {
            return materialize({
                sourceId: "BYBIT_DERIVATIVES",
                venueInstrumentId: typeof (rawRecord === null || rawRecord === void 0 ? void 0 : rawRecord.symbol) ===
                    "string"
                    ? String(rawRecord.symbol)
                    : `UNRESOLVED:${(0, stable_artifact_1.stableContentHash)(rawRecord).slice(7, 31)}`,
                baseAsset: null,
                quoteAsset: null,
                settlementAsset: null,
                contractMechanism: "UNKNOWN_DERIVATIVE",
                contractMultiplier: null,
                priceTick: null,
                quantityStep: null,
                providerStatus: "SCHEMA_INVALID",
                lifecycleState: "UNRESOLVED",
                providerListTime: null,
                providerDelistTime: null,
                statusEffectiveAt: null,
                receivedAt: input.receivedAt,
                rawRecord,
                classificationHint: {
                    assetDomain: null,
                    authority: "UNRESOLVED",
                    reasonCodes: ["bybit_catalog_row_schema_invalid"],
                    broadRwa: false,
                },
                mappings,
                extraReasonCodes: ["bybit_catalog_row_schema_invalid"],
                targetContract: false,
            });
        }
        const row = parsed.data;
        const targetContract = row.contractType === "LinearPerpetual" &&
            ["USDT", "USDC"].includes(row.settleCoin.toUpperCase()) &&
            row.quoteCoin.toUpperCase() === row.settleCoin.toUpperCase();
        return materialize({
            sourceId: "BYBIT_DERIVATIVES",
            venueInstrumentId: row.symbol,
            baseAsset: row.baseCoin,
            quoteAsset: row.quoteCoin,
            settlementAsset: row.settleCoin,
            contractMechanism: row.contractType === "LinearPerpetual"
                ? "LINEAR_PERPETUAL"
                : "UNKNOWN_DERIVATIVE",
            contractMultiplier: "1",
            priceTick: (_b = (_a = row.priceFilter) === null || _a === void 0 ? void 0 : _a.tickSize) !== null && _b !== void 0 ? _b : null,
            quantityStep: (_d = (_c = row.lotSizeFilter) === null || _c === void 0 ? void 0 : _c.qtyStep) !== null && _d !== void 0 ? _d : null,
            providerStatus: row.status,
            lifecycleState: bybitLifecycle(row.status, row.isPreListing),
            providerListTime: timestampFromMilliseconds(row.launchTime),
            providerDelistTime: timestampFromMilliseconds(row.deliveryTime),
            statusEffectiveAt: timestampFromMilliseconds(row.launchTime),
            receivedAt: input.receivedAt,
            rawRecord,
            classificationHint: bybitClassification(row),
            mappings,
            extraReasonCodes: [],
            targetContract,
        });
    });
    return finish("BYBIT_DERIVATIVES", input.receivedAt, envelope.data.result.list.length, observations);
}
function bitgetClassification(row) {
    const isRwa = normalizeToken(row.isRwa);
    const domain = isRwa === "NO"
        ? "CRYPTO_LINEAR_PERPETUAL"
        : isRwa === "YES"
            ? "OTHER_RWA_DERIVATIVE"
            : null;
    return {
        assetDomain: domain,
        authority: isRwa === "NO"
            ? "PROVIDER_NEGATIVE_RWA_FLAG"
            : domain === null
                ? "UNRESOLVED"
                : "PROVIDER_EXPLICIT_CATEGORY",
        reasonCodes: isRwa === "YES"
            ? ["bitget_is_rwa_does_not_prove_stock_or_etf_identity"]
            : domain === null
                ? ["bitget_is_rwa_unrecognized_or_missing"]
                : [],
        broadRwa: isRwa === "YES",
    };
}
function bitgetLifecycle(status, maintainTime) {
    if (status === "listed") {
        return "PRE_LAUNCH_OR_PREOPEN";
    }
    if (status === "maintain" || timestampFromMilliseconds(maintainTime) !== null) {
        return "MAINTENANCE";
    }
    if (status === "limit_open" || status === "restrictedAPI") {
        return "RESTRICTED";
    }
    if (status === "normal") {
        return "TRADING_WARMUP";
    }
    if (status === "off") {
        return "OFFLINE";
    }
    return "UNRESOLVED";
}
function normalizeBitgetMultiAssetCatalog(input) {
    var _a;
    const envelope = BitgetEnvelopeSchema.safeParse(input.payload);
    if (!envelope.success || envelope.data.code !== "00000") {
        return invalidEnvelope("BITGET_FUTURES", input.receivedAt, envelope.success
            ? "bitget_scope_v2_catalog_provider_error"
            : "bitget_scope_v2_catalog_schema_invalid");
    }
    const mappings = validatedMappings((_a = input.mappings) !== null && _a !== void 0 ? _a : []);
    const observations = envelope.data.data.map((rawRecord) => {
        var _a, _b, _c;
        const parsed = BitgetRowSchema.safeParse(rawRecord);
        if (!parsed.success) {
            return materialize({
                sourceId: "BITGET_FUTURES",
                venueInstrumentId: typeof (rawRecord === null || rawRecord === void 0 ? void 0 : rawRecord.symbol) ===
                    "string"
                    ? String(rawRecord.symbol)
                    : `UNRESOLVED:${(0, stable_artifact_1.stableContentHash)(rawRecord).slice(7, 31)}`,
                baseAsset: null,
                quoteAsset: null,
                settlementAsset: null,
                contractMechanism: "UNKNOWN_DERIVATIVE",
                contractMultiplier: null,
                priceTick: null,
                quantityStep: null,
                providerStatus: "SCHEMA_INVALID",
                lifecycleState: "UNRESOLVED",
                providerListTime: null,
                providerDelistTime: null,
                statusEffectiveAt: null,
                receivedAt: input.receivedAt,
                rawRecord,
                classificationHint: {
                    assetDomain: null,
                    authority: "UNRESOLVED",
                    reasonCodes: ["bitget_catalog_row_schema_invalid"],
                    broadRwa: false,
                },
                mappings,
                extraReasonCodes: ["bitget_catalog_row_schema_invalid"],
                targetContract: false,
            });
        }
        const row = parsed.data;
        const marginCoins = (_b = (_a = row.supportMarginCoins) === null || _a === void 0 ? void 0 : _a.map((value) => value.toUpperCase())) !== null && _b !== void 0 ? _b : [];
        const targetContract = row.symbolType === "perpetual" &&
            row.quoteCoin.toUpperCase() === "USDT" &&
            marginCoins.includes("USDT");
        const lifecycleState = bitgetLifecycle(row.symbolStatus, row.maintainTime);
        const providerListTime = timestampFromMilliseconds(row.launchTime);
        const providerDelistTime = timestampFromMilliseconds(row.offTime);
        const maintenanceTime = timestampFromMilliseconds(row.maintainTime);
        return materialize({
            sourceId: "BITGET_FUTURES",
            venueInstrumentId: row.symbol,
            baseAsset: row.baseCoin,
            quoteAsset: row.quoteCoin,
            settlementAsset: marginCoins.includes("USDT") ? "USDT" : null,
            contractMechanism: row.symbolType === "perpetual"
                ? "LINEAR_PERPETUAL"
                : "UNKNOWN_DERIVATIVE",
            contractMultiplier: "1",
            priceTick: decimalFromPlaces(row.priceEndStep, row.pricePlace),
            quantityStep: (_c = row.sizeMultiplier) !== null && _c !== void 0 ? _c : null,
            providerStatus: row.symbolStatus,
            lifecycleState,
            providerListTime,
            providerDelistTime,
            statusEffectiveAt: lifecycleState === "OFFLINE"
                ? providerDelistTime
                : lifecycleState === "MAINTENANCE" ||
                    lifecycleState === "RESTRICTED"
                    ? maintenanceTime
                    : providerListTime,
            receivedAt: input.receivedAt,
            rawRecord,
            classificationHint: bitgetClassification(row),
            mappings,
            extraReasonCodes: [],
            targetContract,
        });
    });
    return finish("BITGET_FUTURES", input.receivedAt, envelope.data.data.length, observations);
}
