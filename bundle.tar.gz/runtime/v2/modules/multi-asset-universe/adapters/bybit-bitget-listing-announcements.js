"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bybitListingAnnouncementSchemaConforms = bybitListingAnnouncementSchemaConforms;
exports.bitgetListingAnnouncementSchemaConforms = bitgetListingAnnouncementSchemaConforms;
exports.normalizeBybitListingAnnouncements = normalizeBybitListingAnnouncements;
exports.normalizeBitgetListingAnnouncements = normalizeBitgetListingAnnouncements;
const zod_1 = require("zod");
const listing_lifecycle_contract_1 = require("../listing-lifecycle-contract");
const stable_artifact_1 = require("../../universe/stable-artifact");
const BybitEnvelopeSchema = zod_1.z.object({
    retCode: zod_1.z.number().int(),
    result: zod_1.z.object({
        total: zod_1.z.number().int().nonnegative(),
        list: zod_1.z.array(zod_1.z.unknown()),
    }).passthrough(),
}).passthrough();
const BybitAnnouncementSchema = zod_1.z.object({
    title: zod_1.z.string(),
    type: zod_1.z.object({
        key: zod_1.z.string(),
    }).passthrough(),
    tags: zod_1.z.array(zod_1.z.string()).optional(),
    url: zod_1.z.string(),
    publishTime: zod_1.z.number().optional(),
    dateTimestamp: zod_1.z.number().optional(),
    startDateTimestamp: zod_1.z.number().optional(),
    startDataTimestamp: zod_1.z.number().optional(),
}).passthrough();
const BitgetEnvelopeSchema = zod_1.z.object({
    code: zod_1.z.string(),
    data: zod_1.z.array(zod_1.z.unknown()),
}).passthrough();
const BitgetAnnouncementSchema = zod_1.z.object({
    annId: zod_1.z.string(),
    annTitle: zod_1.z.string(),
    annUrl: zod_1.z.string(),
    cTime: zod_1.z.string(),
    annType: zod_1.z.string().optional(),
    annSubType: zod_1.z.string().optional(),
}).passthrough();
function uniqueSorted(values) {
    return [...new Set(values)].sort();
}
function timestampFromMilliseconds(value) {
    if (value === null || value === undefined || value === "") {
        return null;
    }
    const numeric = typeof value === "number" ? value : Number(value);
    if (!Number.isSafeInteger(numeric) || numeric <= 0) {
        return null;
    }
    const date = new Date(numeric);
    return Number.isNaN(date.getTime()) ? null : date.toISOString();
}
function isHttpsUrl(value) {
    try {
        return new URL(value).protocol === "https:";
    }
    catch (_a) {
        return false;
    }
}
function bybitListingAnnouncementSchemaConforms(payload) {
    const envelope = BybitEnvelopeSchema.safeParse(payload);
    return envelope.success &&
        envelope.data.retCode === 0 &&
        envelope.data.result.list.every((record) => {
            var _a;
            const parsed = BybitAnnouncementSchema.safeParse(record);
            return parsed.success &&
                timestampFromMilliseconds((_a = parsed.data.publishTime) !== null && _a !== void 0 ? _a : parsed.data.dateTimestamp) !== null &&
                isHttpsUrl(parsed.data.url);
        });
}
function bitgetListingAnnouncementSchemaConforms(payload) {
    const envelope = BitgetEnvelopeSchema.safeParse(payload);
    return envelope.success &&
        envelope.data.code === "00000" &&
        envelope.data.data.every((record) => {
            const parsed = BitgetAnnouncementSchema.safeParse(record);
            return parsed.success &&
                timestampFromMilliseconds(parsed.data.cTime) !== null &&
                isHttpsUrl(parsed.data.annUrl);
        });
}
function finish(sourceId, receivedAt, rawRecordCount, observations, reasonCodes) {
    const status = rawRecordCount === 0 || observations.length === 0
        ? "FAIL"
        : observations.length === rawRecordCount && reasonCodes.length === 0
            ? "PASS"
            : "PARTIAL";
    return (0, stable_artifact_1.deepFreezeArtifact)({
        sourceId,
        receivedAt,
        rawRecordCount,
        observations: [...observations],
        status,
        reasonCodes: uniqueSorted(reasonCodes),
        authorityBoundary: "ANNOUNCEMENT_NORMALIZATION_ONLY_NO_TITLE_SYMBOL_GUESSING_OR_CANDIDATE_AUTHORITY",
    });
}
function bybitKind(typeKey, tags) {
    const normalized = [typeKey, ...tags].map((value) => value.trim().toLowerCase());
    if (normalized.some((value) => value.includes("delist"))) {
        return "DELISTING";
    }
    if (normalized.includes("new_crypto") ||
        normalized.some((value) => value === "spot listings")) {
        return "LISTING";
    }
    return normalized.some((value) => value.includes("product") || value.includes("maintenance"))
        ? "PRODUCT_UPDATE"
        : "OTHER";
}
function bybitProductScope(tags) {
    const normalized = tags.map((value) => value.trim().toLowerCase());
    const spot = normalized.some((value) => value.includes("spot"));
    const derivative = normalized.some((value) => value.includes("derivative") ||
        value.includes("futures") ||
        value.includes("perpetual"));
    return spot && derivative
        ? "MIXED"
        : spot
            ? "SPOT"
            : derivative
                ? "DERIVATIVE"
                : "UNKNOWN";
}
function normalizeBybitListingAnnouncements(input) {
    var _a, _b, _c;
    const envelope = BybitEnvelopeSchema.safeParse(input.payload);
    if (!envelope.success || envelope.data.retCode !== 0) {
        return finish("BYBIT_DERIVATIVES", input.receivedAt, 0, [], [
            envelope.success
                ? "bybit_announcement_provider_error"
                : "bybit_announcement_schema_invalid",
        ]);
    }
    const observations = [];
    const reasonCodes = [];
    for (const rawRecord of envelope.data.result.list) {
        const parsed = BybitAnnouncementSchema.safeParse(rawRecord);
        if (!parsed.success) {
            reasonCodes.push("bybit_announcement_row_schema_invalid");
            continue;
        }
        const row = parsed.data;
        const publishedAt = timestampFromMilliseconds((_a = row.publishTime) !== null && _a !== void 0 ? _a : row.dateTimestamp);
        if (publishedAt === null || !isHttpsUrl(row.url)) {
            reasonCodes.push("bybit_announcement_time_or_url_invalid");
            continue;
        }
        const tags = (_b = row.tags) !== null && _b !== void 0 ? _b : [];
        observations.push((0, listing_lifecycle_contract_1.createM1ListingAnnouncementObservation)({
            sourceId: "BYBIT_DERIVATIVES",
            announcementId: `bybit:${(0, stable_artifact_1.stableContentHash)({
                url: row.url,
                publishedAt,
            }).slice(7, 31)}`,
            announcementUrl: row.url,
            titleDigest: (0, stable_artifact_1.stableContentHash)(row.title),
            announcementKind: bybitKind(row.type.key, tags),
            productScope: bybitProductScope(tags),
            providerPublishedAt: publishedAt,
            providerEffectiveAt: timestampFromMilliseconds((_c = row.startDateTimestamp) !== null && _c !== void 0 ? _c : row.startDataTimestamp),
            knowledgeTime: input.receivedAt,
            structuredVenueInstrumentIds: [],
            instrumentLinkAuthority: "UNLINKED_NO_SYMBOL_GUESSING",
            sourceCapability: "LISTING_ANNOUNCEMENT",
            sourceRecordDigest: (0, stable_artifact_1.stableContentHash)(rawRecord),
            reasonCodes: ["announcement_has_no_structured_instrument_id"],
        }));
    }
    return finish("BYBIT_DERIVATIVES", input.receivedAt, envelope.data.result.list.length, observations, reasonCodes);
}
function bitgetKind(annType) {
    if (annType === "coin_listings") {
        return "LISTING";
    }
    if (annType === "symbol_delisting") {
        return "DELISTING";
    }
    if (annType === "product_updates" ||
        annType === "maintenance_system_updates" ||
        annType === "api_trading") {
        return "PRODUCT_UPDATE";
    }
    return "OTHER";
}
function bitgetProductScope(annSubType) {
    if (annSubType === "spot") {
        return "SPOT";
    }
    if (annSubType === "futures") {
        return "DERIVATIVE";
    }
    return "UNKNOWN";
}
function normalizeBitgetListingAnnouncements(input) {
    const envelope = BitgetEnvelopeSchema.safeParse(input.payload);
    if (!envelope.success || envelope.data.code !== "00000") {
        return finish("BITGET_FUTURES", input.receivedAt, 0, [], [
            envelope.success
                ? "bitget_announcement_provider_error"
                : "bitget_announcement_schema_invalid",
        ]);
    }
    const observations = [];
    const reasonCodes = [];
    for (const rawRecord of envelope.data.data) {
        const parsed = BitgetAnnouncementSchema.safeParse(rawRecord);
        if (!parsed.success) {
            reasonCodes.push("bitget_announcement_row_schema_invalid");
            continue;
        }
        const row = parsed.data;
        const publishedAt = timestampFromMilliseconds(row.cTime);
        if (publishedAt === null || !isHttpsUrl(row.annUrl)) {
            reasonCodes.push("bitget_announcement_time_or_url_invalid");
            continue;
        }
        observations.push((0, listing_lifecycle_contract_1.createM1ListingAnnouncementObservation)({
            sourceId: "BITGET_FUTURES",
            announcementId: `bitget:${row.annId.trim()}`,
            announcementUrl: row.annUrl,
            titleDigest: (0, stable_artifact_1.stableContentHash)(row.annTitle),
            announcementKind: bitgetKind(row.annType),
            productScope: bitgetProductScope(row.annSubType),
            providerPublishedAt: publishedAt,
            providerEffectiveAt: null,
            knowledgeTime: input.receivedAt,
            structuredVenueInstrumentIds: [],
            instrumentLinkAuthority: "UNLINKED_NO_SYMBOL_GUESSING",
            sourceCapability: "LISTING_ANNOUNCEMENT",
            sourceRecordDigest: (0, stable_artifact_1.stableContentHash)(rawRecord),
            reasonCodes: ["announcement_has_no_structured_instrument_id"],
        }));
    }
    return finish("BITGET_FUTURES", input.receivedAt, envelope.data.data.length, observations, reasonCodes);
}
