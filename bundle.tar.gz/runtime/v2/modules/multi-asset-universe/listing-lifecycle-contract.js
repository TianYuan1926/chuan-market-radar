"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.M1ListingLifecycleLedgerSchema = exports.M1ListingLifecycleEventSchema = exports.M1ListingAnnouncementObservationSchema = exports.M1_LISTING_LIFECYCLE_LEDGER_VERSION = exports.M1_ANNOUNCEMENT_OBSERVATION_VERSION = void 0;
exports.createM1ListingAnnouncementObservation = createM1ListingAnnouncementObservation;
exports.buildM1ListingLifecycleLedger = buildM1ListingLifecycleLedger;
const zod_1 = require("zod");
const primitives_1 = require("../../runtime-schema/primitives");
const source_capability_contract_1 = require("../source-capability/source-capability-contract");
const multi_asset_identity_contract_1 = require("./multi-asset-identity-contract");
const stable_artifact_1 = require("../universe/stable-artifact");
exports.M1_ANNOUNCEMENT_OBSERVATION_VERSION = "v2-m1-listing-announcement-observation.v1";
exports.M1_LISTING_LIFECYCLE_LEDGER_VERSION = "v2-m1-listing-lifecycle-ledger.v1";
const DigestSchema = zod_1.z.string().regex(/^sha256:[0-9a-f]{64}$/u);
const VenueSchema = zod_1.z.enum(source_capability_contract_1.M1_VENUE_SOURCE_IDS);
const HttpsUrlSchema = zod_1.z.string().url().superRefine((value, context) => {
    if (new URL(value).protocol !== "https:") {
        context.addIssue({
            code: "custom",
            message: "announcement URL must use HTTPS",
        });
    }
});
exports.M1ListingAnnouncementObservationSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_ANNOUNCEMENT_OBSERVATION_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    sourceId: VenueSchema,
    announcementId: primitives_1.NonEmptyStringSchema,
    announcementUrl: HttpsUrlSchema,
    titleDigest: DigestSchema,
    announcementKind: zod_1.z.enum([
        "LISTING",
        "DELISTING",
        "PRODUCT_UPDATE",
        "OTHER",
    ]),
    productScope: zod_1.z.enum([
        "SPOT",
        "DERIVATIVE",
        "MIXED",
        "UNKNOWN",
    ]),
    providerPublishedAt: primitives_1.IsoDateTimeSchema,
    providerEffectiveAt: primitives_1.IsoDateTimeSchema.nullable(),
    knowledgeTime: primitives_1.IsoDateTimeSchema,
    structuredVenueInstrumentIds: zod_1.z.array(primitives_1.NonEmptyStringSchema),
    instrumentLinkAuthority: zod_1.z.enum([
        "PROVIDER_STRUCTURED_FIELD",
        "UNLINKED_NO_SYMBOL_GUESSING",
    ]),
    sourceCapability: zod_1.z.literal("LISTING_ANNOUNCEMENT"),
    sourceRecordDigest: DigestSchema,
    candidateEmissionAllowed: zod_1.z.literal(false),
    strategyAuthority: zod_1.z.literal(false),
    reasonCodes: primitives_1.ReasonCodesSchema,
}).superRefine((observation, context) => {
    if (Date.parse(observation.providerPublishedAt) >
        Date.parse(observation.knowledgeTime)) {
        context.addIssue({
            code: "custom",
            message: "announcement cannot be known before provider publication",
            path: ["knowledgeTime"],
        });
    }
    if (observation.instrumentLinkAuthority ===
        "UNLINKED_NO_SYMBOL_GUESSING" &&
        observation.structuredVenueInstrumentIds.length > 0) {
        context.addIssue({
            code: "custom",
            message: "unlinked announcements cannot claim instrument ids",
            path: ["structuredVenueInstrumentIds"],
        });
    }
    if (observation.instrumentLinkAuthority === "PROVIDER_STRUCTURED_FIELD" &&
        observation.structuredVenueInstrumentIds.length === 0) {
        context.addIssue({
            code: "custom",
            message: "structured linkage requires at least one instrument id",
            path: ["structuredVenueInstrumentIds"],
        });
    }
});
exports.M1ListingLifecycleEventSchema = zod_1.z.strictObject({
    eventId: primitives_1.NonEmptyStringSchema,
    sourceId: VenueSchema,
    venueInstrumentId: primitives_1.NonEmptyStringSchema.nullable(),
    listingEpoch: primitives_1.NonEmptyStringSchema.nullable(),
    previousState: zod_1.z.enum(multi_asset_identity_contract_1.M1_LISTING_LIFECYCLE_STATES).nullable(),
    currentState: zod_1.z.enum(multi_asset_identity_contract_1.M1_LISTING_LIFECYCLE_STATES),
    eventSource: zod_1.z.enum([
        "DERIVATIVE_CATALOG",
        "ANNOUNCEMENT",
        "CATALOG_ABSENCE",
    ]),
    providerEffectiveAt: primitives_1.IsoDateTimeSchema.nullable(),
    knowledgeTime: primitives_1.IsoDateTimeSchema,
    announcementIds: zod_1.z.array(primitives_1.NonEmptyStringSchema),
    correlationStatus: zod_1.z.enum([
        "EXACT_STRUCTURED_LINK",
        "UNLINKED_ANNOUNCEMENT",
        "CATALOG_ONLY",
        "MISSING_FROM_COMPLETE_CATALOG_NOT_DELISTING_PROOF",
    ]),
    sourceRecordDigests: zod_1.z.array(DigestSchema).min(1),
    candidateEmissionAllowed: zod_1.z.literal(false),
    reasonCodes: primitives_1.ReasonCodesSchema,
}).superRefine((event, context) => {
    const hasInstrument = event.venueInstrumentId !== null;
    if (hasInstrument !== (event.listingEpoch !== null)) {
        context.addIssue({
            code: "custom",
            message: "instrument and listing epoch must be present together",
            path: ["listingEpoch"],
        });
    }
    if (event.eventSource === "ANNOUNCEMENT" &&
        event.correlationStatus === "UNLINKED_ANNOUNCEMENT" &&
        hasInstrument) {
        context.addIssue({
            code: "custom",
            message: "unlinked announcement cannot claim an instrument",
            path: ["venueInstrumentId"],
        });
    }
    if (event.eventSource === "CATALOG_ABSENCE" &&
        (event.currentState !== "UNRESOLVED" ||
            event.correlationStatus !==
                "MISSING_FROM_COMPLETE_CATALOG_NOT_DELISTING_PROOF")) {
        context.addIssue({
            code: "custom",
            message: "catalog absence must remain unresolved, never inferred delisting",
            path: ["currentState"],
        });
    }
});
const CountByVenueSchema = zod_1.z.strictObject({
    BINANCE_FUTURES: primitives_1.NonNegativeIntegerSchema,
    OKX_SWAP: primitives_1.NonNegativeIntegerSchema,
    BYBIT_DERIVATIVES: primitives_1.NonNegativeIntegerSchema,
    BITGET_FUTURES: primitives_1.NonNegativeIntegerSchema,
});
exports.M1ListingLifecycleLedgerSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_LISTING_LIFECYCLE_LEDGER_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: primitives_1.NonEmptyStringSchema,
    generatedAt: primitives_1.IsoDateTimeSchema,
    sourceCutoff: primitives_1.IsoDateTimeSchema,
    currentIdentitySnapshotId: primitives_1.NonEmptyStringSchema,
    previousIdentitySnapshotId: primitives_1.NonEmptyStringSchema.nullable(),
    completeCatalogSources: zod_1.z.array(VenueSchema),
    announcementCount: primitives_1.NonNegativeIntegerSchema,
    eventCount: primitives_1.NonNegativeIntegerSchema,
    unlinkedAnnouncementCount: primitives_1.NonNegativeIntegerSchema,
    eventsByVenue: CountByVenueSchema,
    events: zod_1.z.array(exports.M1ListingLifecycleEventSchema),
    ledgerId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
    authorityBoundary: zod_1.z.literal("LISTING_INTELLIGENCE_ONLY_NO_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY"),
    productionChanged: zod_1.z.literal(false),
}).superRefine((ledger, context) => {
    if (Date.parse(ledger.sourceCutoff) > Date.parse(ledger.generatedAt)) {
        context.addIssue({
            code: "custom",
            message: "sourceCutoff cannot be later than generatedAt",
            path: ["sourceCutoff"],
        });
    }
    if (new Set(ledger.completeCatalogSources).size !==
        ledger.completeCatalogSources.length) {
        context.addIssue({
            code: "custom",
            message: "complete catalog sources must be unique",
            path: ["completeCatalogSources"],
        });
    }
    if (ledger.eventCount !== ledger.events.length) {
        context.addIssue({
            code: "custom",
            message: "eventCount must equal events length",
            path: ["eventCount"],
        });
    }
    const eventIds = ledger.events.map((event) => event.eventId);
    if (new Set(eventIds).size !== eventIds.length) {
        context.addIssue({
            code: "custom",
            message: "event ids must be unique",
            path: ["events"],
        });
    }
    const unlinked = ledger.events.filter((event) => event.correlationStatus === "UNLINKED_ANNOUNCEMENT").length;
    if (ledger.unlinkedAnnouncementCount !== unlinked) {
        context.addIssue({
            code: "custom",
            message: "unlinked announcement count does not match events",
            path: ["unlinkedAnnouncementCount"],
        });
    }
    const announcementEvents = ledger.events.filter((event) => event.eventSource === "ANNOUNCEMENT").length;
    if (ledger.announcementCount !== announcementEvents) {
        context.addIssue({
            code: "custom",
            message: "announcement count does not match announcement events",
            path: ["announcementCount"],
        });
    }
    const expectedByVenue = emptyVenueCounts();
    for (const event of ledger.events) {
        expectedByVenue[event.sourceId] += 1;
    }
    if ((0, stable_artifact_1.stableContentHash)(ledger.eventsByVenue) !==
        (0, stable_artifact_1.stableContentHash)(expectedByVenue)) {
        context.addIssue({
            code: "custom",
            message: "event venue counts do not match events",
            path: ["eventsByVenue"],
        });
    }
    const sortedEvents = [...ledger.events].sort((left, right) => left.knowledgeTime.localeCompare(right.knowledgeTime) ||
        left.sourceId.localeCompare(right.sourceId) ||
        left.eventId.localeCompare(right.eventId));
    if (ledger.events.some((event, index) => (0, stable_artifact_1.stableContentHash)(event) !== (0, stable_artifact_1.stableContentHash)(sortedEvents[index]))) {
        context.addIssue({
            code: "custom",
            message: "listing events must use canonical ordering",
            path: ["events"],
        });
    }
    const expectedContentHash = (0, stable_artifact_1.stableContentHash)({
        scopeEpoch: ledger.scopeEpoch,
        releaseId: ledger.releaseId,
        generatedAt: ledger.generatedAt,
        sourceCutoff: ledger.sourceCutoff,
        currentIdentitySnapshotId: ledger.currentIdentitySnapshotId,
        previousIdentitySnapshotId: ledger.previousIdentitySnapshotId,
        completeCatalogSources: ledger.completeCatalogSources,
        announcementCount: ledger.announcementCount,
        eventCount: ledger.eventCount,
        unlinkedAnnouncementCount: ledger.unlinkedAnnouncementCount,
        eventsByVenue: ledger.eventsByVenue,
        events: ledger.events,
        authorityBoundary: ledger.authorityBoundary,
        productionChanged: ledger.productionChanged,
    });
    if (ledger.contentHash !== expectedContentHash) {
        context.addIssue({
            code: "custom",
            message: "listing lifecycle content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (ledger.ledgerId !== `listing-ledger:${ledger.contentHash.slice(7, 31)}`) {
        context.addIssue({
            code: "custom",
            message: "listing lifecycle ledger id mismatch",
            path: ["ledgerId"],
        });
    }
});
function createM1ListingAnnouncementObservation(input) {
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1ListingAnnouncementObservationSchema.parse(Object.assign(Object.assign({}, input), { schemaVersion: exports.M1_ANNOUNCEMENT_OBSERVATION_VERSION, scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH, candidateEmissionAllowed: false, strategyAuthority: false })));
}
function observationKey(observation) {
    return `${observation.sourceId}:${observation.venueInstrumentId}`;
}
function eventId(event) {
    return `listing-event:${(0, stable_artifact_1.stableSha256)(event).slice(0, 24)}`;
}
function catalogEvent(input) {
    var _a, _b;
    const event = {
        sourceId: input.current.sourceId,
        venueInstrumentId: input.current.venueInstrumentId,
        listingEpoch: input.current.listingEpoch,
        previousState: (_b = (_a = input.previous) === null || _a === void 0 ? void 0 : _a.lifecycleState) !== null && _b !== void 0 ? _b : null,
        currentState: input.current.lifecycleState,
        eventSource: "DERIVATIVE_CATALOG",
        providerEffectiveAt: input.current.statusEffectiveAt,
        knowledgeTime: input.current.knowledgeTime,
        announcementIds: [],
        correlationStatus: "CATALOG_ONLY",
        sourceRecordDigests: [input.current.sourceRecordDigest],
        candidateEmissionAllowed: false,
        reasonCodes: input.previous === null
            ? ["first_catalog_observation_no_announcement_link"]
            : ["provider_catalog_lifecycle_transition"],
    };
    return exports.M1ListingLifecycleEventSchema.parse(Object.assign(Object.assign({}, event), { eventId: eventId(event) }));
}
function absenceEvent(previous, sourceCutoff) {
    const event = {
        sourceId: previous.sourceId,
        venueInstrumentId: previous.venueInstrumentId,
        listingEpoch: previous.listingEpoch,
        previousState: previous.lifecycleState,
        currentState: "UNRESOLVED",
        eventSource: "CATALOG_ABSENCE",
        providerEffectiveAt: null,
        knowledgeTime: sourceCutoff,
        announcementIds: [],
        correlationStatus: "MISSING_FROM_COMPLETE_CATALOG_NOT_DELISTING_PROOF",
        sourceRecordDigests: [previous.sourceRecordDigest],
        candidateEmissionAllowed: false,
        reasonCodes: [
            "catalog_absence_is_not_delisting_proof",
            "requires_explicit_status_or_announcement_confirmation",
        ],
    };
    return exports.M1ListingLifecycleEventSchema.parse(Object.assign(Object.assign({}, event), { eventId: eventId(event) }));
}
function announcementEvent(announcement) {
    const structuredInstrument = announcement.structuredVenueInstrumentIds.length === 1
        ? announcement.structuredVenueInstrumentIds[0]
        : null;
    const exactLink = announcement.instrumentLinkAuthority === "PROVIDER_STRUCTURED_FIELD" &&
        structuredInstrument !== null;
    const event = {
        sourceId: announcement.sourceId,
        venueInstrumentId: exactLink ? structuredInstrument : null,
        listingEpoch: null,
        previousState: null,
        currentState: announcement.announcementKind === "DELISTING"
            ? "DELISTING"
            : announcement.announcementKind === "LISTING"
                ? "ANNOUNCED_WAITING_CATALOG"
                : "UNRESOLVED",
        eventSource: "ANNOUNCEMENT",
        providerEffectiveAt: announcement.providerEffectiveAt,
        knowledgeTime: announcement.knowledgeTime,
        announcementIds: [announcement.announcementId],
        correlationStatus: exactLink
            ? "EXACT_STRUCTURED_LINK"
            : "UNLINKED_ANNOUNCEMENT",
        sourceRecordDigests: [announcement.sourceRecordDigest],
        candidateEmissionAllowed: false,
        reasonCodes: exactLink
            ? ["provider_structured_instrument_link_requires_catalog_epoch_match"]
            : ["announcement_title_not_parsed_for_symbol_guessing"],
    };
    if (exactLink) {
        const listingEpoch = `announcement-pending:${(0, stable_artifact_1.stableSha256)({
            sourceId: announcement.sourceId,
            venueInstrumentId: structuredInstrument,
            announcementId: announcement.announcementId,
        }).slice(0, 20)}`;
        return exports.M1ListingLifecycleEventSchema.parse(Object.assign(Object.assign({}, event), { listingEpoch, eventId: eventId(Object.assign(Object.assign({}, event), { listingEpoch })) }));
    }
    return exports.M1ListingLifecycleEventSchema.parse(Object.assign(Object.assign({}, event), { eventId: eventId(event) }));
}
function emptyVenueCounts() {
    return {
        BINANCE_FUTURES: 0,
        OKX_SWAP: 0,
        BYBIT_DERIVATIVES: 0,
        BITGET_FUTURES: 0,
    };
}
function buildM1ListingLifecycleLedger(input) {
    var _a, _b, _c;
    const current = multi_asset_identity_contract_1.M1MultiAssetIdentitySnapshotSchema.parse(input.current);
    const previous = input.previous === null
        ? null
        : multi_asset_identity_contract_1.M1MultiAssetIdentitySnapshotSchema.parse(input.previous);
    if (current.releaseId !== input.releaseId) {
        throw new Error("current identity snapshot release must match ledger release");
    }
    if (previous !== null &&
        (previous.registryDigest !== current.registryDigest ||
            Date.parse(previous.sourceCutoff) >= Date.parse(current.sourceCutoff))) {
        throw new Error("previous identity snapshot must use the same registry and an earlier cutoff");
    }
    const completeCatalogSources = [...new Set(input.completeCatalogSources)]
        .sort();
    const previousByKey = new Map(((_a = previous === null || previous === void 0 ? void 0 : previous.observations) !== null && _a !== void 0 ? _a : []).map((observation) => [
        observationKey(observation),
        observation,
    ]));
    const currentByKey = new Map(current.observations.map((observation) => [
        observationKey(observation),
        observation,
    ]));
    const events = [];
    for (const observation of current.observations) {
        const prior = (_b = previousByKey.get(observationKey(observation))) !== null && _b !== void 0 ? _b : null;
        if (prior === null ||
            prior.listingEpoch !== observation.listingEpoch ||
            prior.lifecycleState !== observation.lifecycleState) {
            events.push(catalogEvent({ current: observation, previous: prior }));
        }
    }
    if (previous !== null) {
        for (const prior of previous.observations) {
            if (!currentByKey.has(observationKey(prior)) &&
                completeCatalogSources.includes(prior.sourceId)) {
                events.push(absenceEvent(prior, input.sourceCutoff));
            }
        }
    }
    events.push(...input.announcements.map(announcementEvent));
    events.sort((left, right) => left.knowledgeTime.localeCompare(right.knowledgeTime) ||
        left.sourceId.localeCompare(right.sourceId) ||
        left.eventId.localeCompare(right.eventId));
    const eventsByVenue = emptyVenueCounts();
    for (const event of events) {
        eventsByVenue[event.sourceId] += 1;
    }
    const core = {
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        releaseId: input.releaseId,
        generatedAt: input.generatedAt,
        sourceCutoff: input.sourceCutoff,
        currentIdentitySnapshotId: current.snapshotId,
        previousIdentitySnapshotId: (_c = previous === null || previous === void 0 ? void 0 : previous.snapshotId) !== null && _c !== void 0 ? _c : null,
        completeCatalogSources,
        announcementCount: input.announcements.length,
        eventCount: events.length,
        unlinkedAnnouncementCount: events.filter((event) => event.correlationStatus === "UNLINKED_ANNOUNCEMENT").length,
        eventsByVenue,
        events,
        authorityBoundary: "LISTING_INTELLIGENCE_ONLY_NO_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY",
        productionChanged: false,
    };
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1ListingLifecycleLedgerSchema.parse(Object.assign(Object.assign({}, core), { schemaVersion: exports.M1_LISTING_LIFECYCLE_LEDGER_VERSION, ledgerId: `listing-ledger:${contentHash.slice(7, 31)}`, contentHash })));
}
