"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.M1SourceConformanceArtifactSchema = exports.M1SourceConformanceProbeObservationSchema = exports.M1_SOURCE_CONFORMANCE_FAILURES = exports.M1_COINGLASS_GATE_PROBE_IDS = exports.M1_LISTING_GATE_PROBE_IDS = exports.M1_IDENTITY_GATE_PROBE_IDS = exports.M1_SOURCE_CONFORMANCE_PROBE_IDS = exports.M1_SOURCE_CONFORMANCE_VERSION = void 0;
exports.buildM1SourceConformanceArtifact = buildM1SourceConformanceArtifact;
exports.failureSemantic = failureSemantic;
const zod_1 = require("zod");
const primitives_1 = require("../../runtime-schema/primitives");
const source_capability_contract_1 = require("../source-capability/source-capability-contract");
const stable_artifact_1 = require("../universe/stable-artifact");
exports.M1_SOURCE_CONFORMANCE_VERSION = "v2-m1-exact-source-conformance.v1";
exports.M1_SOURCE_CONFORMANCE_PROBE_IDS = [
    "BINANCE_SERVER_TIME",
    "BINANCE_DERIVATIVE_CATALOG",
    "BINANCE_SPOT_CATALOG",
    "OKX_SERVER_TIME",
    "OKX_DERIVATIVE_CATALOG",
    "OKX_SPOT_CATALOG",
    "BYBIT_SERVER_TIME",
    "BYBIT_DERIVATIVE_CATALOG",
    "BYBIT_SPOT_CATALOG",
    "BYBIT_LISTING_ANNOUNCEMENT",
    "BITGET_SERVER_TIME",
    "BITGET_DERIVATIVE_CATALOG",
    "BITGET_SPOT_CATALOG",
    "BITGET_LISTING_ANNOUNCEMENT",
    "COINGLASS_SUPPORTED_COINS",
];
exports.M1_IDENTITY_GATE_PROBE_IDS = [
    "BINANCE_SERVER_TIME",
    "BINANCE_DERIVATIVE_CATALOG",
    "OKX_SERVER_TIME",
    "OKX_DERIVATIVE_CATALOG",
    "BYBIT_SERVER_TIME",
    "BYBIT_DERIVATIVE_CATALOG",
    "BITGET_SERVER_TIME",
    "BITGET_DERIVATIVE_CATALOG",
];
exports.M1_LISTING_GATE_PROBE_IDS = [
    "BINANCE_SPOT_CATALOG",
    "OKX_SPOT_CATALOG",
    "BYBIT_SPOT_CATALOG",
    "BYBIT_LISTING_ANNOUNCEMENT",
    "BITGET_SPOT_CATALOG",
    "BITGET_LISTING_ANNOUNCEMENT",
];
exports.M1_COINGLASS_GATE_PROBE_IDS = [
    "COINGLASS_SUPPORTED_COINS",
];
exports.M1_SOURCE_CONFORMANCE_FAILURES = [
    ...source_capability_contract_1.M1_FAILURE_SEMANTICS,
    "MISSING_REQUIRED_READ_ONLY_CREDENTIAL",
    "PROVIDER_BODY_ERROR_UNAVAILABLE",
    "PROBE_DEFINITION_DRIFT",
];
const DigestSchema = zod_1.z.string().regex(/^sha256:[0-9a-f]{64}$/u);
const ProbeIdSchema = zod_1.z.enum(exports.M1_SOURCE_CONFORMANCE_PROBE_IDS);
const UniqueStringsSchema = zod_1.z.array(zod_1.z.string()).superRefine((values, context) => {
    if (new Set(values).size !== values.length) {
        context.addIssue({
            code: "custom",
            message: "values must be unique",
        });
    }
});
exports.M1SourceConformanceProbeObservationSchema = zod_1.z.strictObject({
    probeId: ProbeIdSchema,
    sourceId: zod_1.z.enum(source_capability_contract_1.M1_SOURCE_IDS),
    capabilityId: zod_1.z.enum(source_capability_contract_1.M1_CAPABILITY_IDS),
    gate: zod_1.z.enum([
        "MULTI_ASSET_IDENTITY",
        "LISTING_INTELLIGENCE",
        "COINGLASS_CONTEXT",
    ]),
    definitionDigest: DigestSchema,
    evidenceClass: zod_1.z.enum(["LIVE_READ_ONLY", "TEST_ONLY"]),
    outcome: zod_1.z.enum(["PASS", "FAIL", "NOT_RUN"]),
    attemptStartedAt: primitives_1.IsoDateTimeSchema.nullable(),
    receivedAt: primitives_1.IsoDateTimeSchema.nullable(),
    latencyMs: primitives_1.NonNegativeIntegerSchema.nullable(),
    httpStatus: zod_1.z.number().int().min(100).max(599).nullable(),
    responseBodyDigest: DigestSchema.nullable(),
    responseBytes: primitives_1.NonNegativeIntegerSchema.nullable(),
    topLevelKeys: UniqueStringsSchema,
    recordKeys: UniqueStringsSchema,
    observedRecordCount: primitives_1.NonNegativeIntegerSchema.nullable(),
    providerServerTime: primitives_1.IsoDateTimeSchema.nullable(),
    absoluteClockSkewMs: primitives_1.NonNegativeIntegerSchema.nullable(),
    paginationStatus: zod_1.z.enum([
        "NOT_APPLICABLE",
        "COMPLETE",
        "BOUNDED_COMPLETE",
        "INCOMPLETE",
        "NOT_RUN",
    ]),
    credentialDisposition: zod_1.z.enum([
        "PUBLIC_NO_CREDENTIAL",
        "READ_ONLY_KEY_USED_NOT_RETAINED",
        "MISSING_REQUIRED_READ_ONLY_KEY",
    ]),
    failure: zod_1.z.enum(exports.M1_SOURCE_CONFORMANCE_FAILURES).nullable(),
    reasonCodes: primitives_1.ReasonCodesSchema,
    rawBodyRetained: zod_1.z.literal(false),
    secretMaterialPresent: zod_1.z.literal(false),
}).superRefine((observation, context) => {
    const hasAttempt = observation.attemptStartedAt !== null;
    if (hasAttempt !==
        (observation.receivedAt !== null &&
            observation.latencyMs !== null)) {
        context.addIssue({
            code: "custom",
            message: "attempt chronology fields must be present together",
            path: ["attemptStartedAt"],
        });
    }
    if (observation.attemptStartedAt !== null &&
        observation.receivedAt !== null &&
        Date.parse(observation.attemptStartedAt) >
            Date.parse(observation.receivedAt)) {
        context.addIssue({
            code: "custom",
            message: "probe cannot be received before it starts",
            path: ["receivedAt"],
        });
    }
    if (observation.outcome === "PASS") {
        for (const [field, value] of [
            ["httpStatus", observation.httpStatus],
            ["responseBodyDigest", observation.responseBodyDigest],
            ["responseBytes", observation.responseBytes],
            ["observedRecordCount", observation.observedRecordCount],
        ]) {
            if (value === null) {
                context.addIssue({
                    code: "custom",
                    message: `PASS probe requires ${field}`,
                    path: [field],
                });
            }
        }
        if (observation.httpStatus !== null &&
            (observation.httpStatus < 200 || observation.httpStatus >= 300)) {
            context.addIssue({
                code: "custom",
                message: "PASS probe requires a 2xx response",
                path: ["httpStatus"],
            });
        }
        if (observation.failure !== null || observation.reasonCodes.length > 0) {
            context.addIssue({
                code: "custom",
                message: "PASS probe cannot carry failure reasons",
                path: ["failure"],
            });
        }
        if (observation.paginationStatus === "INCOMPLETE" ||
            observation.paginationStatus === "NOT_RUN") {
            context.addIssue({
                code: "custom",
                message: "PASS probe requires completed pagination semantics",
                path: ["paginationStatus"],
            });
        }
    }
    else if (observation.failure === null ||
        observation.reasonCodes.length === 0) {
        context.addIssue({
            code: "custom",
            message: "non-PASS probe requires a failure and reason",
            path: ["failure"],
        });
    }
    if (observation.outcome === "NOT_RUN" &&
        (observation.attemptStartedAt !== null ||
            observation.httpStatus !== null ||
            observation.responseBodyDigest !== null)) {
        context.addIssue({
            code: "custom",
            message: "NOT_RUN cannot carry attempted response evidence",
            path: ["outcome"],
        });
    }
    if (observation.credentialDisposition ===
        "MISSING_REQUIRED_READ_ONLY_KEY" &&
        (observation.outcome !== "NOT_RUN" ||
            observation.failure !== "MISSING_REQUIRED_READ_ONLY_CREDENTIAL")) {
        context.addIssue({
            code: "custom",
            message: "missing credential must remain an explicit NOT_RUN",
            path: ["credentialDisposition"],
        });
    }
    if (observation.paginationStatus === "BOUNDED_COMPLETE" &&
        (observation.outcome !== "PASS" ||
            observation.capabilityId !== "LISTING_ANNOUNCEMENT")) {
        context.addIssue({
            code: "custom",
            message: "bounded pagination completion is reserved for passing listing announcement probes",
            path: ["paginationStatus"],
        });
    }
});
const GateStatusSchema = zod_1.z.enum([
    "PASS",
    "BLOCKED",
    "NOT_EVALUATED_TEST_ONLY",
]);
exports.M1SourceConformanceArtifactSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_SOURCE_CONFORMANCE_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: primitives_1.NonEmptyStringSchema,
    generatedAt: primitives_1.IsoDateTimeSchema,
    sourceCutoff: primitives_1.IsoDateTimeSchema,
    registryDigest: DigestSchema,
    probePlanDigest: DigestSchema,
    evidenceClass: zod_1.z.enum(["LIVE_READ_ONLY", "TEST_ONLY"]),
    networkEnvironment: zod_1.z.enum([
        "LOCAL_WORKSTATION",
        "TENCENT_ISOLATED_READ_ONLY",
        "TEST_HARNESS",
    ]),
    expectedProbeCount: zod_1.z.literal(15),
    observedProbeCount: zod_1.z.literal(15),
    passCount: primitives_1.NonNegativeIntegerSchema,
    failCount: primitives_1.NonNegativeIntegerSchema,
    notRunCount: primitives_1.NonNegativeIntegerSchema,
    identityGateStatus: GateStatusSchema,
    listingGateStatus: GateStatusSchema,
    coinGlassGateStatus: GateStatusSchema,
    probes: zod_1.z.array(exports.M1SourceConformanceProbeObservationSchema).length(15),
    artifactId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
    authorityBoundary: zod_1.z.literal("READ_ONLY_SOURCE_CONFORMANCE_ONLY_NO_MARKET_FACT_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY"),
    runtimeNetworkRequestsPerformed: zod_1.z.boolean(),
    productionChanged: zod_1.z.literal(false),
    secretMaterialPresent: zod_1.z.literal(false),
}).superRefine((artifact, context) => {
    if (Date.parse(artifact.sourceCutoff) > Date.parse(artifact.generatedAt)) {
        context.addIssue({
            code: "custom",
            message: "sourceCutoff cannot be later than generatedAt",
            path: ["sourceCutoff"],
        });
    }
    const probeIds = artifact.probes.map((probe) => probe.probeId);
    if (new Set(probeIds).size !== exports.M1_SOURCE_CONFORMANCE_PROBE_IDS.length ||
        exports.M1_SOURCE_CONFORMANCE_PROBE_IDS.some((probeId) => !probeIds.includes(probeId))) {
        context.addIssue({
            code: "custom",
            message: "artifact must account every exact probe once",
            path: ["probes"],
        });
    }
    const counts = {
        pass: artifact.probes.filter((probe) => probe.outcome === "PASS").length,
        fail: artifact.probes.filter((probe) => probe.outcome === "FAIL").length,
        notRun: artifact.probes.filter((probe) => probe.outcome === "NOT_RUN")
            .length,
    };
    if (artifact.passCount !== counts.pass ||
        artifact.failCount !== counts.fail ||
        artifact.notRunCount !== counts.notRun) {
        context.addIssue({
            code: "custom",
            message: "probe outcome counts do not match observations",
            path: ["passCount"],
        });
    }
    if (artifact.runtimeNetworkRequestsPerformed !==
        artifact.probes.some((probe) => probe.attemptStartedAt !== null)) {
        context.addIssue({
            code: "custom",
            message: "runtime request truth does not match probe attempts",
            path: ["runtimeNetworkRequestsPerformed"],
        });
    }
    if (artifact.probes.some((probe) => probe.evidenceClass !== artifact.evidenceClass)) {
        context.addIssue({
            code: "custom",
            message: "probe and artifact evidence classes must match",
            path: ["evidenceClass"],
        });
    }
    const byId = new Map(artifact.probes.map((probe) => [probe.probeId, probe]));
    const expectedGate = (probeIds) => artifact.evidenceClass === "TEST_ONLY"
        ? "NOT_EVALUATED_TEST_ONLY"
        : probeIds.every((probeId) => { var _a; return ((_a = byId.get(probeId)) === null || _a === void 0 ? void 0 : _a.outcome) === "PASS"; })
            ? "PASS"
            : "BLOCKED";
    for (const [field, actual, expected] of [
        [
            "identityGateStatus",
            artifact.identityGateStatus,
            expectedGate(exports.M1_IDENTITY_GATE_PROBE_IDS),
        ],
        [
            "listingGateStatus",
            artifact.listingGateStatus,
            expectedGate(exports.M1_LISTING_GATE_PROBE_IDS),
        ],
        [
            "coinGlassGateStatus",
            artifact.coinGlassGateStatus,
            expectedGate(exports.M1_COINGLASS_GATE_PROBE_IDS),
        ],
    ]) {
        if (actual !== expected) {
            context.addIssue({
                code: "custom",
                message: `${field} does not match probe outcomes`,
                path: [field],
            });
        }
    }
    const sortedProbeIds = [...probeIds].sort();
    if (probeIds.some((probeId, index) => probeId !== sortedProbeIds[index])) {
        context.addIssue({
            code: "custom",
            message: "probes must use canonical probe-id ordering",
            path: ["probes"],
        });
    }
    const expectedContentHash = (0, stable_artifact_1.stableContentHash)({
        scopeEpoch: artifact.scopeEpoch,
        releaseId: artifact.releaseId,
        generatedAt: artifact.generatedAt,
        sourceCutoff: artifact.sourceCutoff,
        registryDigest: artifact.registryDigest,
        probePlanDigest: artifact.probePlanDigest,
        evidenceClass: artifact.evidenceClass,
        networkEnvironment: artifact.networkEnvironment,
        expectedProbeCount: artifact.expectedProbeCount,
        observedProbeCount: artifact.observedProbeCount,
        passCount: artifact.passCount,
        failCount: artifact.failCount,
        notRunCount: artifact.notRunCount,
        identityGateStatus: artifact.identityGateStatus,
        listingGateStatus: artifact.listingGateStatus,
        coinGlassGateStatus: artifact.coinGlassGateStatus,
        probes: artifact.probes,
        authorityBoundary: artifact.authorityBoundary,
        runtimeNetworkRequestsPerformed: artifact.runtimeNetworkRequestsPerformed,
        productionChanged: artifact.productionChanged,
        secretMaterialPresent: artifact.secretMaterialPresent,
    });
    if (artifact.contentHash !== expectedContentHash) {
        context.addIssue({
            code: "custom",
            message: "source conformance content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (artifact.artifactId !==
        `source-conformance:${artifact.contentHash.slice(7, 31)}`) {
        context.addIssue({
            code: "custom",
            message: "source conformance artifact id mismatch",
            path: ["artifactId"],
        });
    }
});
function gateStatus(evidenceClass, probeIds, observations) {
    if (evidenceClass === "TEST_ONLY") {
        return "NOT_EVALUATED_TEST_ONLY";
    }
    const byId = new Map(observations.map((probe) => [probe.probeId, probe]));
    return probeIds.every((probeId) => { var _a; return ((_a = byId.get(probeId)) === null || _a === void 0 ? void 0 : _a.outcome) === "PASS"; })
        ? "PASS"
        : "BLOCKED";
}
function buildM1SourceConformanceArtifact(input) {
    const probes = [...input.probes].sort((left, right) => left.probeId.localeCompare(right.probeId));
    const core = {
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        releaseId: input.releaseId,
        generatedAt: input.generatedAt,
        sourceCutoff: input.sourceCutoff,
        registryDigest: input.registryDigest,
        probePlanDigest: input.probePlanDigest,
        evidenceClass: input.evidenceClass,
        networkEnvironment: input.networkEnvironment,
        expectedProbeCount: 15,
        observedProbeCount: 15,
        passCount: probes.filter((probe) => probe.outcome === "PASS").length,
        failCount: probes.filter((probe) => probe.outcome === "FAIL").length,
        notRunCount: probes.filter((probe) => probe.outcome === "NOT_RUN").length,
        identityGateStatus: gateStatus(input.evidenceClass, exports.M1_IDENTITY_GATE_PROBE_IDS, probes),
        listingGateStatus: gateStatus(input.evidenceClass, exports.M1_LISTING_GATE_PROBE_IDS, probes),
        coinGlassGateStatus: gateStatus(input.evidenceClass, exports.M1_COINGLASS_GATE_PROBE_IDS, probes),
        probes,
        authorityBoundary: "READ_ONLY_SOURCE_CONFORMANCE_ONLY_NO_MARKET_FACT_CANDIDATE_SIGNAL_STRATEGY_OR_READY_AUTHORITY",
        runtimeNetworkRequestsPerformed: probes.some((probe) => probe.attemptStartedAt !== null),
        productionChanged: false,
        secretMaterialPresent: false,
    };
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1SourceConformanceArtifactSchema.parse(Object.assign(Object.assign({}, core), { schemaVersion: exports.M1_SOURCE_CONFORMANCE_VERSION, artifactId: `source-conformance:${contentHash.slice(7, 31)}`, contentHash })));
}
function failureSemantic(value) {
    return source_capability_contract_1.M1_FAILURE_SEMANTICS.includes(value)
        ? value
        : null;
}
