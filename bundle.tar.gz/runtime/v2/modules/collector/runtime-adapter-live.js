"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.M1RuntimeAdapterLiveArtifactSchema = exports.M1RuntimeAdapterAcceptanceAxisSchema = exports.M1RuntimeAdapterProfileExecutionSchema = exports.M1_RUNTIME_ADAPTER_BLOCKED_PROBE_IDS = exports.M1_RUNTIME_ADAPTER_ACCEPTANCE_AXIS_VERSION = exports.M1_RUNTIME_ADAPTER_PROFILE_EXECUTION_VERSION = exports.M1_RUNTIME_ADAPTER_LIVE_ARTIFACT_VERSION = void 0;
exports.runM1RuntimeAdapterLiveSegment = runM1RuntimeAdapterLiveSegment;
exports.extractM1ListingHistoryCheckpoints = extractM1ListingHistoryCheckpoints;
const zod_1 = require("zod");
const primitives_1 = require("../../runtime-schema/primitives");
const source_capability_contract_1 = require("../source-capability/source-capability-contract");
const source_conformance_contract_1 = require("../source-conformance/source-conformance-contract");
const exact_source_conformance_runner_1 = require("../source-conformance/adapters/exact-source-conformance-runner");
const runtime_adapter_profile_1 = require("./runtime-adapter-profile");
const listing_history_runtime_1 = require("../multi-asset-universe/listing-history-runtime");
const stable_artifact_1 = require("../universe/stable-artifact");
exports.M1_RUNTIME_ADAPTER_LIVE_ARTIFACT_VERSION = "v2-m1-runtime-adapter-live-artifact.v1";
exports.M1_RUNTIME_ADAPTER_PROFILE_EXECUTION_VERSION = "v2-m1-runtime-adapter-profile-execution.v1";
exports.M1_RUNTIME_ADAPTER_ACCEPTANCE_AXIS_VERSION = "v2-m1-runtime-adapter-acceptance-axis.v1";
exports.M1_RUNTIME_ADAPTER_BLOCKED_PROBE_IDS = [
    "BINANCE_SPOT_CATALOG",
];
const M1_RUNTIME_ADAPTER_AXIS_ORDER = [
    "BITGET_VENUE",
    "LISTING_LIFECYCLE",
    "EQUITY_ASSET_DOMAIN",
    "DATA_MAXIMIZATION",
];
const M1_RUNTIME_ADAPTER_FIXED_AXIS_PROBES = Object.freeze({
    BITGET_VENUE: Object.freeze([
        "BITGET_DERIVATIVE_CATALOG",
        "BITGET_LISTING_ANNOUNCEMENT",
        "BITGET_SERVER_TIME",
        "BITGET_SPOT_CATALOG",
    ]),
    LISTING_LIFECYCLE: Object.freeze([
        "BITGET_LISTING_ANNOUNCEMENT",
        "BITGET_SPOT_CATALOG",
        "BYBIT_LISTING_ANNOUNCEMENT",
        "BYBIT_SPOT_CATALOG",
        "OKX_SPOT_CATALOG",
    ]),
    EQUITY_ASSET_DOMAIN: Object.freeze([
        "BINANCE_DERIVATIVE_CATALOG",
        "BITGET_DERIVATIVE_CATALOG",
        "BYBIT_DERIVATIVE_CATALOG",
        "OKX_DERIVATIVE_CATALOG",
    ]),
});
const DigestSchema = zod_1.z.string().regex(/^sha256:[0-9a-f]{64}$/u);
const ReleaseIdSchema = zod_1.z.string().regex(/^[0-9a-f]{40}$/u);
const ProbeIdSchema = zod_1.z.enum([
    "BINANCE_SERVER_TIME",
    "BINANCE_DERIVATIVE_CATALOG",
    "BINANCE_SPOT_CATALOG",
    "OKX_SERVER_TIME",
    "OKX_DERIVATIVE_CATALOG",
    "OKX_SPOT_CATALOG",
    "BYBIT_SERVER_TIME",
    "BYBIT_DERIVATIVE_CATALOG",
    "BYBIT_SPOT_CATALOG",
    "BYBIT_LISTING_ANNOUNCEMENT",
    "BITGET_SERVER_TIME",
    "BITGET_DERIVATIVE_CATALOG",
    "BITGET_SPOT_CATALOG",
    "BITGET_LISTING_ANNOUNCEMENT",
    "COINGLASS_SUPPORTED_COINS",
]);
const UniqueProbeIdsSchema = zod_1.z.array(ProbeIdSchema)
    .superRefine((values, context) => {
    if (new Set(values).size !== values.length ||
        values.some((value, index) => index > 0 && values[index - 1].localeCompare(value) >= 0)) {
        context.addIssue({
            code: "custom",
            message: "probe ids must be unique and canonically ordered",
        });
    }
});
const ProfileExecutionCoreSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_RUNTIME_ADAPTER_PROFILE_EXECUTION_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    profileId: primitives_1.NonEmptyStringSchema,
    probeId: ProbeIdSchema,
    sourceId: zod_1.z.enum(source_capability_contract_1.M1_SOURCE_IDS),
    capabilityId: zod_1.z.enum(source_capability_contract_1.M1_CAPABILITY_IDS),
    operation: zod_1.z.enum([
        "SOURCE_WIDE_SNAPSHOT",
        "PAGINATED_SOURCE_WIDE_SNAPSHOT",
        "LISTING_HISTORY_SEGMENT",
    ]),
    evidenceClass: zod_1.z.enum(["LIVE_READ_ONLY", "TEST_ONLY"]),
    outcome: zod_1.z.enum(["PASS", "FAIL", "NOT_RUN"]),
    requestAttempts: primitives_1.NonNegativeIntegerSchema,
    requestTokenBudget: zod_1.z.number().int().positive().max(64),
    pageCount: primitives_1.NonNegativeIntegerSchema,
    responseBytes: primitives_1.NonNegativeIntegerSchema,
    observedRecordCount: primitives_1.NonNegativeIntegerSchema,
    sourceCutoff: primitives_1.IsoDateTimeSchema.nullable(),
    failure: primitives_1.NonEmptyStringSchema.nullable(),
    listingMode: zod_1.z.enum(["BOOTSTRAP", "INCREMENTAL"]).nullable(),
    listingSegmentStop: zod_1.z.enum([
        "SOURCE_TERMINAL",
        "SEGMENT_PAGE_LIMIT",
        "PRIOR_CHECKPOINT_OVERLAP",
        "TRANSPORT_FAILURE",
    ]).nullable(),
    listingAdvance: listing_history_runtime_1.M1ListingHistoryAdvanceResultSchema.nullable(),
    rawBodyRetained: zod_1.z.literal(false),
    secretMaterialPresent: zod_1.z.literal(false),
    runtimeAuthorityGranted: zod_1.z.literal(false),
    factAuthorityGranted: zod_1.z.literal(false),
    candidateAuthorityGranted: zod_1.z.literal(false),
    strategyAuthorityGranted: zod_1.z.literal(false),
    readyAuthorityGranted: zod_1.z.literal(false),
    productionChanged: zod_1.z.literal(false),
});
exports.M1RuntimeAdapterProfileExecutionSchema = ProfileExecutionCoreSchema.extend({
    executionId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
}).superRefine((execution, context) => {
    var _a;
    if (execution.requestAttempts > execution.requestTokenBudget ||
        execution.pageCount > execution.requestAttempts) {
        context.addIssue({
            code: "custom",
            message: "runtime request accounting exceeded the exact profile budget",
            path: ["requestAttempts"],
        });
    }
    const listing = execution.operation === "LISTING_HISTORY_SEGMENT";
    if (listing !== (execution.listingMode !== null) ||
        listing !== (execution.listingSegmentStop !== null) ||
        (execution.listingAdvance !== null &&
            !listing)) {
        context.addIssue({
            code: "custom",
            message: "listing execution metadata does not match the operation",
            path: ["listingMode"],
        });
    }
    if (execution.outcome === "PASS" &&
        (execution.failure !== null ||
            (listing &&
                ((_a = execution.listingAdvance) === null || _a === void 0 ? void 0 : _a.status) !== "COMMITTED"))) {
        context.addIssue({
            code: "custom",
            message: "passing runtime execution cannot hide a failure or gap",
            path: ["outcome"],
        });
    }
    if (execution.outcome !== "PASS" &&
        execution.failure === null) {
        context.addIssue({
            code: "custom",
            message: "non-passing runtime execution requires an explicit failure",
            path: ["failure"],
        });
    }
    const expectedHash = (0, stable_artifact_1.stableContentHash)(profileExecutionCore(execution));
    if (execution.contentHash !== expectedHash) {
        context.addIssue({
            code: "custom",
            message: "runtime profile execution content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (execution.executionId !==
        `runtime-execution:${execution.probeId}:${expectedHash.slice(7, 23)}`) {
        context.addIssue({
            code: "custom",
            message: "runtime profile execution id mismatch",
            path: ["executionId"],
        });
    }
});
function profileExecutionCore(execution) {
    return ProfileExecutionCoreSchema.parse({
        schemaVersion: execution.schemaVersion,
        scopeEpoch: execution.scopeEpoch,
        profileId: execution.profileId,
        probeId: execution.probeId,
        sourceId: execution.sourceId,
        capabilityId: execution.capabilityId,
        operation: execution.operation,
        evidenceClass: execution.evidenceClass,
        outcome: execution.outcome,
        requestAttempts: execution.requestAttempts,
        requestTokenBudget: execution.requestTokenBudget,
        pageCount: execution.pageCount,
        responseBytes: execution.responseBytes,
        observedRecordCount: execution.observedRecordCount,
        sourceCutoff: execution.sourceCutoff,
        failure: execution.failure,
        listingMode: execution.listingMode,
        listingSegmentStop: execution.listingSegmentStop,
        listingAdvance: execution.listingAdvance,
        rawBodyRetained: execution.rawBodyRetained,
        secretMaterialPresent: execution.secretMaterialPresent,
        runtimeAuthorityGranted: execution.runtimeAuthorityGranted,
        factAuthorityGranted: execution.factAuthorityGranted,
        candidateAuthorityGranted: execution.candidateAuthorityGranted,
        strategyAuthorityGranted: execution.strategyAuthorityGranted,
        readyAuthorityGranted: execution.readyAuthorityGranted,
        productionChanged: execution.productionChanged,
    });
}
const AcceptanceAxisCoreSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_RUNTIME_ADAPTER_ACCEPTANCE_AXIS_VERSION),
    axisId: zod_1.z.enum([
        "BITGET_VENUE",
        "LISTING_LIFECYCLE",
        "EQUITY_ASSET_DOMAIN",
        "DATA_MAXIMIZATION",
    ]),
    expectedProbeIds: UniqueProbeIdsSchema,
    executedProbeIds: UniqueProbeIdsSchema,
    passedProbeIds: UniqueProbeIdsSchema,
    routeGateStatus: zod_1.z.enum(["PASS", "BLOCKED"]),
    scopeBoundary: zod_1.z.enum([
        "BITGET_PUBLIC_VENUE_ROUTES_NO_TRADING_AUTHORITY",
        "LISTING_DISCOVERY_AND_HISTORY_ONLY_NO_CANDIDATE_AUTHORITY",
        "CATALOG_ACCOUNTING_ONLY_SESSION_CORPORATE_ACTION_FX_BASIS_BLOCKED",
        "ALL_ROUTE_ELIGIBLE_PROFILES_ONLY_REGISTRY_BLOCK_RETAINED",
    ]),
    acceptanceGranted: zod_1.z.literal(false),
});
exports.M1RuntimeAdapterAcceptanceAxisSchema = AcceptanceAxisCoreSchema.extend({
    axisEvidenceId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
}).superRefine((axis, context) => {
    const passed = new Set(axis.passedProbeIds);
    const executed = new Set(axis.executedProbeIds);
    if (axis.passedProbeIds.some((probeId) => !executed.has(probeId)) ||
        axis.routeGateStatus !==
            (axis.expectedProbeIds.every((probeId) => passed.has(probeId))
                ? "PASS"
                : "BLOCKED")) {
        context.addIssue({
            code: "custom",
            message: "acceptance axis denominator does not reconcile",
            path: ["routeGateStatus"],
        });
    }
    const expectedHash = (0, stable_artifact_1.stableContentHash)(acceptanceAxisCore(axis));
    if (axis.contentHash !== expectedHash) {
        context.addIssue({
            code: "custom",
            message: "acceptance axis content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (axis.axisEvidenceId !==
        `runtime-axis:${axis.axisId}:${expectedHash.slice(7, 23)}`) {
        context.addIssue({
            code: "custom",
            message: "acceptance axis evidence id mismatch",
            path: ["axisEvidenceId"],
        });
    }
});
function acceptanceAxisCore(axis) {
    return AcceptanceAxisCoreSchema.parse({
        schemaVersion: axis.schemaVersion,
        axisId: axis.axisId,
        expectedProbeIds: axis.expectedProbeIds,
        executedProbeIds: axis.executedProbeIds,
        passedProbeIds: axis.passedProbeIds,
        routeGateStatus: axis.routeGateStatus,
        scopeBoundary: axis.scopeBoundary,
        acceptanceGranted: axis.acceptanceGranted,
    });
}
const RuntimeAdapterLiveArtifactCoreSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_RUNTIME_ADAPTER_LIVE_ARTIFACT_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    runtimeReleaseId: ReleaseIdSchema,
    generatedAt: primitives_1.IsoDateTimeSchema,
    sourceCutoff: primitives_1.IsoDateTimeSchema,
    conformanceReleaseId: ReleaseIdSchema,
    conformanceArtifactId: primitives_1.NonEmptyStringSchema,
    conformanceArtifactHash: DigestSchema,
    profileSetId: primitives_1.NonEmptyStringSchema,
    profileSetHash: DigestSchema,
    registryDigest: DigestSchema,
    probePlanDigest: DigestSchema,
    evidenceClass: zod_1.z.enum(["LIVE_READ_ONLY", "TEST_ONLY"]),
    networkEnvironment: zod_1.z.enum([
        "TENCENT_ISOLATED_READ_ONLY",
        "TEST_HARNESS",
    ]),
    status: zod_1.z.enum([
        "PASS_BOUNDED_ROUTE_SEGMENT_NO_AUTHORITY",
        "BLOCKED_ROUTE_SEGMENT_NO_STALE_PROMOTION",
        "TEST_ONLY_NOT_LIVE_EVIDENCE",
    ]),
    liveConformantProfileCount: zod_1.z.literal(15),
    routeEligibleProfileCount: zod_1.z.literal(14),
    registryBlockedProfileCount: zod_1.z.literal(1),
    registryBlockedProbeIds: UniqueProbeIdsSchema,
    expectedExecutionProbeIds: UniqueProbeIdsSchema,
    executedProbeIds: UniqueProbeIdsSchema,
    passedProbeIds: UniqueProbeIdsSchema,
    failedProbeIds: UniqueProbeIdsSchema,
    requestAttemptCount: primitives_1.NonNegativeIntegerSchema,
    requestTokenBudget: primitives_1.NonNegativeIntegerSchema,
    listingCheckpointCommittedCount: primitives_1.NonNegativeIntegerSchema,
    listingGapCount: primitives_1.NonNegativeIntegerSchema,
    executions: zod_1.z.array(exports.M1RuntimeAdapterProfileExecutionSchema),
    acceptanceAxes: zod_1.z.array(exports.M1RuntimeAdapterAcceptanceAxisSchema).length(4),
    acceptanceAccounting: zod_1.z.literal("FOUR_INDEPENDENT_AXES_NO_CROSS_PASS"),
    rawBodyRetained: zod_1.z.literal(false),
    secretMaterialPresent: zod_1.z.literal(false),
    runtimeAuthorityGranted: zod_1.z.literal(false),
    factAuthorityGranted: zod_1.z.literal(false),
    candidateAuthorityGranted: zod_1.z.literal(false),
    strategyAuthorityGranted: zod_1.z.literal(false),
    readyAuthorityGranted: zod_1.z.literal(false),
    productionChanged: zod_1.z.literal(false),
});
exports.M1RuntimeAdapterLiveArtifactSchema = RuntimeAdapterLiveArtifactCoreSchema.extend({
    artifactId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
}).superRefine((artifact, context) => {
    if (artifact.executions.some((execution, index) => index > 0 &&
        artifact.executions[index - 1].probeId.localeCompare(execution.probeId) >= 0)) {
        context.addIssue({
            code: "custom",
            message: "runtime executions must remain canonically ordered",
            path: ["executions"],
        });
    }
    const executionProbeIds = artifact.executions
        .map((execution) => execution.probeId)
        .sort();
    const passedProbeIds = artifact.executions
        .filter((execution) => execution.outcome === "PASS")
        .map((execution) => execution.probeId)
        .sort();
    const failedProbeIds = artifact.executions
        .filter((execution) => execution.outcome !== "PASS")
        .map((execution) => execution.probeId)
        .sort();
    const requestAttemptCount = artifact.executions.reduce((total, execution) => total + execution.requestAttempts, 0);
    const requestTokenBudget = artifact.executions.reduce((total, execution) => total + execution.requestTokenBudget, 0);
    const committed = artifact.executions.filter((execution) => { var _a; return ((_a = execution.listingAdvance) === null || _a === void 0 ? void 0 : _a.status) === "COMMITTED"; }).length;
    const gaps = artifact.executions.filter((execution) => { var _a; return ((_a = execution.listingAdvance) === null || _a === void 0 ? void 0 : _a.status) === "BLOCKED_GAP"; }).length;
    if ((0, stable_artifact_1.stableContentHash)(executionProbeIds) !==
        (0, stable_artifact_1.stableContentHash)(artifact.executedProbeIds) ||
        (0, stable_artifact_1.stableContentHash)(passedProbeIds) !==
            (0, stable_artifact_1.stableContentHash)(artifact.passedProbeIds) ||
        (0, stable_artifact_1.stableContentHash)(failedProbeIds) !==
            (0, stable_artifact_1.stableContentHash)(artifact.failedProbeIds) ||
        requestAttemptCount !== artifact.requestAttemptCount ||
        requestTokenBudget !== artifact.requestTokenBudget ||
        committed !== artifact.listingCheckpointCommittedCount ||
        gaps !== artifact.listingGapCount) {
        context.addIssue({
            code: "custom",
            message: "runtime artifact denominator accounting does not reconcile",
        });
    }
    if (artifact.acceptanceAxes.some((axis, index) => axis.axisId !== M1_RUNTIME_ADAPTER_AXIS_ORDER[index])) {
        context.addIssue({
            code: "custom",
            message: "acceptance axes must remain complete and ordered",
            path: ["acceptanceAxes"],
        });
    }
    for (const axis of artifact.acceptanceAxes) {
        const expected = axis.axisId === "DATA_MAXIMIZATION"
            ? artifact.expectedExecutionProbeIds
            : M1_RUNTIME_ADAPTER_FIXED_AXIS_PROBES[axis.axisId];
        if ((0, stable_artifact_1.stableContentHash)(axis.expectedProbeIds) !==
            (0, stable_artifact_1.stableContentHash)(expected)) {
            context.addIssue({
                code: "custom",
                message: `${axis.axisId} acceptance denominator drifted`,
                path: ["acceptanceAxes"],
            });
        }
    }
    if ((0, stable_artifact_1.stableContentHash)(artifact.registryBlockedProbeIds) !==
        (0, stable_artifact_1.stableContentHash)([...exports.M1_RUNTIME_ADAPTER_BLOCKED_PROBE_IDS]) ||
        artifact.executedProbeIds.some((probeId) => exports.M1_RUNTIME_ADAPTER_BLOCKED_PROBE_IDS.includes(probeId))) {
        context.addIssue({
            code: "custom",
            message: "registry-blocked probe was not retained as blocked",
            path: ["registryBlockedProbeIds"],
        });
    }
    const liveRoutePass = artifact.executedProbeIds.length === 14 &&
        artifact.passedProbeIds.length === 14 &&
        artifact.failedProbeIds.length === 0 &&
        artifact.listingCheckpointCommittedCount === 2 &&
        artifact.listingGapCount === 0 &&
        artifact.acceptanceAxes.every((axis) => axis.routeGateStatus === "PASS");
    const expectedStatus = artifact.evidenceClass === "TEST_ONLY"
        ? "TEST_ONLY_NOT_LIVE_EVIDENCE"
        : liveRoutePass
            ? "PASS_BOUNDED_ROUTE_SEGMENT_NO_AUTHORITY"
            : "BLOCKED_ROUTE_SEGMENT_NO_STALE_PROMOTION";
    if (artifact.status !== expectedStatus) {
        context.addIssue({
            code: "custom",
            message: "runtime artifact status overstates observed evidence",
            path: ["status"],
        });
    }
    if (artifact.evidenceClass === "LIVE_READ_ONLY" &&
        artifact.networkEnvironment !== "TENCENT_ISOLATED_READ_ONLY") {
        context.addIssue({
            code: "custom",
            message: "live runtime evidence must come from Tencent isolation",
            path: ["networkEnvironment"],
        });
    }
    if (artifact.evidenceClass === "TEST_ONLY" &&
        artifact.networkEnvironment !== "TEST_HARNESS") {
        context.addIssue({
            code: "custom",
            message: "test transport cannot claim live network evidence",
            path: ["networkEnvironment"],
        });
    }
    const expectedHash = (0, stable_artifact_1.stableContentHash)(runtimeAdapterLiveArtifactCore(artifact));
    if (artifact.contentHash !== expectedHash) {
        context.addIssue({
            code: "custom",
            message: "runtime adapter live artifact content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (artifact.artifactId !==
        `runtime-adapter-live:${expectedHash.slice(7, 31)}`) {
        context.addIssue({
            code: "custom",
            message: "runtime adapter live artifact id mismatch",
            path: ["artifactId"],
        });
    }
});
function runtimeAdapterLiveArtifactCore(artifact) {
    return RuntimeAdapterLiveArtifactCoreSchema.parse({
        schemaVersion: artifact.schemaVersion,
        scopeEpoch: artifact.scopeEpoch,
        runtimeReleaseId: artifact.runtimeReleaseId,
        generatedAt: artifact.generatedAt,
        sourceCutoff: artifact.sourceCutoff,
        conformanceReleaseId: artifact.conformanceReleaseId,
        conformanceArtifactId: artifact.conformanceArtifactId,
        conformanceArtifactHash: artifact.conformanceArtifactHash,
        profileSetId: artifact.profileSetId,
        profileSetHash: artifact.profileSetHash,
        registryDigest: artifact.registryDigest,
        probePlanDigest: artifact.probePlanDigest,
        evidenceClass: artifact.evidenceClass,
        networkEnvironment: artifact.networkEnvironment,
        status: artifact.status,
        liveConformantProfileCount: artifact.liveConformantProfileCount,
        routeEligibleProfileCount: artifact.routeEligibleProfileCount,
        registryBlockedProfileCount: artifact.registryBlockedProfileCount,
        registryBlockedProbeIds: artifact.registryBlockedProbeIds,
        expectedExecutionProbeIds: artifact.expectedExecutionProbeIds,
        executedProbeIds: artifact.executedProbeIds,
        passedProbeIds: artifact.passedProbeIds,
        failedProbeIds: artifact.failedProbeIds,
        requestAttemptCount: artifact.requestAttemptCount,
        requestTokenBudget: artifact.requestTokenBudget,
        listingCheckpointCommittedCount: artifact.listingCheckpointCommittedCount,
        listingGapCount: artifact.listingGapCount,
        executions: artifact.executions,
        acceptanceAxes: artifact.acceptanceAxes,
        acceptanceAccounting: artifact.acceptanceAccounting,
        rawBodyRetained: artifact.rawBodyRetained,
        secretMaterialPresent: artifact.secretMaterialPresent,
        runtimeAuthorityGranted: artifact.runtimeAuthorityGranted,
        factAuthorityGranted: artifact.factAuthorityGranted,
        candidateAuthorityGranted: artifact.candidateAuthorityGranted,
        strategyAuthorityGranted: artifact.strategyAuthorityGranted,
        readyAuthorityGranted: artifact.readyAuthorityGranted,
        productionChanged: artifact.productionChanged,
    });
}
function buildExecution(input) {
    const core = profileExecutionCore(Object.assign(Object.assign({ schemaVersion: exports.M1_RUNTIME_ADAPTER_PROFILE_EXECUTION_VERSION, scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH }, input), { rawBodyRetained: false, secretMaterialPresent: false, runtimeAuthorityGranted: false, factAuthorityGranted: false, candidateAuthorityGranted: false, strategyAuthorityGranted: false, readyAuthorityGranted: false, productionChanged: false }));
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return exports.M1RuntimeAdapterProfileExecutionSchema.parse(Object.assign(Object.assign({}, core), { executionId: `runtime-execution:${core.probeId}:${contentHash.slice(7, 23)}`, contentHash }));
}
function listingProbeId(profile) {
    if (profile.probeId === "BYBIT_LISTING_ANNOUNCEMENT") {
        return profile.probeId;
    }
    if (profile.probeId === "BITGET_LISTING_ANNOUNCEMENT") {
        return profile.probeId;
    }
    throw new Error("listing runtime received a non-listing profile");
}
async function executeListingProfile(input) {
    var _a, _b;
    const prior = input.priorCheckpoint === null
        ? null
        : listing_history_runtime_1.M1ListingHistoryCheckpointSchema.parse(input.priorCheckpoint);
    const mode = prior === null || prior.status === "BOOTSTRAP_IN_PROGRESS"
        ? "BOOTSTRAP"
        : "INCREMENTAL";
    const initial = (0, listing_history_runtime_1.buildM1ListingHistoryRequest)({
        profile: input.profile,
        mode,
        checkpoint: prior,
    });
    const pages = [];
    const priorAnnouncementIds = new Set((_a = prior === null || prior === void 0 ? void 0 : prior.observations.map((observation) => observation.announcementId)) !== null && _a !== void 0 ? _a : []);
    let requestToken = initial.requestToken;
    let requestAttempts = 0;
    let responseBytes = 0;
    let failure = null;
    let segmentStop = "SEGMENT_PAGE_LIMIT";
    while (requestAttempts < input.profile.maxRequestsPerSegment) {
        const request = (0, listing_history_runtime_1.buildM1ListingHistoryPageRequest)({
            profile: input.profile,
            requestToken,
        });
        const fetched = await (0, exact_source_conformance_runner_1.fetchM1ExactListingRuntimePage)({
            probeId: listingProbeId(input.profile),
            url: request.url,
            networkEnvironment: input.networkEnvironment,
            transportImplementation: input.transportImplementation,
            now: input.now,
        });
        requestAttempts += fetched.requestAttempts;
        if (!fetched.ok) {
            failure = fetched.failure;
            segmentStop = "TRANSPORT_FAILURE";
            break;
        }
        if (fetched.evidenceClass !== input.evidenceClass) {
            throw new Error("listing runtime evidence class drifted");
        }
        responseBytes += fetched.page.responseBytes;
        const page = (0, listing_history_runtime_1.parseM1ListingHistoryPage)({
            profile: input.profile,
            mode,
            pageOrdinal: pages.length + 1,
            requestToken,
            receivedAt: fetched.page.receivedAt,
            responseBodyHash: fetched.page.responseBodyDigest,
            payload: fetched.page.payload,
        });
        pages.push(page);
        if (mode === "INCREMENTAL" &&
            page.observations.some((observation) => priorAnnouncementIds.has(observation.announcementId))) {
            segmentStop = "PRIOR_CHECKPOINT_OVERLAP";
            break;
        }
        if (page.providerTerminal) {
            segmentStop = "SOURCE_TERMINAL";
            break;
        }
        requestToken = page.nextRequestToken;
    }
    const sourceCutoff = (_b = pages
        .map((page) => page.receivedAt)
        .sort()
        .at(-1)) !== null && _b !== void 0 ? _b : null;
    if (failure !== null) {
        return buildExecution({
            profileId: input.profile.profileId,
            probeId: input.profile.probeId,
            sourceId: input.profile.sourceId,
            capabilityId: input.profile.capabilityId,
            operation: input.profile.operation,
            evidenceClass: input.evidenceClass,
            outcome: "FAIL",
            requestAttempts,
            requestTokenBudget: input.profile.maxRequestsPerSegment,
            pageCount: pages.length,
            responseBytes,
            observedRecordCount: pages.reduce((total, page) => total + page.normalizedRecordCount, 0),
            sourceCutoff,
            failure,
            listingMode: mode,
            listingSegmentStop: segmentStop,
            listingAdvance: null,
        });
    }
    const generatedAt = input.now().toISOString();
    if (segmentStop === "TRANSPORT_FAILURE") {
        throw new Error("listing transport failure escaped the blocked result");
    }
    const advance = (0, listing_history_runtime_1.advanceM1ListingHistory)({
        profile: input.profile,
        mode,
        priorCheckpoint: prior,
        pages,
        segmentStop,
        generatedAt,
        sourceCutoff: sourceCutoff !== null && sourceCutoff !== void 0 ? sourceCutoff : generatedAt,
    });
    const gapFailure = advance.status === "BLOCKED_GAP"
        ? `LISTING_HISTORY_GAP_${advance.gap.reason}`
        : null;
    return buildExecution({
        profileId: input.profile.profileId,
        probeId: input.profile.probeId,
        sourceId: input.profile.sourceId,
        capabilityId: input.profile.capabilityId,
        operation: input.profile.operation,
        evidenceClass: input.evidenceClass,
        outcome: advance.status === "COMMITTED" ? "PASS" : "FAIL",
        requestAttempts,
        requestTokenBudget: input.profile.maxRequestsPerSegment,
        pageCount: pages.length,
        responseBytes,
        observedRecordCount: pages.reduce((total, page) => total + page.normalizedRecordCount, 0),
        sourceCutoff,
        failure: gapFailure,
        listingMode: mode,
        listingSegmentStop: segmentStop,
        listingAdvance: advance,
    });
}
async function executeSnapshotProfile(input) {
    var _a, _b;
    const result = await (0, exact_source_conformance_runner_1.runM1ExactSourceRuntimeProbe)({
        probeId: input.profile.probeId,
        networkEnvironment: input.networkEnvironment,
        coinGlassApiKey: input.coinGlassApiKey,
        transportImplementation: input.transportImplementation,
        now: input.now,
    });
    const observation = source_conformance_contract_1.M1SourceConformanceProbeObservationSchema.parse(result.observation);
    if (observation.evidenceClass !== input.evidenceClass) {
        throw new Error("snapshot runtime evidence class drifted");
    }
    return buildExecution({
        profileId: input.profile.profileId,
        probeId: input.profile.probeId,
        sourceId: input.profile.sourceId,
        capabilityId: input.profile.capabilityId,
        operation: input.profile.operation,
        evidenceClass: input.evidenceClass,
        outcome: observation.outcome,
        requestAttempts: result.requestAttempts,
        requestTokenBudget: input.profile.maxRequestsPerSegment,
        pageCount: result.requestAttempts,
        responseBytes: (_a = observation.responseBytes) !== null && _a !== void 0 ? _a : 0,
        observedRecordCount: (_b = observation.observedRecordCount) !== null && _b !== void 0 ? _b : 0,
        sourceCutoff: observation.receivedAt,
        failure: observation.failure,
        listingMode: null,
        listingSegmentStop: null,
        listingAdvance: null,
    });
}
function buildAxis(input) {
    const expectedProbeIds = [...input.expectedProbeIds].sort();
    const expected = new Set(expectedProbeIds);
    const executedProbeIds = input.executions
        .filter((execution) => expected.has(execution.probeId))
        .map((execution) => execution.probeId)
        .sort();
    const passedProbeIds = input.executions
        .filter((execution) => expected.has(execution.probeId) && execution.outcome === "PASS")
        .map((execution) => execution.probeId)
        .sort();
    const core = acceptanceAxisCore({
        schemaVersion: exports.M1_RUNTIME_ADAPTER_ACCEPTANCE_AXIS_VERSION,
        axisId: input.axisId,
        expectedProbeIds,
        executedProbeIds,
        passedProbeIds,
        routeGateStatus: passedProbeIds.length === expectedProbeIds.length ? "PASS" : "BLOCKED",
        scopeBoundary: input.scopeBoundary,
        acceptanceGranted: false,
    });
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return exports.M1RuntimeAdapterAcceptanceAxisSchema.parse(Object.assign(Object.assign({}, core), { axisEvidenceId: `runtime-axis:${core.axisId}:${contentHash.slice(7, 23)}`, contentHash }));
}
async function runM1RuntimeAdapterLiveSegment(input) {
    var _a, _b, _c;
    ReleaseIdSchema.parse(input.runtimeReleaseId);
    const conformance = source_conformance_contract_1.M1SourceConformanceArtifactSchema.parse(input.conformanceArtifact);
    if (conformance.evidenceClass !== "LIVE_READ_ONLY" ||
        conformance.networkEnvironment !== "TENCENT_ISOLATED_READ_ONLY" ||
        conformance.passCount !== 15 ||
        conformance.failCount !== 0 ||
        conformance.notRunCount !== 0) {
        throw new Error("runtime adapter requires exact 15-of-15 Tencent live conformance");
    }
    const evidenceClass = input.transportImplementation === undefined
        ? "LIVE_READ_ONLY"
        : "TEST_ONLY";
    const expectedEnvironment = evidenceClass === "LIVE_READ_ONLY"
        ? "TENCENT_ISOLATED_READ_ONLY"
        : "TEST_HARNESS";
    if (input.networkEnvironment !== expectedEnvironment) {
        throw new Error("runtime adapter evidence environment is invalid");
    }
    const now = (_a = input.now) !== null && _a !== void 0 ? _a : (() => new Date());
    const profileSet = runtime_adapter_profile_1.M1RuntimeAdapterProfileSetSchema.parse((0, runtime_adapter_profile_1.buildM1RuntimeAdapterProfileSet)({
        runtimeReleaseId: input.runtimeReleaseId,
        generatedAt: now().toISOString(),
        conformanceArtifact: conformance,
    }));
    if (profileSet.profileCount !== 15 ||
        profileSet.schedulerRouteEligibleProfileCount !== 14 ||
        profileSet.registryBlockedProfileCount !== 1 ||
        (0, stable_artifact_1.stableContentHash)(profileSet.registryBlockedProbeIds) !==
            (0, stable_artifact_1.stableContentHash)([...exports.M1_RUNTIME_ADAPTER_BLOCKED_PROBE_IDS])) {
        throw new Error("runtime adapter route denominator drifted");
    }
    const routeProfiles = profileSet.profiles
        .filter((profile) => profile.schedulerRouteEligible)
        .sort((left, right) => left.probeId.localeCompare(right.probeId));
    const profilesBySource = new Map();
    for (const profile of routeProfiles) {
        const profiles = (_b = profilesBySource.get(profile.sourceId)) !== null && _b !== void 0 ? _b : [];
        profiles.push(profile);
        profilesBySource.set(profile.sourceId, profiles);
    }
    const executions = (await Promise.all([...profilesBySource.entries()].map(async ([sourceId, profiles]) => {
        var _a, _b, _c;
        const sourceExecutions = [];
        for (const profile of profiles) {
            sourceExecutions.push(profile.operation === "LISTING_HISTORY_SEGMENT"
                ? await executeListingProfile({
                    profile,
                    priorCheckpoint: (_b = (_a = input.listingCheckpoints) === null || _a === void 0 ? void 0 : _a[sourceId]) !== null && _b !== void 0 ? _b : null,
                    evidenceClass,
                    networkEnvironment: input.networkEnvironment,
                    transportImplementation: input.transportImplementation,
                    now,
                })
                : await executeSnapshotProfile({
                    profile,
                    coinGlassApiKey: ((_c = input.coinGlassApiKey) === null || _c === void 0 ? void 0 : _c.trim()) || null,
                    evidenceClass,
                    networkEnvironment: input.networkEnvironment,
                    transportImplementation: input.transportImplementation,
                    now,
                }));
        }
        return sourceExecutions;
    }))).flat().sort((left, right) => left.probeId.localeCompare(right.probeId));
    const executedProbeIds = executions.map((execution) => execution.probeId).sort();
    const passedProbeIds = executions
        .filter((execution) => execution.outcome === "PASS")
        .map((execution) => execution.probeId)
        .sort();
    const failedProbeIds = executions
        .filter((execution) => execution.outcome !== "PASS")
        .map((execution) => execution.probeId)
        .sort();
    const axisInputs = [
        {
            axisId: "BITGET_VENUE",
            expectedProbeIds: routeProfiles
                .filter((profile) => profile.acceptanceAxes.bitgetVenue)
                .map((profile) => profile.probeId),
            scopeBoundary: "BITGET_PUBLIC_VENUE_ROUTES_NO_TRADING_AUTHORITY",
        },
        {
            axisId: "LISTING_LIFECYCLE",
            expectedProbeIds: routeProfiles
                .filter((profile) => profile.acceptanceAxes.listingLifecycle)
                .map((profile) => profile.probeId),
            scopeBoundary: "LISTING_DISCOVERY_AND_HISTORY_ONLY_NO_CANDIDATE_AUTHORITY",
        },
        {
            axisId: "EQUITY_ASSET_DOMAIN",
            expectedProbeIds: routeProfiles
                .filter((profile) => profile.acceptanceAxes.equityAssetDomain)
                .map((profile) => profile.probeId),
            scopeBoundary: "CATALOG_ACCOUNTING_ONLY_SESSION_CORPORATE_ACTION_FX_BASIS_BLOCKED",
        },
        {
            axisId: "DATA_MAXIMIZATION",
            expectedProbeIds: routeProfiles.map((profile) => profile.probeId),
            scopeBoundary: "ALL_ROUTE_ELIGIBLE_PROFILES_ONLY_REGISTRY_BLOCK_RETAINED",
        },
    ];
    const acceptanceAxes = axisInputs.map((axis) => buildAxis(Object.assign(Object.assign({}, axis), { executions })));
    const listingCheckpointCommittedCount = executions.filter((execution) => { var _a; return ((_a = execution.listingAdvance) === null || _a === void 0 ? void 0 : _a.status) === "COMMITTED"; }).length;
    const listingGapCount = executions.filter((execution) => { var _a; return ((_a = execution.listingAdvance) === null || _a === void 0 ? void 0 : _a.status) === "BLOCKED_GAP"; }).length;
    const liveRoutePass = passedProbeIds.length === 14 &&
        failedProbeIds.length === 0 &&
        listingCheckpointCommittedCount === 2 &&
        listingGapCount === 0 &&
        acceptanceAxes.every((axis) => axis.routeGateStatus === "PASS");
    const generatedAt = now().toISOString();
    const sourceCutoff = (_c = executions
        .map((execution) => execution.sourceCutoff)
        .filter((value) => value !== null)
        .sort()
        .at(-1)) !== null && _c !== void 0 ? _c : generatedAt;
    const core = runtimeAdapterLiveArtifactCore({
        schemaVersion: exports.M1_RUNTIME_ADAPTER_LIVE_ARTIFACT_VERSION,
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        runtimeReleaseId: input.runtimeReleaseId,
        generatedAt,
        sourceCutoff,
        conformanceReleaseId: conformance.releaseId,
        conformanceArtifactId: conformance.artifactId,
        conformanceArtifactHash: conformance.contentHash,
        profileSetId: profileSet.profileSetId,
        profileSetHash: profileSet.contentHash,
        registryDigest: profileSet.registryDigest,
        probePlanDigest: profileSet.probePlanDigest,
        evidenceClass,
        networkEnvironment: input.networkEnvironment,
        status: evidenceClass === "TEST_ONLY"
            ? "TEST_ONLY_NOT_LIVE_EVIDENCE"
            : liveRoutePass
                ? "PASS_BOUNDED_ROUTE_SEGMENT_NO_AUTHORITY"
                : "BLOCKED_ROUTE_SEGMENT_NO_STALE_PROMOTION",
        liveConformantProfileCount: 15,
        routeEligibleProfileCount: 14,
        registryBlockedProfileCount: 1,
        registryBlockedProbeIds: [...exports.M1_RUNTIME_ADAPTER_BLOCKED_PROBE_IDS],
        expectedExecutionProbeIds: routeProfiles.map((profile) => profile.probeId).sort(),
        executedProbeIds,
        passedProbeIds,
        failedProbeIds,
        requestAttemptCount: executions.reduce((total, execution) => total + execution.requestAttempts, 0),
        requestTokenBudget: executions.reduce((total, execution) => total + execution.requestTokenBudget, 0),
        listingCheckpointCommittedCount,
        listingGapCount,
        executions,
        acceptanceAxes,
        acceptanceAccounting: "FOUR_INDEPENDENT_AXES_NO_CROSS_PASS",
        rawBodyRetained: false,
        secretMaterialPresent: false,
        runtimeAuthorityGranted: false,
        factAuthorityGranted: false,
        candidateAuthorityGranted: false,
        strategyAuthorityGranted: false,
        readyAuthorityGranted: false,
        productionChanged: false,
    });
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1RuntimeAdapterLiveArtifactSchema.parse(Object.assign(Object.assign({}, core), { artifactId: `runtime-adapter-live:${contentHash.slice(7, 31)}`, contentHash })));
}
function extractM1ListingHistoryCheckpoints(artifact) {
    const parsed = exports.M1RuntimeAdapterLiveArtifactSchema.parse(artifact);
    const checkpoint = (probeId) => {
        var _a;
        const advance = (_a = parsed.executions.find((execution) => execution.probeId === probeId)) === null || _a === void 0 ? void 0 : _a.listingAdvance;
        return (advance === null || advance === void 0 ? void 0 : advance.status) === "COMMITTED"
            ? listing_history_runtime_1.M1ListingHistoryCheckpointSchema.parse(advance.checkpoint)
            : null;
    };
    return (0, stable_artifact_1.deepFreezeArtifact)({
        BYBIT_DERIVATIVES: checkpoint("BYBIT_LISTING_ANNOUNCEMENT"),
        BITGET_FUTURES: checkpoint("BITGET_LISTING_ANNOUNCEMENT"),
    });
}
