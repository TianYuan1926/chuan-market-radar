"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.M1AdaptiveCollectorPlanSchema = exports.M1AdaptiveCollectorIntentSchema = exports.M1AdaptiveCollectorPolicySchema = exports.M1CollectorCheckpointSchema = exports.M1CollectorQuotaStateSchema = exports.M1CollectorSubjectSchema = exports.M1CollectorCapabilityGrantSchema = exports.M1_COLLECTOR_INTENT_DISPOSITIONS = exports.M1_COLLECTOR_RIGHTS_STATUSES = exports.M1_COLLECTOR_EVIDENCE_CLASSES = exports.M1_ADAPTIVE_COLLECTOR_POLICY_VERSION = exports.M1_ADAPTIVE_COLLECTOR_PLAN_VERSION = exports.M1_ADAPTIVE_COLLECTOR_GRANT_VERSION = void 0;
exports.buildM1CollectorCapabilityGrant = buildM1CollectorCapabilityGrant;
exports.buildM1AdaptiveCollectorPlan = buildM1AdaptiveCollectorPlan;
const zod_1 = require("zod");
const primitives_1 = require("../../runtime-schema/primitives");
const source_capability_contract_1 = require("../source-capability/source-capability-contract");
const four_venue_capability_registry_1 = require("../source-capability/adapters/four-venue-capability-registry");
const multi_asset_identity_contract_1 = require("../multi-asset-universe/multi-asset-identity-contract");
const stable_artifact_1 = require("../universe/stable-artifact");
exports.M1_ADAPTIVE_COLLECTOR_GRANT_VERSION = "v2-m1-adaptive-collector-capability-grant.v1";
exports.M1_ADAPTIVE_COLLECTOR_PLAN_VERSION = "v2-m1-adaptive-collector-contract-plan.v1";
exports.M1_ADAPTIVE_COLLECTOR_POLICY_VERSION = "v2-m1-adaptive-collector-policy.v1";
exports.M1_COLLECTOR_EVIDENCE_CLASSES = [
    "LIVE_READ_ONLY",
    "TEST_ONLY",
];
exports.M1_COLLECTOR_RIGHTS_STATUSES = [
    "PUBLIC_PERSONAL_ANALYTICS_ALLOWED",
    "HOBBYIST_PERSONAL_ANALYTICS_ALLOWED",
    "PENDING_REVIEW",
    "RESTRICTED",
    "UNAVAILABLE",
];
exports.M1_COLLECTOR_INTENT_DISPOSITIONS = [
    "READY_FOR_RUNTIME_ADAPTER",
    "TEST_ONLY_NO_RUNTIME",
    "CAPABILITY_NOT_LIVE",
    "CAPABILITY_FAILED",
    "CAPABILITY_GRANT_CONFLICT",
    "CAPABILITY_EXPIRED",
    "RIGHTS_BLOCKED",
    "ENTITLEMENT_BLOCKED",
    "JURISDICTION_BLOCKED",
    "REGISTRY_DISPOSITION_BLOCKED",
    "SUBJECT_NOT_ELIGIBLE",
    "LIFECYCLE_BLOCKED",
    "IDENTITY_UNRESOLVED",
    "EQUITY_REFERENCE_BLOCKED",
    "CONTROL_MISSING",
    "CONTROL_NOT_READY",
    "QUOTA_UNVERIFIED",
    "RATE_LIMITED",
    "AUTH_ERROR",
    "SOURCE_UNAVAILABLE",
    "QUOTA_EXHAUSTED",
    "NOT_DUE",
    "CHECKPOINT_INFLIGHT",
    "BACKOFF_DEFERRED",
    "RETRY_CIRCUIT_OPEN",
    "BACKPRESSURE_DEFERRED",
];
const DigestSchema = zod_1.z.string().regex(/^sha256:[0-9a-f]{64}$/u);
const ReleaseIdSchema = zod_1.z.string().regex(/^[0-9a-f]{40}$/u);
const UniqueNonEmptyStringsSchema = zod_1.z.array(primitives_1.NonEmptyStringSchema)
    .superRefine((values, context) => {
    if (new Set(values).size !== values.length) {
        context.addIssue({
            code: "custom",
            message: "values must be unique",
        });
    }
});
const AssetDomainsSchema = zod_1.z.array(zod_1.z.enum(source_capability_contract_1.M1_ASSET_DOMAINS)).min(1)
    .superRefine((values, context) => {
    if (new Set(values).size !== values.length) {
        context.addIssue({
            code: "custom",
            message: "asset domains must be unique",
        });
    }
});
const CapabilityGrantCoreSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_ADAPTIVE_COLLECTOR_GRANT_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: ReleaseIdSchema,
    sourceId: zod_1.z.enum(source_capability_contract_1.M1_SOURCE_IDS),
    capabilityId: zod_1.z.enum(source_capability_contract_1.M1_CAPABILITY_IDS),
    assetDomains: AssetDomainsSchema,
    evidenceClass: zod_1.z.enum(exports.M1_COLLECTOR_EVIDENCE_CLASSES),
    networkEnvironment: zod_1.z.enum([
        "TENCENT_ISOLATED_READ_ONLY",
        "TEST_HARNESS",
    ]),
    conformanceStatus: zod_1.z.enum(["PASS", "FAIL", "NOT_RUN"]),
    rightsStatus: zod_1.z.enum(exports.M1_COLLECTOR_RIGHTS_STATUSES),
    rightsReviewerClass: zod_1.z.enum([
        "HUMAN_EXTERNAL_REVIEW",
        "NOT_REVIEWED",
    ]),
    rightsReviewedAt: primitives_1.IsoDateTimeSchema.nullable(),
    rightsExpiresAt: primitives_1.IsoDateTimeSchema.nullable(),
    rightsEvidenceHash: DigestSchema.nullable(),
    entitlementStatus: zod_1.z.enum([
        "PUBLIC_NO_KEY",
        "HOBBYIST_CONFIRMED",
        "HOBBYIST_UNAVAILABLE",
        "UNVERIFIED",
    ]),
    jurisdictionAvailability: zod_1.z.enum([
        "AVAILABLE",
        "RESTRICTED",
        "UNAVAILABLE",
        "UNVERIFIED",
    ]),
    observedAt: primitives_1.IsoDateTimeSchema,
    expiresAt: primitives_1.IsoDateTimeSchema,
    evidenceIds: UniqueNonEmptyStringsSchema,
    conformanceArtifactHash: DigestSchema,
    adapterVersion: primitives_1.NonEmptyStringSchema,
    noSyntheticOrStaleFallback: zod_1.z.literal(true),
    factAuthorityGranted: zod_1.z.literal(false),
    candidateAuthorityGranted: zod_1.z.literal(false),
    strategyAuthorityGranted: zod_1.z.literal(false),
});
exports.M1CollectorCapabilityGrantSchema = CapabilityGrantCoreSchema.extend({
    grantId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
}).superRefine((grant, context) => {
    if (Date.parse(grant.observedAt) >= Date.parse(grant.expiresAt)) {
        context.addIssue({
            code: "custom",
            message: "capability grant expiry must be after observation",
            path: ["expiresAt"],
        });
    }
    if (grant.evidenceClass === "LIVE_READ_ONLY" &&
        grant.networkEnvironment !== "TENCENT_ISOLATED_READ_ONLY") {
        context.addIssue({
            code: "custom",
            message: "live grants require Tencent isolated read-only evidence",
            path: ["networkEnvironment"],
        });
    }
    if (grant.evidenceClass === "TEST_ONLY" &&
        grant.networkEnvironment !== "TEST_HARNESS") {
        context.addIssue({
            code: "custom",
            message: "test-only grants require the test harness environment",
            path: ["networkEnvironment"],
        });
    }
    if (grant.evidenceClass === "LIVE_READ_ONLY" &&
        grant.conformanceStatus === "PASS" &&
        grant.evidenceIds.length === 0) {
        context.addIssue({
            code: "custom",
            message: "passing live grants require runtime evidence ids",
            path: ["evidenceIds"],
        });
    }
    const isCoinGlass = grant.sourceId === "COINGLASS_V4";
    if (isCoinGlass &&
        !["HOBBYIST_CONFIRMED", "HOBBYIST_UNAVAILABLE", "UNVERIFIED"]
            .includes(grant.entitlementStatus)) {
        context.addIssue({
            code: "custom",
            message: "CoinGlass cannot use a public-no-key entitlement",
            path: ["entitlementStatus"],
        });
    }
    if (!isCoinGlass && grant.entitlementStatus !== "PUBLIC_NO_KEY") {
        context.addIssue({
            code: "custom",
            message: "venue grants must remain public-no-key",
            path: ["entitlementStatus"],
        });
    }
    if (grant.rightsStatus === "HOBBYIST_PERSONAL_ANALYTICS_ALLOWED" &&
        !isCoinGlass) {
        context.addIssue({
            code: "custom",
            message: "Hobbyist rights apply only to CoinGlass",
            path: ["rightsStatus"],
        });
    }
    if (grant.rightsStatus === "PUBLIC_PERSONAL_ANALYTICS_ALLOWED" &&
        isCoinGlass) {
        context.addIssue({
            code: "custom",
            message: "CoinGlass rights cannot be represented as public",
            path: ["rightsStatus"],
        });
    }
    const rightsAllowed = [
        "PUBLIC_PERSONAL_ANALYTICS_ALLOWED",
        "HOBBYIST_PERSONAL_ANALYTICS_ALLOWED",
    ].includes(grant.rightsStatus);
    const completeRightsEvidence = grant.rightsReviewerClass === "HUMAN_EXTERNAL_REVIEW" &&
        grant.rightsReviewedAt !== null &&
        grant.rightsExpiresAt !== null &&
        grant.rightsEvidenceHash !== null;
    if (rightsAllowed && !completeRightsEvidence) {
        context.addIssue({
            code: "custom",
            message: "allowed rights require current external human review evidence",
            path: ["rightsReviewerClass"],
        });
    }
    if (grant.rightsReviewerClass === "NOT_REVIEWED" &&
        (grant.rightsReviewedAt !== null ||
            grant.rightsExpiresAt !== null ||
            grant.rightsEvidenceHash !== null)) {
        context.addIssue({
            code: "custom",
            message: "unreviewed rights cannot carry review evidence",
            path: ["rightsReviewedAt"],
        });
    }
    if (completeRightsEvidence &&
        (Date.parse(grant.rightsReviewedAt) > Date.parse(grant.observedAt) ||
            Date.parse(grant.rightsReviewedAt) >=
                Date.parse(grant.rightsExpiresAt) ||
            Date.parse(grant.expiresAt) > Date.parse(grant.rightsExpiresAt))) {
        context.addIssue({
            code: "custom",
            message: "capability grant cannot predate or outlive its rights review",
            path: ["rightsExpiresAt"],
        });
    }
    const registryRow = four_venue_capability_registry_1.M1_FOUR_VENUE_SOURCE_CAPABILITY_REGISTRY.rows.find((row) => row.sourceId === grant.sourceId &&
        row.capabilityId === grant.capabilityId);
    if (registryRow === undefined ||
        grant.assetDomains.some((assetDomain) => !registryRow.assetDomains.includes(assetDomain))) {
        context.addIssue({
            code: "custom",
            message: "capability grant exceeds the registered source domain",
            path: ["assetDomains"],
        });
    }
    if (grant.evidenceClass === "LIVE_READ_ONLY" &&
        grant.conformanceStatus === "PASS" &&
        (registryRow === undefined ||
            !["ADOPTED_AS_FACT", "DERIVED_WITH_LINEAGE"].includes(registryRow.disposition))) {
        context.addIssue({
            code: "custom",
            message: "live grant cannot promote a blocked registry disposition",
            path: ["conformanceStatus"],
        });
    }
    const core = capabilityGrantCore(grant);
    const expectedHash = (0, stable_artifact_1.stableContentHash)(core);
    if (grant.contentHash !== expectedHash) {
        context.addIssue({
            code: "custom",
            message: "capability grant content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (grant.grantId !==
        `collector-grant:${grant.sourceId}:${grant.capabilityId}:` +
            expectedHash.slice(7, 23)) {
        context.addIssue({
            code: "custom",
            message: "capability grant id mismatch",
            path: ["grantId"],
        });
    }
});
function capabilityGrantCore(grant) {
    return CapabilityGrantCoreSchema.parse({
        schemaVersion: grant.schemaVersion,
        scopeEpoch: grant.scopeEpoch,
        releaseId: grant.releaseId,
        sourceId: grant.sourceId,
        capabilityId: grant.capabilityId,
        assetDomains: [...grant.assetDomains].sort(),
        evidenceClass: grant.evidenceClass,
        networkEnvironment: grant.networkEnvironment,
        conformanceStatus: grant.conformanceStatus,
        rightsStatus: grant.rightsStatus,
        rightsReviewerClass: grant.rightsReviewerClass,
        rightsReviewedAt: grant.rightsReviewedAt,
        rightsExpiresAt: grant.rightsExpiresAt,
        rightsEvidenceHash: grant.rightsEvidenceHash,
        entitlementStatus: grant.entitlementStatus,
        jurisdictionAvailability: grant.jurisdictionAvailability,
        observedAt: grant.observedAt,
        expiresAt: grant.expiresAt,
        evidenceIds: [...grant.evidenceIds].sort(),
        conformanceArtifactHash: grant.conformanceArtifactHash,
        adapterVersion: grant.adapterVersion,
        noSyntheticOrStaleFallback: grant.noSyntheticOrStaleFallback,
        factAuthorityGranted: grant.factAuthorityGranted,
        candidateAuthorityGranted: grant.candidateAuthorityGranted,
        strategyAuthorityGranted: grant.strategyAuthorityGranted,
    });
}
function buildM1CollectorCapabilityGrant(input) {
    const core = capabilityGrantCore(Object.assign(Object.assign({}, input), { schemaVersion: exports.M1_ADAPTIVE_COLLECTOR_GRANT_VERSION, scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH, noSyntheticOrStaleFallback: true, factAuthorityGranted: false, candidateAuthorityGranted: false, strategyAuthorityGranted: false }));
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1CollectorCapabilityGrantSchema.parse(Object.assign(Object.assign({}, core), { grantId: `collector-grant:${core.sourceId}:${core.capabilityId}:` +
            contentHash.slice(7, 23), contentHash })));
}
exports.M1CollectorSubjectSchema = zod_1.z.strictObject({
    subjectId: primitives_1.NonEmptyStringSchema,
    sourceId: zod_1.z.enum(source_capability_contract_1.M1_VENUE_SOURCE_IDS),
    assetDomain: zod_1.z.enum(source_capability_contract_1.M1_ASSET_DOMAINS),
    coverageClass: zod_1.z.enum([
        "SUPPORTED_DERIVATIVE",
        "ASSET_LISTING_WATCH",
    ]),
    canonicalInstrumentId: primitives_1.NonEmptyStringSchema.nullable(),
    venueInstrumentId: primitives_1.NonEmptyStringSchema,
    listingEpoch: primitives_1.NonEmptyStringSchema,
    identityEpoch: primitives_1.NonEmptyStringSchema,
    identityStatus: zod_1.z.enum(["EXACT", "PARTIAL", "UNRESOLVED"]),
    lifecycleState: zod_1.z.enum(multi_asset_identity_contract_1.M1_LISTING_LIFECYCLE_STATES),
    eligibilityStatus: zod_1.z.enum([
        "ELIGIBLE",
        "INELIGIBLE",
        "NOT_EVALUATED",
        "UNRESOLVED",
    ]),
    candidatePriority: zod_1.z.enum(["NONE", "P0", "P1", "P2"]),
    candidateEpisodeId: primitives_1.NonEmptyStringSchema.nullable(),
    matchedControlForEpisodeId: primitives_1.NonEmptyStringSchema.nullable(),
    deepValidationEpisodeId: primitives_1.NonEmptyStringSchema.nullable(),
    observedAt: primitives_1.IsoDateTimeSchema,
    reasonCodes: primitives_1.ReasonCodesSchema,
}).superRefine((subject, context) => {
    const isWatch = subject.coverageClass === "ASSET_LISTING_WATCH";
    if (isWatch &&
        (subject.assetDomain !== "ASSET_LISTING_WATCH" ||
            subject.canonicalInstrumentId !== null ||
            subject.eligibilityStatus === "ELIGIBLE" ||
            subject.candidatePriority !== "NONE" ||
            subject.candidateEpisodeId !== null ||
            subject.matchedControlForEpisodeId !== null ||
            subject.deepValidationEpisodeId !== null)) {
        context.addIssue({
            code: "custom",
            message: "listing-watch subjects cannot masquerade as derivative candidates",
            path: ["coverageClass"],
        });
    }
    if (!isWatch &&
        (subject.assetDomain === "ASSET_LISTING_WATCH" ||
            subject.assetDomain === "CROSS_MARKET_CONTEXT")) {
        context.addIssue({
            code: "custom",
            message: "derivative subjects require a derivative asset domain",
            path: ["assetDomain"],
        });
    }
    if (subject.identityStatus === "EXACT" &&
        subject.canonicalInstrumentId === null) {
        context.addIssue({
            code: "custom",
            message: "exact identity requires a canonical instrument id",
            path: ["canonicalInstrumentId"],
        });
    }
    if (subject.identityStatus !== "EXACT" &&
        subject.canonicalInstrumentId !== null) {
        context.addIssue({
            code: "custom",
            message: "non-exact identity cannot claim a canonical instrument id",
            path: ["canonicalInstrumentId"],
        });
    }
    const isCandidate = ["P0", "P1"].includes(subject.candidatePriority);
    if (isCandidate !== (subject.candidateEpisodeId !== null)) {
        context.addIssue({
            code: "custom",
            message: "P0/P1 candidate priority and episode id must agree",
            path: ["candidateEpisodeId"],
        });
    }
    if (subject.candidatePriority !== "NONE" &&
        subject.matchedControlForEpisodeId !== null) {
        context.addIssue({
            code: "custom",
            message: "candidate subjects cannot also be matched controls",
            path: ["matchedControlForEpisodeId"],
        });
    }
    if (subject.matchedControlForEpisodeId !== null &&
        (subject.candidatePriority !== "NONE" ||
            subject.candidateEpisodeId !== null ||
            subject.deepValidationEpisodeId !== null)) {
        context.addIssue({
            code: "custom",
            message: "matched controls cannot carry candidate or deep episodes",
            path: ["matchedControlForEpisodeId"],
        });
    }
    if (subject.deepValidationEpisodeId !== null &&
        !isCandidate) {
        context.addIssue({
            code: "custom",
            message: "deep validation requires a P0/P1 candidate episode",
            path: ["deepValidationEpisodeId"],
        });
    }
});
exports.M1CollectorQuotaStateSchema = zod_1.z.strictObject({
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: ReleaseIdSchema,
    sourceId: zod_1.z.enum(source_capability_contract_1.M1_SOURCE_IDS),
    capabilityId: zod_1.z.enum(source_capability_contract_1.M1_CAPABILITY_IDS),
    evidenceClass: zod_1.z.enum(exports.M1_COLLECTOR_EVIDENCE_CLASSES),
    networkEnvironment: zod_1.z.enum([
        "TENCENT_ISOLATED_READ_ONLY",
        "TEST_HARNESS",
    ]),
    status: zod_1.z.enum([
        "READY",
        "RATE_LIMITED",
        "AUTH_ERROR",
        "SOURCE_UNAVAILABLE",
    ]),
    windowStartedAt: primitives_1.IsoDateTimeSchema,
    windowEndsAt: primitives_1.IsoDateTimeSchema,
    requestLimit: zod_1.z.number().int().positive().max(1000000),
    requestsUsed: primitives_1.NonNegativeIntegerSchema,
    requestsReserved: primitives_1.NonNegativeIntegerSchema,
    observedAt: primitives_1.IsoDateTimeSchema,
    retryAfter: primitives_1.IsoDateTimeSchema.nullable(),
    evidenceIds: UniqueNonEmptyStringsSchema.min(1),
}).superRefine((quota, context) => {
    if (quota.evidenceClass === "LIVE_READ_ONLY" &&
        quota.networkEnvironment !== "TENCENT_ISOLATED_READ_ONLY") {
        context.addIssue({
            code: "custom",
            message: "live quota state requires Tencent isolated read-only evidence",
            path: ["networkEnvironment"],
        });
    }
    if (quota.evidenceClass === "TEST_ONLY" &&
        quota.networkEnvironment !== "TEST_HARNESS") {
        context.addIssue({
            code: "custom",
            message: "test quota state requires the test harness environment",
            path: ["networkEnvironment"],
        });
    }
    if (Date.parse(quota.windowStartedAt) >= Date.parse(quota.windowEndsAt)) {
        context.addIssue({
            code: "custom",
            message: "quota window end must be after start",
            path: ["windowEndsAt"],
        });
    }
    if (Date.parse(quota.observedAt) < Date.parse(quota.windowStartedAt) ||
        Date.parse(quota.observedAt) >= Date.parse(quota.windowEndsAt)) {
        context.addIssue({
            code: "custom",
            message: "quota observation must belong to its active window",
            path: ["observedAt"],
        });
    }
    if (quota.requestsUsed + quota.requestsReserved > quota.requestLimit) {
        context.addIssue({
            code: "custom",
            message: "quota usage cannot exceed the documented request limit",
            path: ["requestsUsed"],
        });
    }
    if (quota.status === "RATE_LIMITED" &&
        quota.retryAfter === null) {
        context.addIssue({
            code: "custom",
            message: "rate-limited quota requires retryAfter",
            path: ["retryAfter"],
        });
    }
    if (quota.retryAfter !== null &&
        Date.parse(quota.retryAfter) <= Date.parse(quota.observedAt)) {
        context.addIssue({
            code: "custom",
            message: "quota retryAfter must be later than observation",
            path: ["retryAfter"],
        });
    }
    if (quota.status !== "RATE_LIMITED" &&
        quota.retryAfter !== null) {
        context.addIssue({
            code: "custom",
            message: "only rate-limited quota may carry retryAfter",
            path: ["retryAfter"],
        });
    }
});
exports.M1CollectorCheckpointSchema = zod_1.z.strictObject({
    intentKey: primitives_1.NonEmptyStringSchema,
    lastCompletedAt: primitives_1.IsoDateTimeSchema.nullable(),
    lastAttemptAt: primitives_1.IsoDateTimeSchema.nullable(),
    consecutiveFailures: primitives_1.NonNegativeIntegerSchema,
    inFlightLeaseUntil: primitives_1.IsoDateTimeSchema.nullable(),
    lastFailureClass: zod_1.z.enum([
        "NONE",
        "RATE_LIMITED",
        "AUTH_ERROR",
        "SCHEMA_DRIFT",
        "TRANSPORT",
        "SOURCE_UNAVAILABLE",
    ]),
}).superRefine((checkpoint, context) => {
    if (checkpoint.consecutiveFailures === 0 &&
        checkpoint.lastFailureClass !== "NONE") {
        context.addIssue({
            code: "custom",
            message: "zero failures require NONE failure class",
            path: ["lastFailureClass"],
        });
    }
    if (checkpoint.consecutiveFailures > 0 &&
        (checkpoint.lastFailureClass === "NONE" ||
            checkpoint.lastAttemptAt === null)) {
        context.addIssue({
            code: "custom",
            message: "failed checkpoints require an attempt and failure class",
            path: ["consecutiveFailures"],
        });
    }
    if (checkpoint.inFlightLeaseUntil !== null &&
        checkpoint.lastAttemptAt === null) {
        context.addIssue({
            code: "custom",
            message: "an in-flight lease requires a recorded attempt",
            path: ["inFlightLeaseUntil"],
        });
    }
    if (checkpoint.lastCompletedAt !== null &&
        checkpoint.lastAttemptAt !== null &&
        Date.parse(checkpoint.lastCompletedAt) <
            Date.parse(checkpoint.lastAttemptAt)) {
        context.addIssue({
            code: "custom",
            message: "completion cannot precede the recorded attempt",
            path: ["lastCompletedAt"],
        });
    }
});
const CadencesSchema = zod_1.z.strictObject({
    T0_CATALOG_EVENT: zod_1.z.number().int().min(60000).max(86400000),
    T1_WIDE_MARKET: zod_1.z.number().int().min(1000).max(3600000),
    T2_CANDIDATE_BURST: zod_1.z.number().int().min(250).max(300000),
    T3_DEEP_VALIDATION: zod_1.z.number().int().min(1000).max(3600000),
});
exports.M1AdaptiveCollectorPolicySchema = zod_1.z.strictObject({
    policyVersion: zod_1.z.literal(exports.M1_ADAPTIVE_COLLECTOR_POLICY_VERSION),
    maxIntentRows: zod_1.z.number().int().positive().max(200000),
    maxReadyIntents: zod_1.z.number().int().positive().max(20000),
    baselineReservedSlots: primitives_1.NonNegativeIntegerSchema,
    maxReadyIntentsPerSource: zod_1.z.number().int().positive().max(10000),
    maxBurstIntentsPerSubject: zod_1.z.number().int().positive().max(1000),
    maxConsecutiveFailures: zod_1.z.number().int().positive().max(100),
    baseRetryBackoffMs: zod_1.z.number().int().min(1000).max(3600000),
    maxRetryBackoffMs: zod_1.z.number().int().min(1000).max(86400000),
    cadencesMs: CadencesSchema,
    fairnessCursorSource: zod_1.z.enum(source_capability_contract_1.M1_SOURCE_IDS),
    fullT0T1AccountingRequired: zod_1.z.literal(true),
    t2MatchedControlRequired: zod_1.z.literal(true),
    dropDeferredIntentsAllowed: zod_1.z.literal(false),
    unboundedRetentionAllowed: zod_1.z.literal(false),
    automaticFactAuthorityAllowed: zod_1.z.literal(false),
    automaticCandidateAuthorityAllowed: zod_1.z.literal(false),
    automaticStrategyAuthorityAllowed: zod_1.z.literal(false),
}).superRefine((policy, context) => {
    if (policy.baselineReservedSlots > policy.maxReadyIntents) {
        context.addIssue({
            code: "custom",
            message: "baseline reserve cannot exceed total ready capacity",
            path: ["baselineReservedSlots"],
        });
    }
    if (policy.maxReadyIntentsPerSource > policy.maxReadyIntents) {
        context.addIssue({
            code: "custom",
            message: "per-source capacity cannot exceed total ready capacity",
            path: ["maxReadyIntentsPerSource"],
        });
    }
    if (policy.baseRetryBackoffMs > policy.maxRetryBackoffMs) {
        context.addIssue({
            code: "custom",
            message: "base retry backoff cannot exceed maximum",
            path: ["baseRetryBackoffMs"],
        });
    }
});
const PlanInputSchema = zod_1.z.strictObject({
    releaseId: ReleaseIdSchema,
    generatedAt: primitives_1.IsoDateTimeSchema,
    sourceCutoff: primitives_1.IsoDateTimeSchema,
    registryDigest: DigestSchema,
    identitySnapshotHash: DigestSchema,
    subjects: zod_1.z.array(exports.M1CollectorSubjectSchema).max(10000),
    capabilityGrants: zod_1.z.array(exports.M1CollectorCapabilityGrantSchema).max(1000),
    quotaStates: zod_1.z.array(exports.M1CollectorQuotaStateSchema).max(1000),
    checkpoints: zod_1.z.array(exports.M1CollectorCheckpointSchema).max(200000),
    policy: exports.M1AdaptiveCollectorPolicySchema,
});
const TierCountsSchema = zod_1.z.strictObject({
    T0_CATALOG_EVENT: primitives_1.NonNegativeIntegerSchema,
    T1_WIDE_MARKET: primitives_1.NonNegativeIntegerSchema,
    T2_CANDIDATE_BURST: primitives_1.NonNegativeIntegerSchema,
    T3_DEEP_VALIDATION: primitives_1.NonNegativeIntegerSchema,
});
const SourceCountsSchema = zod_1.z.strictObject({
    BINANCE_FUTURES: primitives_1.NonNegativeIntegerSchema,
    OKX_SWAP: primitives_1.NonNegativeIntegerSchema,
    BYBIT_DERIVATIVES: primitives_1.NonNegativeIntegerSchema,
    BITGET_FUTURES: primitives_1.NonNegativeIntegerSchema,
    COINGLASS_V4: primitives_1.NonNegativeIntegerSchema,
});
const DispositionCountsSchema = zod_1.z.strictObject(Object.fromEntries(exports.M1_COLLECTOR_INTENT_DISPOSITIONS.map((disposition) => [
    disposition,
    primitives_1.NonNegativeIntegerSchema,
])));
exports.M1AdaptiveCollectorIntentSchema = zod_1.z.strictObject({
    intentKey: primitives_1.NonEmptyStringSchema,
    subjectId: primitives_1.NonEmptyStringSchema,
    subjectSourceId: zod_1.z.enum(source_capability_contract_1.M1_VENUE_SOURCE_IDS),
    collectionSourceId: zod_1.z.enum(source_capability_contract_1.M1_SOURCE_IDS),
    assetDomain: zod_1.z.enum(source_capability_contract_1.M1_ASSET_DOMAINS),
    tier: zod_1.z.enum(source_capability_contract_1.M1_COLLECTION_TIERS),
    capabilityId: zod_1.z.enum(source_capability_contract_1.M1_CAPABILITY_IDS),
    candidateEpisodeId: primitives_1.NonEmptyStringSchema.nullable(),
    matchedControlForEpisodeId: primitives_1.NonEmptyStringSchema.nullable(),
    deepValidationEpisodeId: primitives_1.NonEmptyStringSchema.nullable(),
    disposition: zod_1.z.enum(exports.M1_COLLECTOR_INTENT_DISPOSITIONS),
    reasonCodes: primitives_1.ReasonCodesSchema,
    grantId: primitives_1.NonEmptyStringSchema.nullable(),
    quotaWindowEndsAt: primitives_1.IsoDateTimeSchema.nullable(),
    plannedRequestTokens: zod_1.z.union([zod_1.z.literal(0), zod_1.z.literal(1)]),
    runtimeExecutionAllowed: zod_1.z.literal(false),
    factAuthorityGranted: zod_1.z.literal(false),
    candidateAuthorityGranted: zod_1.z.literal(false),
    strategyAuthorityGranted: zod_1.z.literal(false),
});
const AdaptiveCollectorPlanCoreSchema = zod_1.z.strictObject({
    schemaVersion: zod_1.z.literal(exports.M1_ADAPTIVE_COLLECTOR_PLAN_VERSION),
    scopeEpoch: zod_1.z.literal(source_capability_contract_1.M1_SCOPE_EPOCH),
    releaseId: ReleaseIdSchema,
    generatedAt: primitives_1.IsoDateTimeSchema,
    sourceCutoff: primitives_1.IsoDateTimeSchema,
    registryDigest: DigestSchema,
    identitySnapshotHash: DigestSchema,
    subjectInputHash: DigestSchema,
    capabilityGrantSetHash: DigestSchema,
    quotaStateSetHash: DigestSchema,
    checkpointSetHash: DigestSchema,
    policyHash: DigestSchema,
    capabilityEvidenceClass: zod_1.z.enum([
        "NO_GRANTS",
        "TEST_ONLY_OR_MIXED",
        "LIVE_READ_ONLY_ONLY",
    ]),
    subjectCount: primitives_1.NonNegativeIntegerSchema,
    subjectDenominatorsByTier: TierCountsSchema,
    intentCount: primitives_1.NonNegativeIntegerSchema,
    readyForRuntimeAdapterCount: primitives_1.NonNegativeIntegerSchema,
    countsByTier: TierCountsSchema,
    countsBySource: SourceCountsSchema,
    countsByDisposition: DispositionCountsSchema,
    plannedRequestTokensBySource: SourceCountsSchema,
    intents: zod_1.z.array(exports.M1AdaptiveCollectorIntentSchema).max(200000),
    schedulerAuthority: zod_1.z.literal("CONTRACT_ONLY_NO_RUNTIME_EXECUTION_AUTHORITY"),
    runtimeExecutionAllowed: zod_1.z.literal(false),
    factAuthorityGranted: zod_1.z.literal(false),
    candidateAuthorityGranted: zod_1.z.literal(false),
    strategyAuthorityGranted: zod_1.z.literal(false),
    readyAuthorityGranted: zod_1.z.literal(false),
    productionChanged: zod_1.z.literal(false),
});
exports.M1AdaptiveCollectorPlanSchema = AdaptiveCollectorPlanCoreSchema.extend({
    planId: primitives_1.NonEmptyStringSchema,
    contentHash: DigestSchema,
}).superRefine((plan, context) => {
    if (Date.parse(plan.sourceCutoff) > Date.parse(plan.generatedAt)) {
        context.addIssue({
            code: "custom",
            message: "source cutoff cannot be later than plan generation",
            path: ["sourceCutoff"],
        });
    }
    if (plan.intentCount !== plan.intents.length) {
        context.addIssue({
            code: "custom",
            message: "intent count must equal intent rows",
            path: ["intentCount"],
        });
    }
    const keys = plan.intents.map((intent) => intent.intentKey);
    if (new Set(keys).size !== keys.length ||
        keys.some((key, index) => index > 0 && keys[index - 1].localeCompare(key) >= 0)) {
        context.addIssue({
            code: "custom",
            message: "collector intents must have unique canonical ordering",
            path: ["intents"],
        });
    }
    const expectedReady = plan.intents.filter((intent) => intent.disposition === "READY_FOR_RUNTIME_ADAPTER").length;
    if (plan.readyForRuntimeAdapterCount !== expectedReady) {
        context.addIssue({
            code: "custom",
            message: "ready adapter count does not match intents",
            path: ["readyForRuntimeAdapterCount"],
        });
    }
    const expectedTierCounts = emptyTierCounts();
    const expectedSourceCounts = emptySourceCounts();
    const expectedDispositionCounts = emptyDispositionCounts();
    const expectedTokens = emptySourceCounts();
    for (const intent of plan.intents) {
        expectedTierCounts[intent.tier] += 1;
        expectedSourceCounts[intent.collectionSourceId] += 1;
        expectedDispositionCounts[intent.disposition] += 1;
        expectedTokens[intent.collectionSourceId] +=
            intent.plannedRequestTokens;
    }
    for (const [path, actual, expected] of [
        ["countsByTier", plan.countsByTier, expectedTierCounts],
        ["countsBySource", plan.countsBySource, expectedSourceCounts],
        ["countsByDisposition", plan.countsByDisposition, expectedDispositionCounts],
        ["plannedRequestTokensBySource", plan.plannedRequestTokensBySource, expectedTokens],
    ]) {
        if ((0, stable_artifact_1.stableContentHash)(actual) !== (0, stable_artifact_1.stableContentHash)(expected)) {
            context.addIssue({
                code: "custom",
                message: `${path} does not match intents`,
                path: [path],
            });
        }
    }
    const core = adaptiveCollectorPlanCore(plan);
    const expectedHash = (0, stable_artifact_1.stableContentHash)(core);
    if (plan.contentHash !== expectedHash) {
        context.addIssue({
            code: "custom",
            message: "adaptive collector plan content hash mismatch",
            path: ["contentHash"],
        });
    }
    if (plan.planId !== `adaptive-collector:${expectedHash.slice(7, 31)}`) {
        context.addIssue({
            code: "custom",
            message: "adaptive collector plan id mismatch",
            path: ["planId"],
        });
    }
});
function emptyTierCounts() {
    return {
        T0_CATALOG_EVENT: 0,
        T1_WIDE_MARKET: 0,
        T2_CANDIDATE_BURST: 0,
        T3_DEEP_VALIDATION: 0,
    };
}
function emptySourceCounts() {
    return {
        BINANCE_FUTURES: 0,
        OKX_SWAP: 0,
        BYBIT_DERIVATIVES: 0,
        BITGET_FUTURES: 0,
        COINGLASS_V4: 0,
    };
}
function emptyDispositionCounts() {
    return Object.fromEntries(exports.M1_COLLECTOR_INTENT_DISPOSITIONS.map((value) => [value, 0]));
}
function adaptiveCollectorPlanCore(plan) {
    return AdaptiveCollectorPlanCoreSchema.parse({
        schemaVersion: plan.schemaVersion,
        scopeEpoch: plan.scopeEpoch,
        releaseId: plan.releaseId,
        generatedAt: plan.generatedAt,
        sourceCutoff: plan.sourceCutoff,
        registryDigest: plan.registryDigest,
        identitySnapshotHash: plan.identitySnapshotHash,
        subjectInputHash: plan.subjectInputHash,
        capabilityGrantSetHash: plan.capabilityGrantSetHash,
        quotaStateSetHash: plan.quotaStateSetHash,
        checkpointSetHash: plan.checkpointSetHash,
        policyHash: plan.policyHash,
        capabilityEvidenceClass: plan.capabilityEvidenceClass,
        subjectCount: plan.subjectCount,
        subjectDenominatorsByTier: plan.subjectDenominatorsByTier,
        intentCount: plan.intentCount,
        readyForRuntimeAdapterCount: plan.readyForRuntimeAdapterCount,
        countsByTier: plan.countsByTier,
        countsBySource: plan.countsBySource,
        countsByDisposition: plan.countsByDisposition,
        plannedRequestTokensBySource: plan.plannedRequestTokensBySource,
        intents: plan.intents,
        schedulerAuthority: plan.schedulerAuthority,
        runtimeExecutionAllowed: plan.runtimeExecutionAllowed,
        factAuthorityGranted: plan.factAuthorityGranted,
        candidateAuthorityGranted: plan.candidateAuthorityGranted,
        strategyAuthorityGranted: plan.strategyAuthorityGranted,
        readyAuthorityGranted: plan.readyAuthorityGranted,
        productionChanged: plan.productionChanged,
    });
}
function isEquityDomain(assetDomain) {
    return [
        "EQUITY_SINGLE_NAME_PERPETUAL",
        "EQUITY_INDEX_ETF_PERPETUAL",
        "EQUITY_CFD",
    ].includes(assetDomain);
}
function subjectTierEligible(subject, tier, subjects) {
    if (tier === "T0_CATALOG_EVENT") {
        return true;
    }
    if (subject.coverageClass !== "SUPPORTED_DERIVATIVE" ||
        subject.identityStatus !== "EXACT" ||
        subject.eligibilityStatus !== "ELIGIBLE" ||
        !["TRADING_WARMUP", "ESTABLISHED"].includes(subject.lifecycleState)) {
        return false;
    }
    if (tier === "T1_WIDE_MARKET") {
        return true;
    }
    if (subject.lifecycleState !== "ESTABLISHED") {
        return false;
    }
    if (tier === "T2_CANDIDATE_BURST") {
        return (["P0", "P1"].includes(subject.candidatePriority) ||
            subject.matchedControlForEpisodeId !== null);
    }
    if (subject.deepValidationEpisodeId !== null) {
        return true;
    }
    return (subject.matchedControlForEpisodeId !== null &&
        subjects.some((candidate) => candidate.candidateEpisodeId === subject.matchedControlForEpisodeId &&
            candidate.deepValidationEpisodeId !== null));
}
function subjectTierDenominators(subjects) {
    const counts = emptyTierCounts();
    for (const subject of subjects) {
        for (const tier of source_capability_contract_1.M1_COLLECTION_TIERS) {
            if (subjectTierEligible(subject, tier, subjects)) {
                counts[tier] += 1;
            }
        }
    }
    return counts;
}
function intentKey(input) {
    return [
        input.tier,
        input.sourceId,
        input.capabilityId,
        input.subjectId,
    ].join(":");
}
function liveGrantDisposition(grant, generatedAt) {
    if (grant.evidenceClass !== "LIVE_READ_ONLY") {
        return {
            disposition: "TEST_ONLY_NO_RUNTIME",
            reasonCodes: ["test_only_capability_cannot_enter_runtime"],
        };
    }
    if (grant.conformanceStatus === "FAIL") {
        return {
            disposition: "CAPABILITY_FAILED",
            reasonCodes: ["live_source_conformance_failed"],
        };
    }
    if (grant.conformanceStatus !== "PASS") {
        return {
            disposition: "CAPABILITY_NOT_LIVE",
            reasonCodes: ["live_source_conformance_not_run"],
        };
    }
    if (Date.parse(grant.expiresAt) <= Date.parse(generatedAt)) {
        return {
            disposition: "CAPABILITY_EXPIRED",
            reasonCodes: ["live_capability_evidence_expired"],
        };
    }
    const rightsAllowed = grant.sourceId === "COINGLASS_V4"
        ? grant.rightsStatus === "HOBBYIST_PERSONAL_ANALYTICS_ALLOWED"
        : grant.rightsStatus === "PUBLIC_PERSONAL_ANALYTICS_ALLOWED";
    if (!rightsAllowed) {
        return {
            disposition: "RIGHTS_BLOCKED",
            reasonCodes: [`rights_${grant.rightsStatus.toLowerCase()}`],
        };
    }
    const entitlementAllowed = grant.sourceId === "COINGLASS_V4"
        ? grant.entitlementStatus === "HOBBYIST_CONFIRMED"
        : grant.entitlementStatus === "PUBLIC_NO_KEY";
    if (!entitlementAllowed) {
        return {
            disposition: "ENTITLEMENT_BLOCKED",
            reasonCodes: [`entitlement_${grant.entitlementStatus.toLowerCase()}`],
        };
    }
    if (grant.jurisdictionAvailability !== "AVAILABLE") {
        return {
            disposition: "JURISDICTION_BLOCKED",
            reasonCodes: [
                `jurisdiction_${grant.jurisdictionAvailability.toLowerCase()}`,
            ],
        };
    }
    return {
        disposition: "READY_FOR_RUNTIME_ADAPTER",
        reasonCodes: [],
    };
}
function retryBackoffMs(checkpoint, policy) {
    if (checkpoint.consecutiveFailures === 0) {
        return 0;
    }
    const exponent = Math.min(checkpoint.consecutiveFailures - 1, 20);
    return Math.min(policy.maxRetryBackoffMs, policy.baseRetryBackoffMs * 2 ** exponent);
}
function checkpointDisposition(checkpoint, tier, generatedAt, policy) {
    if (checkpoint === undefined) {
        return null;
    }
    const now = Date.parse(generatedAt);
    if (checkpoint.inFlightLeaseUntil !== null &&
        Date.parse(checkpoint.inFlightLeaseUntil) > now) {
        return {
            disposition: "CHECKPOINT_INFLIGHT",
            reasonCodes: ["existing_intent_lease_is_active"],
        };
    }
    if (checkpoint.consecutiveFailures >= policy.maxConsecutiveFailures) {
        return {
            disposition: "RETRY_CIRCUIT_OPEN",
            reasonCodes: ["consecutive_failure_limit_reached"],
        };
    }
    if (checkpoint.consecutiveFailures > 0 &&
        checkpoint.lastAttemptAt !== null &&
        Date.parse(checkpoint.lastAttemptAt) +
            retryBackoffMs(checkpoint, policy) > now) {
        return {
            disposition: "BACKOFF_DEFERRED",
            reasonCodes: ["retry_backoff_not_elapsed"],
        };
    }
    if (checkpoint.lastCompletedAt !== null &&
        Date.parse(checkpoint.lastCompletedAt) + policy.cadencesMs[tier] > now) {
        return {
            disposition: "NOT_DUE",
            reasonCodes: ["collection_cadence_not_due"],
        };
    }
    return null;
}
function quotaDisposition(quota, generatedAt) {
    if (quota === undefined) {
        return {
            disposition: "QUOTA_UNVERIFIED",
            reasonCodes: ["source_capability_quota_state_missing"],
        };
    }
    if (quota.evidenceClass !== "LIVE_READ_ONLY") {
        return {
            disposition: "QUOTA_UNVERIFIED",
            reasonCodes: ["test_only_quota_cannot_enter_runtime_planning"],
        };
    }
    const now = Date.parse(generatedAt);
    if (Date.parse(quota.windowStartedAt) > now ||
        Date.parse(quota.windowEndsAt) <= now) {
        return {
            disposition: "QUOTA_UNVERIFIED",
            reasonCodes: ["source_capability_quota_window_not_current"],
        };
    }
    if (quota.status === "RATE_LIMITED") {
        return {
            disposition: "RATE_LIMITED",
            reasonCodes: ["provider_rate_limited_no_stale_fallback"],
        };
    }
    if (quota.status === "AUTH_ERROR") {
        return {
            disposition: "AUTH_ERROR",
            reasonCodes: ["provider_authentication_failed"],
        };
    }
    if (quota.status === "SOURCE_UNAVAILABLE") {
        return {
            disposition: "SOURCE_UNAVAILABLE",
            reasonCodes: ["provider_source_unavailable"],
        };
    }
    if (quota.requestsUsed + quota.requestsReserved >= quota.requestLimit) {
        return {
            disposition: "QUOTA_EXHAUSTED",
            reasonCodes: ["documented_request_budget_exhausted"],
        };
    }
    return null;
}
function registryDisposition(sourceId, capabilityId) {
    const row = four_venue_capability_registry_1.M1_FOUR_VENUE_SOURCE_CAPABILITY_REGISTRY.rows.find((candidate) => candidate.sourceId === sourceId &&
        candidate.capabilityId === capabilityId);
    if (row === undefined ||
        !["ADOPTED_AS_FACT", "DERIVED_WITH_LINEAGE"].includes(row.disposition)) {
        return {
            disposition: "REGISTRY_DISPOSITION_BLOCKED",
            reasonCodes: [
                row === undefined
                    ? "source_capability_registry_row_missing"
                    : `registry_disposition_${row.disposition.toLowerCase()}`,
            ],
        };
    }
    return null;
}
function subjectBlock(subject, tier) {
    if (tier === "T0_CATALOG_EVENT") {
        return null;
    }
    if (subject.identityStatus !== "EXACT") {
        return {
            disposition: "IDENTITY_UNRESOLVED",
            reasonCodes: ["exact_identity_required_for_market_collection"],
        };
    }
    if (subject.eligibilityStatus !== "ELIGIBLE" ||
        subject.coverageClass !== "SUPPORTED_DERIVATIVE") {
        return {
            disposition: "SUBJECT_NOT_ELIGIBLE",
            reasonCodes: ["eligible_derivative_required_for_t1_t3"],
        };
    }
    if (!["TRADING_WARMUP", "ESTABLISHED"].includes(subject.lifecycleState)) {
        return {
            disposition: "LIFECYCLE_BLOCKED",
            reasonCodes: [`lifecycle_${subject.lifecycleState.toLowerCase()}`],
        };
    }
    if (["T2_CANDIDATE_BURST", "T3_DEEP_VALIDATION"].includes(tier) &&
        subject.lifecycleState !== "ESTABLISHED") {
        return {
            disposition: "LIFECYCLE_BLOCKED",
            reasonCodes: ["warmup_assets_cannot_enter_burst_or_deep_collection"],
        };
    }
    return null;
}
function applicableRegistryRows(subject, tier) {
    return four_venue_capability_registry_1.M1_FOUR_VENUE_SOURCE_CAPABILITY_REGISTRY.rows.filter((row) => {
        const capability = four_venue_capability_registry_1.M1_FOUR_VENUE_SOURCE_CAPABILITY_REGISTRY.capabilities
            .find((candidate) => candidate.capabilityId === row.capabilityId);
        if (capability === undefined || !capability.targetTiers.includes(tier)) {
            return false;
        }
        const sourceMatches = row.sourceId === subject.sourceId ||
            (tier === "T3_DEEP_VALIDATION" && row.sourceId === "COINGLASS_V4");
        if (!sourceMatches) {
            return false;
        }
        return (row.assetDomains.includes(subject.assetDomain) ||
            (tier === "T3_DEEP_VALIDATION" &&
                row.assetDomains.includes("CROSS_MARKET_CONTEXT")));
    });
}
function evidenceClass(grants) {
    if (grants.length === 0) {
        return "NO_GRANTS";
    }
    return grants.every((grant) => grant.evidenceClass === "LIVE_READ_ONLY")
        ? "LIVE_READ_ONLY_ONLY"
        : "TEST_ONLY_OR_MIXED";
}
function sourceOrder(cursor) {
    const cursorIndex = source_capability_contract_1.M1_SOURCE_IDS.indexOf(cursor);
    return [
        ...source_capability_contract_1.M1_SOURCE_IDS.slice(cursorIndex),
        ...source_capability_contract_1.M1_SOURCE_IDS.slice(0, cursorIndex),
    ];
}
function readyOrdering(left, right) {
    const tierPriority = {
        T0_CATALOG_EVENT: 0,
        T1_WIDE_MARKET: 1,
        T2_CANDIDATE_BURST: 2,
        T3_DEEP_VALIDATION: 3,
    };
    const rolePriority = (intent) => intent.matchedControlForEpisodeId !== null
        ? 0
        : intent.candidateEpisodeId !== null
            ? 1
            : 2;
    return (tierPriority[left.tier] - tierPriority[right.tier] ||
        rolePriority(left) - rolePriority(right) ||
        left.intentKey.localeCompare(right.intentKey));
}
function allocateReadyCapacity(intents, policy, quotasByKey) {
    const ready = intents.filter((intent) => intent.disposition === "READY_FOR_RUNTIME_ADAPTER");
    const baseline = ready
        .filter((intent) => intent.tier === "T0_CATALOG_EVENT" ||
        intent.tier === "T1_WIDE_MARKET")
        .sort(readyOrdering);
    const burst = ready
        .filter((intent) => intent.tier === "T2_CANDIDATE_BURST" ||
        intent.tier === "T3_DEEP_VALIDATION")
        .sort(readyOrdering);
    const selected = new Set();
    const perSource = emptySourceCounts();
    const perSubjectBurst = new Map();
    const order = sourceOrder(policy.fairnessCursorSource);
    const remainingByQuotaKey = new Map();
    for (const [key, quota] of quotasByKey) {
        remainingByQuotaKey.set(key, quota.requestLimit - quota.requestsUsed - quota.requestsReserved);
    }
    const selectPhase = (candidates, maxAdditional) => {
        var _a, _b;
        const pools = new Map();
        for (const sourceId of source_capability_contract_1.M1_SOURCE_IDS) {
            pools.set(sourceId, []);
        }
        for (const intent of candidates) {
            if (!selected.has(intent.intentKey)) {
                pools.get(intent.collectionSourceId).push(intent);
            }
        }
        let added = 0;
        let progressed = true;
        while (selected.size < policy.maxReadyIntents &&
            added < maxAdditional &&
            progressed) {
            progressed = false;
            for (const sourceId of order) {
                if (selected.size >= policy.maxReadyIntents ||
                    added >= maxAdditional ||
                    perSource[sourceId] >= policy.maxReadyIntentsPerSource) {
                    continue;
                }
                const pool = pools.get(sourceId);
                while (pool.length > 0) {
                    const candidate = pool.shift();
                    const burstIntent = [
                        "T2_CANDIDATE_BURST",
                        "T3_DEEP_VALIDATION",
                    ].includes(candidate.tier);
                    const currentBurst = (_a = perSubjectBurst.get(candidate.subjectId)) !== null && _a !== void 0 ? _a : 0;
                    if (burstIntent &&
                        currentBurst >= policy.maxBurstIntentsPerSubject) {
                        candidate.disposition = "BACKPRESSURE_DEFERRED";
                        candidate.reasonCodes = ["per_subject_burst_limit_reached"];
                        candidate.plannedRequestTokens = 0;
                        continue;
                    }
                    const quotaKey = `${candidate.collectionSourceId}:${candidate.capabilityId}`;
                    const remaining = (_b = remainingByQuotaKey.get(quotaKey)) !== null && _b !== void 0 ? _b : 0;
                    if (remaining <= 0) {
                        candidate.disposition = "QUOTA_EXHAUSTED";
                        candidate.reasonCodes = [
                            "bounded_plan_would_exceed_request_budget",
                        ];
                        candidate.plannedRequestTokens = 0;
                        continue;
                    }
                    selected.add(candidate.intentKey);
                    perSource[sourceId] += 1;
                    remainingByQuotaKey.set(quotaKey, remaining - 1);
                    if (burstIntent) {
                        perSubjectBurst.set(candidate.subjectId, currentBurst + 1);
                    }
                    added += 1;
                    progressed = true;
                    break;
                }
            }
        }
    };
    const baselineReserve = Math.min(baseline.length, policy.baselineReservedSlots, policy.maxReadyIntents);
    selectPhase(baseline, baselineReserve);
    selectPhase(burst, policy.maxReadyIntents - selected.size);
    selectPhase(baseline, policy.maxReadyIntents - selected.size);
    for (const intent of ready) {
        if (!selected.has(intent.intentKey) &&
            intent.disposition === "READY_FOR_RUNTIME_ADAPTER") {
            intent.disposition = "BACKPRESSURE_DEFERRED";
            intent.reasonCodes = ["bounded_ready_capacity_exhausted"];
            intent.plannedRequestTokens = 0;
        }
    }
}
function enforceControlReadiness(intents, subjects) {
    const controlEpisodes = new Set();
    for (const subject of subjects) {
        if (subject.matchedControlForEpisodeId !== null) {
            controlEpisodes.add(subject.matchedControlForEpisodeId);
        }
    }
    const readyControlCapabilities = new Set(intents
        .filter((intent) => intent.matchedControlForEpisodeId !== null &&
        intent.disposition === "READY_FOR_RUNTIME_ADAPTER")
        .map((intent) => [
        intent.matchedControlForEpisodeId,
        intent.tier,
        intent.capabilityId,
    ].join(":")));
    for (const intent of intents) {
        const episodeId = intent.candidateEpisodeId;
        if (episodeId === null ||
            !["T2_CANDIDATE_BURST", "T3_DEEP_VALIDATION"].includes(intent.tier)) {
            continue;
        }
        if (!controlEpisodes.has(episodeId)) {
            intent.disposition = "CONTROL_MISSING";
            intent.reasonCodes = ["candidate_episode_has_no_matched_control"];
            intent.plannedRequestTokens = 0;
            continue;
        }
        if (intent.disposition !== "READY_FOR_RUNTIME_ADAPTER") {
            continue;
        }
        const controlKey = [
            episodeId,
            intent.tier,
            intent.capabilityId,
        ].join(":");
        if (!readyControlCapabilities.has(controlKey)) {
            intent.disposition = "CONTROL_NOT_READY";
            intent.reasonCodes = ["matched_control_capability_not_ready"];
            intent.plannedRequestTokens = 0;
        }
    }
}
function hasLiveEquityPrerequisites(subject, grants, generatedAt) {
    if (!isEquityDomain(subject.assetDomain)) {
        return true;
    }
    return [
        "EQUITY_SESSION_REFERENCE",
        "EQUITY_CORPORATE_ACTION",
    ].every((capabilityId) => grants.some((grant) => grant.sourceId === subject.sourceId &&
        grant.capabilityId === capabilityId &&
        grant.assetDomains.includes(subject.assetDomain) &&
        liveGrantDisposition(grant, generatedAt).disposition ===
            "READY_FOR_RUNTIME_ADAPTER"));
}
function buildIntent(subject, tier, sourceId, capabilityId, input, grantsByKey, quotasByKey, checkpointsByKey) {
    var _a, _b;
    const key = intentKey({
        subjectId: subject.subjectId,
        sourceId,
        tier,
        capabilityId,
    });
    const base = {
        intentKey: key,
        subjectId: subject.subjectId,
        subjectSourceId: subject.sourceId,
        collectionSourceId: sourceId,
        assetDomain: subject.assetDomain,
        tier,
        capabilityId,
        candidateEpisodeId: subject.candidateEpisodeId,
        matchedControlForEpisodeId: subject.matchedControlForEpisodeId,
        deepValidationEpisodeId: subject.deepValidationEpisodeId,
        disposition: "CAPABILITY_NOT_LIVE",
        reasonCodes: [],
        grantId: null,
        quotaWindowEndsAt: null,
        plannedRequestTokens: 0,
        runtimeExecutionAllowed: false,
        factAuthorityGranted: false,
        candidateAuthorityGranted: false,
        strategyAuthorityGranted: false,
    };
    const subjectBlocked = subjectBlock(subject, tier);
    if (subjectBlocked !== null) {
        return Object.assign(Object.assign({}, base), subjectBlocked);
    }
    const registryBlocked = registryDisposition(sourceId, capabilityId);
    if (registryBlocked !== null) {
        return Object.assign(Object.assign({}, base), registryBlocked);
    }
    if (tier !== "T0_CATALOG_EVENT" &&
        !hasLiveEquityPrerequisites(subject, input.capabilityGrants, input.generatedAt)) {
        return Object.assign(Object.assign({}, base), { disposition: "EQUITY_REFERENCE_BLOCKED", reasonCodes: [
                "equity_session_and_corporate_action_capabilities_required",
            ] });
    }
    const grants = (_a = grantsByKey.get(`${sourceId}:${capabilityId}`)) !== null && _a !== void 0 ? _a : [];
    const applicableGrants = grants.filter((grant) => grant.assetDomains.includes(subject.assetDomain) ||
        (tier === "T3_DEEP_VALIDATION" &&
            grant.assetDomains.includes("CROSS_MARKET_CONTEXT")));
    if (applicableGrants.length === 0) {
        return Object.assign(Object.assign({}, base), { disposition: "CAPABILITY_NOT_LIVE", reasonCodes: ["no_capability_grant_for_subject_domain"] });
    }
    if (applicableGrants.length > 1) {
        return Object.assign(Object.assign({}, base), { disposition: "CAPABILITY_GRANT_CONFLICT", reasonCodes: ["multiple_capability_grants_for_subject_domain"] });
    }
    const grant = applicableGrants[0];
    const grantDisposition = liveGrantDisposition(grant, input.generatedAt);
    if (grantDisposition.disposition !== "READY_FOR_RUNTIME_ADAPTER") {
        return Object.assign(Object.assign(Object.assign({}, base), grantDisposition), { grantId: grant.grantId });
    }
    const quota = quotasByKey.get(`${sourceId}:${capabilityId}`);
    const quotaBlocked = quotaDisposition(quota, input.generatedAt);
    if (quotaBlocked !== null) {
        return Object.assign(Object.assign(Object.assign({}, base), quotaBlocked), { grantId: grant.grantId, quotaWindowEndsAt: (_b = quota === null || quota === void 0 ? void 0 : quota.windowEndsAt) !== null && _b !== void 0 ? _b : null });
    }
    const checkpointBlocked = checkpointDisposition(checkpointsByKey.get(key), tier, input.generatedAt, input.policy);
    if (checkpointBlocked !== null) {
        return Object.assign(Object.assign(Object.assign({}, base), checkpointBlocked), { grantId: grant.grantId, quotaWindowEndsAt: quota.windowEndsAt });
    }
    return Object.assign(Object.assign({}, base), { disposition: "READY_FOR_RUNTIME_ADAPTER", reasonCodes: [], grantId: grant.grantId, quotaWindowEndsAt: quota.windowEndsAt, plannedRequestTokens: 1 });
}
function buildM1AdaptiveCollectorPlan(rawInput) {
    var _a;
    const input = PlanInputSchema.parse(rawInput);
    if (input.registryDigest !==
        four_venue_capability_registry_1.M1_FOUR_VENUE_SOURCE_CAPABILITY_REGISTRY.registryDigest) {
        throw new Error("adaptive collector registry digest mismatch");
    }
    if (Date.parse(input.sourceCutoff) > Date.parse(input.generatedAt)) {
        throw new Error("adaptive collector source cutoff is in the future");
    }
    const subjectIds = input.subjects.map((subject) => subject.subjectId);
    if (new Set(subjectIds).size !== subjectIds.length) {
        throw new Error("adaptive collector subjects must be unique");
    }
    const venueInstrumentKeys = input.subjects.map((subject) => `${subject.sourceId}:${subject.venueInstrumentId}`);
    if (new Set(venueInstrumentKeys).size !== venueInstrumentKeys.length) {
        throw new Error("adaptive collector venue instrument subjects must be unique");
    }
    const canonicalIds = input.subjects
        .map((subject) => subject.canonicalInstrumentId)
        .filter((value) => value !== null);
    if (new Set(canonicalIds).size !== canonicalIds.length) {
        throw new Error("adaptive collector canonical instrument subjects must be unique");
    }
    const candidateEpisodeIds = input.subjects
        .map((subject) => subject.candidateEpisodeId)
        .filter((value) => value !== null);
    if (new Set(candidateEpisodeIds).size !== candidateEpisodeIds.length) {
        throw new Error("adaptive collector candidate episodes must be unique");
    }
    const deepEpisodeIds = input.subjects
        .map((subject) => subject.deepValidationEpisodeId)
        .filter((value) => value !== null);
    if (new Set(deepEpisodeIds).size !== deepEpisodeIds.length) {
        throw new Error("adaptive collector deep-validation episodes must be unique");
    }
    const candidatesByEpisode = new Map(input.subjects
        .filter((candidate) => candidate.candidateEpisodeId !== null)
        .map((candidate) => [candidate.candidateEpisodeId, candidate]));
    for (const control of input.subjects.filter((candidate) => candidate.matchedControlForEpisodeId !== null)) {
        const candidate = candidatesByEpisode.get(control.matchedControlForEpisodeId);
        if (candidate === undefined) {
            throw new Error("adaptive collector matched control has no candidate episode");
        }
        if (candidate.assetDomain !== control.assetDomain) {
            throw new Error("adaptive collector matched control asset domain mismatch");
        }
    }
    for (const subject of input.subjects) {
        const participatesInCandidateEvaluation = subject.candidateEpisodeId !== null ||
            subject.matchedControlForEpisodeId !== null ||
            subject.deepValidationEpisodeId !== null;
        if (participatesInCandidateEvaluation &&
            (subject.coverageClass !== "SUPPORTED_DERIVATIVE" ||
                subject.identityStatus !== "EXACT" ||
                subject.eligibilityStatus !== "ELIGIBLE" ||
                subject.lifecycleState !== "ESTABLISHED")) {
            throw new Error("adaptive collector candidate and control subjects require an " +
                "exact eligible established derivative identity");
        }
    }
    if (input.subjects.some((subject) => Date.parse(subject.observedAt) > Date.parse(input.sourceCutoff))) {
        throw new Error("adaptive collector subject knowledge exceeds source cutoff");
    }
    if (input.capabilityGrants.some((grant) => grant.releaseId !== input.releaseId ||
        Date.parse(grant.observedAt) > Date.parse(input.sourceCutoff))) {
        throw new Error("adaptive collector capability grant lineage mismatch");
    }
    const grantsByKey = new Map();
    for (const grant of input.capabilityGrants) {
        const key = `${grant.sourceId}:${grant.capabilityId}`;
        const existing = (_a = grantsByKey.get(key)) !== null && _a !== void 0 ? _a : [];
        existing.push(grant);
        grantsByKey.set(key, existing);
    }
    const quotasByKey = new Map();
    for (const quota of input.quotaStates) {
        const key = `${quota.sourceId}:${quota.capabilityId}`;
        if (quotasByKey.has(key)) {
            throw new Error(`duplicate adaptive collector quota state: ${key}`);
        }
        if (quota.releaseId !== input.releaseId ||
            Date.parse(quota.observedAt) > Date.parse(input.sourceCutoff) ||
            Date.parse(quota.windowStartedAt) > Date.parse(input.generatedAt)) {
            throw new Error("adaptive collector quota lineage exceeds cutoff");
        }
        quotasByKey.set(key, quota);
    }
    const checkpointsByKey = new Map();
    for (const checkpoint of input.checkpoints) {
        if (checkpointsByKey.has(checkpoint.intentKey)) {
            throw new Error(`duplicate adaptive collector checkpoint: ${checkpoint.intentKey}`);
        }
        if ((checkpoint.lastCompletedAt !== null &&
            Date.parse(checkpoint.lastCompletedAt) >
                Date.parse(input.generatedAt)) ||
            (checkpoint.lastAttemptAt !== null &&
                Date.parse(checkpoint.lastAttemptAt) >
                    Date.parse(input.generatedAt))) {
            throw new Error("adaptive collector checkpoint contains future history");
        }
        checkpointsByKey.set(checkpoint.intentKey, checkpoint);
    }
    const intents = [];
    for (const subject of [...input.subjects].sort((left, right) => left.subjectId.localeCompare(right.subjectId))) {
        for (const tier of source_capability_contract_1.M1_COLLECTION_TIERS) {
            if (!subjectTierEligible(subject, tier, input.subjects)) {
                continue;
            }
            const rows = applicableRegistryRows(subject, tier);
            if (rows.length === 0) {
                throw new Error(`adaptive collector has no registry accounting rows for ` +
                    `${subject.subjectId}:${tier}`);
            }
            for (const row of rows) {
                intents.push(buildIntent(subject, tier, row.sourceId, row.capabilityId, input, grantsByKey, quotasByKey, checkpointsByKey));
            }
        }
    }
    if (intents.length > input.policy.maxIntentRows) {
        throw new Error(`adaptive collector intent denominator ${intents.length} exceeds ` +
            `the bounded plan limit ${input.policy.maxIntentRows}`);
    }
    allocateReadyCapacity(intents, input.policy, quotasByKey);
    enforceControlReadiness(intents, input.subjects);
    const parsedIntents = intents
        .sort((left, right) => left.intentKey.localeCompare(right.intentKey))
        .map((intent) => exports.M1AdaptiveCollectorIntentSchema.parse(intent));
    const countsByTier = emptyTierCounts();
    const countsBySource = emptySourceCounts();
    const countsByDisposition = emptyDispositionCounts();
    const plannedRequestTokensBySource = emptySourceCounts();
    for (const intent of parsedIntents) {
        countsByTier[intent.tier] += 1;
        countsBySource[intent.collectionSourceId] += 1;
        countsByDisposition[intent.disposition] += 1;
        plannedRequestTokensBySource[intent.collectionSourceId] +=
            intent.plannedRequestTokens;
    }
    const core = adaptiveCollectorPlanCore({
        schemaVersion: exports.M1_ADAPTIVE_COLLECTOR_PLAN_VERSION,
        scopeEpoch: source_capability_contract_1.M1_SCOPE_EPOCH,
        releaseId: input.releaseId,
        generatedAt: input.generatedAt,
        sourceCutoff: input.sourceCutoff,
        registryDigest: input.registryDigest,
        identitySnapshotHash: input.identitySnapshotHash,
        subjectInputHash: (0, stable_artifact_1.stableContentHash)([...input.subjects].sort((left, right) => left.subjectId.localeCompare(right.subjectId))),
        capabilityGrantSetHash: (0, stable_artifact_1.stableContentHash)([...input.capabilityGrants].sort((left, right) => left.grantId.localeCompare(right.grantId))),
        quotaStateSetHash: (0, stable_artifact_1.stableContentHash)([...input.quotaStates].sort((left, right) => `${left.sourceId}:${left.capabilityId}`.localeCompare(`${right.sourceId}:${right.capabilityId}`))),
        checkpointSetHash: (0, stable_artifact_1.stableContentHash)([...input.checkpoints].sort((left, right) => left.intentKey.localeCompare(right.intentKey))),
        policyHash: (0, stable_artifact_1.stableContentHash)(input.policy),
        capabilityEvidenceClass: evidenceClass(input.capabilityGrants),
        subjectCount: input.subjects.length,
        subjectDenominatorsByTier: subjectTierDenominators(input.subjects),
        intentCount: parsedIntents.length,
        readyForRuntimeAdapterCount: countsByDisposition.READY_FOR_RUNTIME_ADAPTER,
        countsByTier,
        countsBySource,
        countsByDisposition,
        plannedRequestTokensBySource,
        intents: parsedIntents,
        schedulerAuthority: "CONTRACT_ONLY_NO_RUNTIME_EXECUTION_AUTHORITY",
        runtimeExecutionAllowed: false,
        factAuthorityGranted: false,
        candidateAuthorityGranted: false,
        strategyAuthorityGranted: false,
        readyAuthorityGranted: false,
        productionChanged: false,
    });
    const contentHash = (0, stable_artifact_1.stableContentHash)(core);
    return (0, stable_artifact_1.deepFreezeArtifact)(exports.M1AdaptiveCollectorPlanSchema.parse(Object.assign(Object.assign({}, core), { planId: `adaptive-collector:${contentHash.slice(7, 31)}`, contentHash })));
}
