"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UncertaintyVectorSchema = exports.UncertaintyAssessmentSchema = exports.InstrumentIdentitySchema = exports.QualityAssessmentSchema = exports.SourceLineageSchema = exports.TraceEnvelopeSchema = exports.ReasonCodesSchema = exports.DecimalStringSchema = exports.NonNegativeDecimalStringSchema = exports.PositiveDecimalStringSchema = exports.NonNegativeIntegerSchema = exports.RatioSchema = exports.NonNegativeFiniteSchema = exports.FiniteNumberSchema = exports.IsoDateTimeSchema = exports.NonEmptyStringSchema = void 0;
exports.compareNonNegativeDecimalStrings = compareNonNegativeDecimalStrings;
exports.traceEnvelopeShape = traceEnvelopeShape;
const zod_1 = require("zod");
const module_registry_1 = require("../domain/module-registry");
const product_constitution_1 = require("../domain/product-constitution");
const states_1 = require("../domain/states");
const uncertainty_1 = require("../domain/uncertainty");
exports.NonEmptyStringSchema = zod_1.z.string().trim().min(1);
exports.IsoDateTimeSchema = zod_1.z.string().datetime({ offset: true });
exports.FiniteNumberSchema = zod_1.z.number().finite();
exports.NonNegativeFiniteSchema = exports.FiniteNumberSchema.min(0);
exports.RatioSchema = exports.FiniteNumberSchema.min(0).max(1);
exports.NonNegativeIntegerSchema = zod_1.z.number().int().nonnegative();
exports.PositiveDecimalStringSchema = zod_1.z
    .string()
    .max(128)
    .regex(/^(?:0|[1-9]\d*)(?:\.\d+)?$/u)
    .refine((value) => /[1-9]/u.test(value), "must be greater than zero");
exports.NonNegativeDecimalStringSchema = zod_1.z
    .string()
    .max(128)
    .regex(/^(?:0|[1-9]\d*)(?:\.\d+)?$/u);
exports.DecimalStringSchema = zod_1.z
    .string()
    .max(129)
    .regex(/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/u);
exports.ReasonCodesSchema = zod_1.z.array(exports.NonEmptyStringSchema);
function compareNonNegativeDecimalStrings(left, right) {
    const [leftInteger, leftFraction = ""] = left.split(".");
    const [rightInteger, rightFraction = ""] = right.split(".");
    if (leftInteger.length !== rightInteger.length) {
        return leftInteger.length < rightInteger.length ? -1 : 1;
    }
    if (leftInteger !== rightInteger) {
        return leftInteger < rightInteger ? -1 : 1;
    }
    const fractionLength = Math.max(leftFraction.length, rightFraction.length);
    const normalizedLeft = leftFraction.padEnd(fractionLength, "0");
    const normalizedRight = rightFraction.padEnd(fractionLength, "0");
    if (normalizedLeft === normalizedRight) {
        return 0;
    }
    return normalizedLeft < normalizedRight ? -1 : 1;
}
function traceEnvelopeShape(producerModule, schemaVersion) {
    return {
        schemaVersion: zod_1.z.literal(schemaVersion),
        releaseId: exports.NonEmptyStringSchema,
        producerModule: zod_1.z.literal(producerModule),
        generatedAt: exports.IsoDateTimeSchema,
        sourceCutoff: exports.IsoDateTimeSchema,
        contentHash: exports.NonEmptyStringSchema,
    };
}
exports.TraceEnvelopeSchema = zod_1.z.strictObject({
    schemaVersion: exports.NonEmptyStringSchema,
    releaseId: exports.NonEmptyStringSchema,
    producerModule: zod_1.z.enum(module_registry_1.MODULE_IDS),
    generatedAt: exports.IsoDateTimeSchema,
    sourceCutoff: exports.IsoDateTimeSchema,
    contentHash: exports.NonEmptyStringSchema,
});
exports.SourceLineageSchema = zod_1.z.strictObject({
    sourceId: exports.NonEmptyStringSchema,
    sourceCapability: exports.NonEmptyStringSchema,
    sourceRecordIds: zod_1.z.array(exports.NonEmptyStringSchema),
    eventTime: exports.IsoDateTimeSchema.nullable(),
    receivedAt: exports.IsoDateTimeSchema,
    normalizedAt: exports.IsoDateTimeSchema,
    persistedAt: exports.IsoDateTimeSchema.nullable(),
}).superRefine((lineage, context) => {
    const eventTime = lineage.eventTime === null
        ? null
        : Date.parse(lineage.eventTime);
    const receivedAt = Date.parse(lineage.receivedAt);
    const normalizedAt = Date.parse(lineage.normalizedAt);
    const persistedAt = lineage.persistedAt === null
        ? null
        : Date.parse(lineage.persistedAt);
    if (eventTime !== null && eventTime > receivedAt) {
        context.addIssue({
            code: "custom",
            message: "eventTime cannot be later than receivedAt",
            path: ["eventTime"],
        });
    }
    if (receivedAt > normalizedAt) {
        context.addIssue({
            code: "custom",
            message: "receivedAt cannot be later than normalizedAt",
            path: ["receivedAt"],
        });
    }
    if (persistedAt !== null && normalizedAt > persistedAt) {
        context.addIssue({
            code: "custom",
            message: "normalizedAt cannot be later than persistedAt",
            path: ["normalizedAt"],
        });
    }
});
exports.QualityAssessmentSchema = zod_1.z.strictObject({
    status: zod_1.z.enum(states_1.DATA_QUALITY_STATES),
    ageMs: exports.NonNegativeFiniteSchema.nullable(),
    reasonCodes: exports.ReasonCodesSchema,
}).superRefine((quality, context) => {
    if (quality.status !== "FRESH" && quality.reasonCodes.length === 0) {
        context.addIssue({
            code: "custom",
            message: "non-fresh quality requires at least one reason code",
            path: ["reasonCodes"],
        });
    }
    if (quality.status === "UNAVAILABLE" && quality.ageMs !== null) {
        context.addIssue({
            code: "custom",
            message: "unavailable quality cannot claim a measured age",
            path: ["ageMs"],
        });
    }
});
exports.InstrumentIdentitySchema = zod_1.z.strictObject({
    canonicalInstrumentId: exports.NonEmptyStringSchema,
    underlyingGroupId: exports.NonEmptyStringSchema,
    venue: zod_1.z.enum(product_constitution_1.TARGET_VENUES),
    venueInstrumentId: exports.NonEmptyStringSchema,
    baseAsset: exports.NonEmptyStringSchema,
    quoteAsset: exports.NonEmptyStringSchema,
    settlementAsset: exports.NonEmptyStringSchema,
    contractType: zod_1.z.literal("LINEAR_PERPETUAL"),
    contractSize: exports.PositiveDecimalStringSchema,
});
exports.UncertaintyAssessmentSchema = zod_1.z.strictObject({
    dimension: zod_1.z.enum(uncertainty_1.UNCERTAINTY_DIMENSIONS),
    status: zod_1.z.enum(["LOW", "MEDIUM", "HIGH", "UNKNOWN"]),
    reasonCodes: exports.ReasonCodesSchema,
    sampleSize: exports.NonNegativeIntegerSchema.nullable(),
    calibrationVersion: exports.NonEmptyStringSchema.nullable(),
    lastValidatedAt: exports.IsoDateTimeSchema.nullable(),
});
function uncertaintyFor(dimension) {
    return exports.UncertaintyAssessmentSchema.refine((assessment) => assessment.dimension === dimension, `${dimension} uncertainty must identify its own dimension`);
}
exports.UncertaintyVectorSchema = zod_1.z.strictObject({
    data: uncertaintyFor("data"),
    model: uncertaintyFor("model"),
    market: uncertaintyFor("market"),
    execution: uncertaintyFor("execution"),
});
