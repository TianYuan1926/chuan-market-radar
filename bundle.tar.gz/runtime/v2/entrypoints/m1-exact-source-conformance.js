"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runM1ExactSourceConformanceEntrypoint = runM1ExactSourceConformanceEntrypoint;
const node_child_process_1 = require("node:child_process");
const node_path_1 = require("node:path");
const four_venue_capability_registry_1 = require("../modules/source-capability/adapters/four-venue-capability-registry");
const exact_source_conformance_runner_1 = require("../modules/source-conformance/adapters/exact-source-conformance-runner");
function option(args, name) {
    const index = args.indexOf(name);
    const value = index < 0 ? undefined : args[index + 1];
    if (value === undefined || value.startsWith("--") || value.trim() === "") {
        throw new Error(`missing required ${name} option`);
    }
    return value;
}
function resolveCleanRepositoryRelease(repositoryRoot) {
    const releaseId = (0, node_child_process_1.execFileSync)("git", ["-C", repositoryRoot, "rev-parse", "HEAD"], { encoding: "utf8" }).trim();
    const trackedChanges = (0, node_child_process_1.execFileSync)("git", ["-C", repositoryRoot, "status", "--porcelain", "--untracked-files=all"], { encoding: "utf8" }).trim();
    if (trackedChanges !== "") {
        throw new Error("source conformance requires a completely clean release");
    }
    if (!/^[0-9a-f]{40}$/u.test(releaseId)) {
        throw new Error("repository HEAD is not a full Git commit id");
    }
    return releaseId;
}
function networkEnvironment(value) {
    if (value !== "LOCAL_WORKSTATION" &&
        value !== "TENCENT_ISOLATED_READ_ONLY") {
        throw new Error("network environment must be LOCAL_WORKSTATION or TENCENT_ISOLATED_READ_ONLY");
    }
    return value;
}
async function runM1ExactSourceConformanceEntrypoint(input) {
    var _a, _b, _c;
    const allowed = new Set([
        "--network-environment",
        "--release-id",
        "--repository-root",
    ]);
    const optionNames = input.args.filter((_, index) => index % 2 === 0);
    if (input.args.length !== 6 ||
        optionNames.some((value) => !allowed.has(value)) ||
        new Set(optionNames).size !== allowed.size) {
        throw new Error("usage: m1-exact-source-conformance --repository-root <absolute-path> --release-id <40-hex-commit> --network-environment <LOCAL_WORKSTATION|TENCENT_ISOLATED_READ_ONLY>");
    }
    const repositoryRoot = option(input.args, "--repository-root");
    const releaseId = option(input.args, "--release-id");
    if (!(0, node_path_1.isAbsolute)(repositoryRoot)) {
        throw new Error("repository root must be absolute");
    }
    if (!/^[0-9a-f]{40}$/u.test(releaseId)) {
        throw new Error("release-id must be a full 40-hex Git commit id");
    }
    const resolvedRepositoryRoot = (0, node_path_1.resolve)(repositoryRoot);
    const actualReleaseId = ((_a = input.resolveRepositoryRelease) !== null && _a !== void 0 ? _a : resolveCleanRepositoryRelease)(resolvedRepositoryRoot);
    if (actualReleaseId !== releaseId) {
        throw new Error("source conformance release-id does not match repository HEAD");
    }
    const artifact = await (0, exact_source_conformance_runner_1.runM1ExactSourceConformance)({
        releaseId,
        registryDigest: four_venue_capability_registry_1.M1_FOUR_VENUE_SOURCE_CAPABILITY_REGISTRY.registryDigest,
        networkEnvironment: networkEnvironment(option(input.args, "--network-environment")),
        coinGlassApiKey: (_c = ((_b = input.env) !== null && _b !== void 0 ? _b : process.env).COINGLASS_API_KEY) !== null && _c !== void 0 ? _c : null,
        fetchImplementation: input.fetchImplementation,
        now: input.now,
    });
    const passed = artifact.identityGateStatus === "PASS" &&
        artifact.listingGateStatus === "PASS" &&
        artifact.coinGlassGateStatus === "PASS";
    return Object.freeze({
        exitCode: passed ? 0 : 2,
        output: JSON.stringify(artifact),
    });
}
if (require.main === module) {
    void runM1ExactSourceConformanceEntrypoint({
        args: process.argv.slice(2),
    }).then((result) => {
        process.stdout.write(`${result.output}\n`);
        process.exitCode = result.exitCode;
    }).catch((error) => {
        const message = error instanceof Error ? error.message : String(error);
        process.stderr.write(`m1 exact source conformance failed: ${message}\n`);
        process.exitCode = 1;
    });
}
